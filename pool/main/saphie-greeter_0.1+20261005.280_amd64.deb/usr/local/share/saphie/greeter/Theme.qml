pragma Singleton
import Quickshell
import Quickshell.Io
import QtQuick

// Saphie "Channel" design tokens (docs/desktop-design-zzz.md). Black & white with a bright
// green accent by default; wallpaper mode replaces accentA/accentB.
Singleton {
    id: theme
    // Live colors from ~/.config/saphie/colors.json (written by desktop/bin/saphie-theme).
    // Only "#rrggbb" values are accepted; anything else keeps the black & white default.
    property var live: ({})
    function pick(key, fallback) {
        const v = live[key];
        return typeof v === "string" && /^#[0-9a-fA-F]{6}$/.test(v) ? v : fallback;
    }
    FileView {
        path: (Quickshell.env("HOME") ?? "") + "/.config/saphie/colors.json"
        watchChanges: true
        printErrors: false
        onFileChanged: reload()
        onLoaded: {
            try {
                const d = JSON.parse(text());
                theme.live = d && typeof d === "object" ? d : {};
            } catch (e) { theme.live = {}; }
        }
        onLoadFailed: theme.live = {}
    }

    readonly property color bg: "#000000"
    readonly property color surface: pick("surface", "#141414")
    readonly property color ring: pick("ring", "#333333")
    readonly property color raised: "#4b4b4b"
    readonly property color text: "#ffffff"
    readonly property color textDim: pick("textDim", "#b4b4b4")
    readonly property color accentA: pick("accentA", "#aaff00")   // bright ZZZ-style green
    readonly property color accentB: pick("accentB", "#5fcc00")   // pulse partner (deeper green)
    readonly property color onAccent: pick("onAccent", "#000000")
    readonly property color danger: "#c01c00"

    readonly property int corner: 14          // sticker corner radius (one corner stays sharp)
    readonly property int edge: 2             // black outer edge
    readonly property int ringWidth: 3        // inner ring
    readonly property int shadow: 4           // hard offset shadow, no blur
    readonly property int gap: 6
    readonly property real skew: -0.364       // tan(-20 deg), highlight backings only

    readonly property string numeralFont: "Barlow Condensed"
    readonly property string titleFont: "Archivo Black"
    readonly property string labelFont: "JetBrains Mono"

    readonly property int snapMs: 330         // bezier(1, 0, 0.5, 1)
    readonly property var snapCurve: [1, 0, 0.5, 1, 1, 1]
    readonly property int uiMs: 200           // bezier(0.15, 0.59, 0.45, 0.89)
    readonly property var uiCurve: [0.15, 0.59, 0.45, 0.89, 1, 1]
    readonly property int pulseMs: 1000

    // How full-screen menus (launcher, power) open: "wipe" = green diagonal wipe (default),
    // "tv" = TV switch-on. Toggled from the launcher (chip / F2), saved in ~/.config/saphie/ui.json.
    property string openStyle: "wipe"
    readonly property var openStyles: ["wipe", "tv"]
    function toggleOpenStyle() {
        const i = openStyles.indexOf(openStyle);
        openStyle = openStyles[(i + 1) % openStyles.length];
        saveUi();
    }
    // Saphie Settings values (Settings.qml), saved together in ui.json. Every value read back
    // is checked (type + range); anything odd keeps the default.
    property bool uiSounds: true
    property real soundVolume: 0.45            // UI sounds only, 0..1
    property int idleLockMin: 10               // auto-lock after N minutes, 0 = never
    readonly property var idleLockChoices: [5, 10, 15, 30, 0]
    property bool hotkeysAtLogin: true
    function saveUi() {
        uiFile.setText(JSON.stringify({ openStyle: openStyle, uiSounds: uiSounds, soundVolume: soundVolume,
                                        idleLockMin: idleLockMin, hotkeysAtLogin: hotkeysAtLogin }, null, 1) + "\n");
    }
    FileView {
        id: uiFile
        path: (Quickshell.env("HOME") ?? "") + "/.config/saphie/ui.json"
        printErrors: false
        onLoaded: {
            try {
                const d = JSON.parse(text());
                if (!d || typeof d !== "object") return;
                if (theme.openStyles.includes(d.openStyle)) theme.openStyle = d.openStyle;
                if (typeof d.uiSounds === "boolean") theme.uiSounds = d.uiSounds;
                if (typeof d.soundVolume === "number" && d.soundVolume >= 0 && d.soundVolume <= 1) theme.soundVolume = d.soundVolume;
                if (theme.idleLockChoices.includes(d.idleLockMin)) theme.idleLockMin = d.idleLockMin;
                if (typeof d.hotkeysAtLogin === "boolean") theme.hotkeysAtLogin = d.hotkeysAtLogin;
            } catch (e) {}
        }
    }

    // UI sounds (desktop/sounds/make-sounds.py, played by Sfx.qml). uiSounds false = all off.
    readonly property bool closeSound: uiSounds
}
