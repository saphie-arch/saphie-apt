-- Saphie OS: Bluetooth headsets win the default speaker + mic too (see main.lua.d/51-saphie-headsets.lua).
bluez_monitor = bluez_monitor or {}
bluez_monitor.rules = bluez_monitor.rules or {}
table.insert(bluez_monitor.rules, {
  matches = { { { "node.name", "matches", "bluez_output.*" } } },
  apply_properties = { ["priority.session"] = 1109 },
})
table.insert(bluez_monitor.rules, {
  matches = { { { "node.name", "matches", "bluez_input.*" } } },
  apply_properties = { ["priority.session"] = 2109 },
})
