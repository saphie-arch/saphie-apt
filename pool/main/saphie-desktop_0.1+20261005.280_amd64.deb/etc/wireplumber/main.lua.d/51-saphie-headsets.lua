-- Saphie OS: a connected headset (USB or Bluetooth) becomes the default speaker + mic by itself,
-- and the laptop takes over again when it's gone. WirePlumber 0.4 picks the default by
-- priority.session unless you chose a device yourself (Settings > SOUND); ALSA gives the laptop
-- jack and a USB headset the same priority, so the laptop won by order. +100 puts headsets first.
alsa_monitor.rules = alsa_monitor.rules or {}
table.insert(alsa_monitor.rules, {
  matches = {
    { { "node.name", "matches", "alsa_output.usb-*" } },
  },
  apply_properties = { ["priority.session"] = 1109 },
})
table.insert(alsa_monitor.rules, {
  matches = {
    { { "node.name", "matches", "alsa_input.usb-*" } },
  },
  apply_properties = { ["priority.session"] = 2109 },
})
