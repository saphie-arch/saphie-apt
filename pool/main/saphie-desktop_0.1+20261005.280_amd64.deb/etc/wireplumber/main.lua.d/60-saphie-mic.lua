-- Saphie OS: new microphones start at a sane level instead of full hardware gain.
alsa_monitor.rules = alsa_monitor.rules or {}
table.insert(alsa_monitor.rules, {
  matches = { { { "node.name", "matches", "alsa_input.*" } } },
  apply_properties = { ["node.volume"] = 0.0049 },   -- 17% on the cubic volume scale
})
