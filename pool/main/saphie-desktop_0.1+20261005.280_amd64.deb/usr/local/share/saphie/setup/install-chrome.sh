#!/usr/bin/env bash
# Install Google Chrome from Google's signed apt repository (gets updates with normal system updates).
#   sudo bash setup/install-chrome.sh          install
#   sudo bash setup/install-chrome.sh --undo   remove Chrome + the repository
# Fails closed: the signing key must have Google's published fingerprint.
set -euo pipefail
[[ $EUID -eq 0 ]] || { echo "Run with sudo." >&2; exit 1; }
FPR="EB4C1BFD4F042F6DDDCCEC917721F63BD38B4796"
KEYRING=/etc/apt/keyrings/google-chrome.gpg
LIST=/etc/apt/sources.list.d/google-chrome.list
if [[ "${1:-}" == --undo ]]; then
  apt-get remove -y google-chrome-stable || true
  rm -f "$KEYRING" "$LIST"; apt-get update -qq || true
  echo "Chrome and its repository removed."; exit 0
fi
TMP="$(mktemp -d)"; trap 'rm -rf "$TMP"' EXIT
curl -fsSL https://dl.google.com/linux/linux_signing_key.pub -o "$TMP/key.pub"
got="$(gpg --batch --show-keys --with-colons "$TMP/key.pub" | awk -F: '$1=="fpr"{print $10; exit}')"
[[ "$got" == "$FPR" ]] || { echo "Signing key fingerprint mismatch ($got); not installing." >&2; exit 1; }
install -d -m 755 /etc/apt/keyrings
gpg --batch --dearmor -o "$TMP/google-chrome.gpg" "$TMP/key.pub"
install -m 644 "$TMP/google-chrome.gpg" "$KEYRING"
echo "deb [arch=amd64 signed-by=$KEYRING] https://dl.google.com/linux/chrome/deb/ stable main" > "$LIST"
apt-get update
apt-get install -y google-chrome-stable
# Chrome's package adds its own list file pointing at the same repo; keep only ours (signed-by)
for f in /etc/apt/sources.list.d/google-chrome*.list; do [[ "$f" == "$LIST" ]] || rm -f "$f"; done
echo; google-chrome-stable --version
echo "Undo: sudo bash $(readlink -f "$0") --undo"
