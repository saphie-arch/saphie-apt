#!/usr/bin/env bash
# Install Tailscale (private encrypted network between your PCs, works across any Wi-Fi/hotspot)
# from Tailscale's signed apt repository. Run on BOTH PCs:
#   sudo bash setup/install-tailscale.sh          install + start; then log in with the link it prints
#   sudo bash setup/install-tailscale.sh --undo   log out + remove
# Fails closed: the repository key must have Tailscale's fingerprint (cross-checked on
# keyserver.ubuntu.com, 2026-10-05).
set -euo pipefail
[[ $EUID -eq 0 ]] || { echo "Run with sudo." >&2; exit 1; }
FPR="2596A99EAAB33821893C0A79458CA832957F5868"
KEYRING=/usr/share/keyrings/tailscale-archive-keyring.gpg
LIST=/etc/apt/sources.list.d/tailscale.list
CODENAME="$(. /etc/os-release; echo "${UBUNTU_CODENAME:-$VERSION_CODENAME}")"
[[ "$CODENAME" =~ ^[a-z]+$ ]] || { echo "Unexpected Ubuntu codename '$CODENAME'" >&2; exit 1; }
if [[ "${1:-}" == --undo ]]; then
  tailscale logout 2>/dev/null || true
  apt-get remove -y tailscale || true
  rm -f "$KEYRING" "$LIST"; apt-get update -qq || true
  echo "Tailscale removed."; exit 0
fi
TMP="$(mktemp -d)"; trap 'rm -rf "$TMP"' EXIT
curl -fsSL "https://pkgs.tailscale.com/stable/ubuntu/$CODENAME.noarmor.gpg" -o "$TMP/key.gpg"
got="$(gpg --batch --show-keys --with-colons "$TMP/key.gpg" | awk -F: '$1=="fpr"{print $10; exit}')"
[[ "$got" == "$FPR" ]] || { echo "Tailscale key fingerprint mismatch ($got); not installing." >&2; exit 1; }
install -m 644 "$TMP/key.gpg" "$KEYRING"
echo "deb [signed-by=$KEYRING] https://pkgs.tailscale.com/stable/ubuntu $CODENAME main" > "$LIST"
apt-get update
apt-get install -y tailscale
systemctl enable --now tailscaled
U="${SUDO_USER:-}"
echo
echo "Now log in (opens a link; use the SAME account on both PCs):"
tailscale up ${U:+--operator="$U"} --hostname="$(hostname | tr -c 'a-zA-Z0-9-\n' '-' | cut -c1-40)"
echo; tailscale status
echo "Undo: sudo bash $(readlink -f "$0") --undo"
