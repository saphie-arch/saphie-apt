pragma Singleton
import Quickshell
import Quickshell.Io
import QtQuick

// Screen recording state for the bar's REC sticker (written by desktop/bin/saphie-record).
Singleton {
    id: root
    property bool recording: false
    property real started: 0
    property int secs: 0
    FileView {
        id: f
        path: (Quickshell.env("XDG_RUNTIME_DIR") ?? "/tmp") + "/saphie-record/state.json"
        printErrors: false
        onLoaded: { try { const d = JSON.parse(text()); root.recording = d.recording === true;
                          root.started = typeof d.started === "number" ? d.started : 0; } catch (e) { root.recording = false; } }
        onLoadFailed: root.recording = false
    }
    Timer { interval: 1000; running: true; repeat: true; triggeredOnStart: true
            onTriggered: { f.reload(); root.secs = root.recording && root.started > 0 ? Math.max(0, Math.floor(Date.now() / 1000 - root.started)) : 0; } }
    function stop() { Quickshell.execDetached([Quickshell.shellDir + "/../../bin/saphie-record", "stop"]); }
}
