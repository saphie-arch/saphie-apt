// Test harness: run the lock screen alone (inside a nested niri) without the bar.
//   quickshell -p desktop/shell/saphie-bar/lock-test.qml   (WAYLAND_DISPLAY = nested niri)
// IPC: "locktest lock" / "locktest submit <text>" / "locktest state".
import Quickshell
import Quickshell.Io
import QtQuick

ShellRoot {
    LockScreen {}
    FloatingWindow {   // unlocked preview of the lock visuals, for screenshots
        id: previewWin
        visible: false
        implicitWidth: 1100; implicitHeight: 700
        color: "#000000"
        LockContent { main: true }
    }
    IpcHandler {
        target: "locktest"
        function lock(): void { Locker.lock(); }
        function submit(text: string): void { Locker.submit(text); }
        function preview(): void { previewWin.visible = !previewWin.visible; }
        function state(): string { return JSON.stringify({ locked: Locker.locked, busy: Locker.busy, message: Locker.message, failures: Locker.failures }); }
    }
}
