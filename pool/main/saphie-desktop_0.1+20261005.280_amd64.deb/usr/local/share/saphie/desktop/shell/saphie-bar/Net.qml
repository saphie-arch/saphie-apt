import Quickshell.Networking
import QtQuick

// Wi-Fi signal + name, and live download/upload speed.
Row {
    id: root
    spacing: 8
    readonly property var wifiDevice: Networking.devices.values.find(d => d.type === DeviceType.Wifi) ?? null
    readonly property var net: wifiDevice ? wifiDevice.networks.values.find(n => n.connected) ?? null : null
    readonly property real strength: net ? Math.max(0, Math.min(1, net.signalStrength > 1 ? net.signalStrength / 100 : net.signalStrength)) : 0
    property bool compact: false

    Row {   // signal bars
        anchors.verticalCenter: parent.verticalCenter
        spacing: 2; height: 16
        Repeater {
            model: 4
            Rectangle {
                required property int index
                anchors.bottom: parent.bottom
                width: 4; height: 4 + index * 4
                color: root.net && root.strength > index / 4 + 0.05 ? (index === 3 ? Theme.accentA : Theme.text) : Theme.raised
            }
        }
    }
    Label {
        anchors.verticalCenter: parent.verticalCenter
        visible: !root.compact
        width: Math.min(implicitWidth, 110); elide: Text.ElideRight
        dim: false
        font.capitalization: Font.MixedCase
        text: root.net ? root.net.name : (root.wifiDevice ? "OFFLINE" : "WIRED")
    }
    Column {
        anchors.verticalCenter: parent.verticalCenter
        Label { font.pixelSize: 10; text: "↓ " + SysStats.human(SysStats.rxRate); color: SysStats.rxRate > 1e6 ? Theme.accentA : Theme.textDim }
        Label { font.pixelSize: 10; text: "↑ " + SysStats.human(SysStats.txRate); color: SysStats.txRate > 1e6 ? Theme.accentA : Theme.textDim }
    }
}
