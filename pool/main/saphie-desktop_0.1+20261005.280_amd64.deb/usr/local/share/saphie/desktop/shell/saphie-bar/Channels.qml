import QtQuick

// Workspaces as TV channels: CH 01, CH 02 ... for one output.
Row {
    id: root
    property string output: ""
    spacing: 6
    height: 22

    Repeater {
        model: Niri.workspacesFor(root.output)
        delegate: Item {
            id: ch
            required property var modelData
            readonly property bool active: modelData.is_active
            readonly property bool occupied: Niri.occupied(modelData.id)
            width: label.implicitWidth + 16
            height: root.height
            scale: active ? 1.0 : 0.94
            Behavior on scale { NumberAnimation { duration: Theme.snapMs; easing.type: Easing.BezierSpline; easing.bezierCurve: Theme.snapCurve } }

            Rectangle {   // idle pill
                anchors.fill: parent
                radius: height / 2
                color: "transparent"
                visible: !ch.active
                border.width: 2
                border.color: ch.modelData.is_urgent ? Theme.danger : (ch.occupied ? Theme.text : Theme.raised)
            }
            Rectangle {   // active: skewed pulsing backing
                id: backing
                visible: ch.active
                x: -4; width: parent.width + 8; height: parent.height
                transform: Matrix4x4 {
                    matrix: Qt.matrix4x4(1, Theme.skew, 0, -Theme.skew * backing.height / 2,
                                         0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1)
                }
                color: Theme.accentA
                // Pulse only briefly after a switch: a constant animation would redraw both
                // screens at 165/180 Hz all the time (measured: ~14% of a core + niri load).
                SequentialAnimation on color {
                    id: pulse
                    running: false
                    loops: 2
                    ColorAnimation { to: Theme.accentB; duration: Theme.pulseMs; easing.type: Easing.InOutSine }
                    ColorAnimation { to: Theme.accentA; duration: Theme.pulseMs; easing.type: Easing.InOutSine }
                }
            }
            Rectangle {   // channel-change flash (static burst), 3 x 70 ms
                id: flash
                x: backing.x; width: backing.width; height: backing.height
                transform: Matrix4x4 {
                    matrix: Qt.matrix4x4(1, Theme.skew, 0, -Theme.skew * flash.height / 2,
                                         0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1)
                }
                color: "#e8ffb0"; opacity: 0      // flash: near-white green
                SequentialAnimation {
                    id: flashAnim
                    loops: 3
                    NumberAnimation { target: flash; property: "opacity"; to: 0.9; duration: 35 }
                    NumberAnimation { target: flash; property: "opacity"; to: 0; duration: 35 }
                }
            }
            onActiveChanged: if (active) { flashAnim.restart(); pulse.restart(); flip.restart(); }

            Label {
                id: label
                anchors.centerIn: parent
                // Channel number "flips" in from below when the channel becomes active.
                transform: Translate { id: flipT; y: 0 }
                SequentialAnimation {
                    id: flip
                    NumberAnimation { target: flipT; property: "y"; from: 9; to: 0; duration: 240; easing.type: Easing.OutBack; easing.overshoot: 2.0 }
                }
                text: "CH " + String(ch.modelData.idx).padStart(2, "0")
                dim: false
                color: ch.active ? Theme.onAccent : (ch.occupied ? Theme.text : "#8a8a8a")
                font.weight: ch.active ? Font.ExtraBold : Font.Medium
            }
            Rectangle {   // dot: a channel you added (stays when empty; right-click removes it)
                visible: !!ch.modelData.name
                anchors.horizontalCenter: parent.horizontalCenter; anchors.top: parent.bottom; anchors.topMargin: 1
                width: 4; height: 4; radius: 2
                color: ch.active ? Theme.accentA : Theme.textDim
            }
            MouseArea {
                anchors.fill: parent
                cursorShape: Qt.PointingHandCursor
                acceptedButtons: Qt.LeftButton | Qt.RightButton
                onClicked: ev => {
                    if (ev.button === Qt.RightButton) {
                        if (ch.modelData.name) { Sfx.play("close"); Niri.removeChannel(ch.modelData); }
                    } else Niri.focusWorkspace(ch.modelData.id);
                }
            }
        }
    }
    Item {   // "+": add a channel that stays (like a new desktop on Windows)
        width: 22; height: root.height
        Rectangle {
            anchors.fill: parent; radius: height / 2; color: "transparent"; border.width: 2
            border.color: addMa.containsMouse ? Theme.accentA : Theme.raised
        }
        Label { anchors.centerIn: parent; text: "+"; dim: false
                color: addMa.containsMouse ? Theme.accentA : "#8a8a8a"; font.weight: Font.ExtraBold }
        MouseArea { id: addMa; anchors.fill: parent; hoverEnabled: true; cursorShape: Qt.PointingHandCursor
                    onClicked: { Sfx.play("open"); Niri.addChannel(root.output); } }
    }

    // One workspace step per wheel notch (120); touchpads send many small deltas.
    property real wheelAcc: 0
    WheelHandler {
        onWheel: ev => {
            root.wheelAcc += ev.angleDelta.y;
            if (Math.abs(root.wheelAcc) < 120) return;
            root.wheelAcc > 0 ? Niri.focusWorkspaceUp() : Niri.focusWorkspaceDown();
            root.wheelAcc = 0;
        }
    }
}
