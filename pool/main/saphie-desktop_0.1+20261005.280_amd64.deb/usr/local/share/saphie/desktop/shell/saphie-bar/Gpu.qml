import QtQuick

// NVIDIA state on the bar without waking the GPU: SLEEP (dim) or ACTIVE (green, two pulses on wake).
// No endless pulse: the GPU is active exactly while 3D apps run, and a looping animation makes the
// bar and niri redraw every frame (~30% of a core at 165 Hz) and cost Blender playback FPS.
Row {
    id: root
    spacing: 6
    visible: SysStats.gpuState !== ""
    readonly property bool active: SysStats.gpuState === "active" || SysStats.gpuState === "resuming"
    Rectangle {   // chip
        anchors.verticalCenter: parent.verticalCenter
        width: 14; height: 14
        color: root.active ? Theme.accentA : "transparent"
        border.color: root.active ? Theme.bg : Theme.raised; border.width: 2
        transform: Matrix4x4 { matrix: Qt.matrix4x4(1, Theme.skew, 0, -Theme.skew * 7, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1) }
        SequentialAnimation on opacity {
            running: root.active; loops: 2
            NumberAnimation { to: 0.45; duration: 700; easing.type: Easing.InOutSine }
            NumberAnimation { to: 1; duration: 700; easing.type: Easing.InOutSine }
            onStopped: parent.opacity = 1
        }
    }
    Label { anchors.verticalCenter: parent.verticalCenter; text: "NV" }
    Label {
        anchors.verticalCenter: parent.verticalCenter
        dim: !root.active
        font.weight: Font.ExtraBold
        color: root.active ? Theme.accentA : Theme.textDim
        text: root.active ? "ACTIVE" : "SLEEP"
    }
}
