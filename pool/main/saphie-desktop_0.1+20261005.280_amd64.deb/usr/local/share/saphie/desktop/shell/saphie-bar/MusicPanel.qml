import Quickshell
import Quickshell.Services.Mpris
import QtQuick

// "Now playing" deck under the tape sticker (original Saphie design; ZZZ-inspired record/sleeve
// look): sleeve + spinning disc, italic title, seek line, transport with a green play plate.
// Animates only while open.
PopupWindow {
    id: deck
    required property var player          // MprisPlayer or null
    required property Item anchorItem
    required property var barWindow

    anchor.window: barWindow
    anchor.item: anchorItem
    anchor.edges: Edges.Bottom
    anchor.gravity: Edges.Bottom
    anchor.margins.top: 10
    implicitWidth: 500
    implicitHeight: 262
    color: "transparent"
    grabFocus: true

    function toggle() {
        if (closing) return;
        if (visible) { Sfx.play("close"); closing = true; closeAnim.restart(); }
        else { Sfx.play("open"); drop.y = 0; body.opacity = 1; visible = true; }
    }
    onVisibleChanged: if (visible) openAnim.restart()
    onPlayerChanged: if (!player) visible = false

    readonly property bool playing: player?.isPlaying ?? false
    function fmt(s) {
        if (!isFinite(s) || s < 0) return "--:--";
        const m = Math.floor(s / 60), r = Math.floor(s % 60);
        return String(m).padStart(2, "0") + ":" + String(r).padStart(2, "0");
    }
    // Only local files and https covers (trust nothing a player sends).
    readonly property string art: {
        const u = player?.trackArtUrl ?? "";
        return /^(file|https):\/\//.test(u) ? u : "";
    }

    Timer {   // MPRIS does not push the position
        running: deck.visible && deck.playing
        interval: 500; repeat: true
        onTriggered: deck.player.positionChanged()
    }

    Item {
        id: body
        anchors.fill: parent
        anchors.topMargin: 16; anchors.rightMargin: 8; anchors.bottomMargin: 8
        transform: Translate { id: drop; y: 0 }

        Rectangle { x: 6; y: 6; width: parent.width; height: parent.height; color: Theme.bg; radius: 0 }   // hard shadow
        Rectangle {                                                                                          // card
            anchors.fill: parent
            color: Theme.surface
            border.color: Theme.bg; border.width: 2
            topLeftRadius: Theme.corner; topRightRadius: Theme.corner; bottomLeftRadius: Theme.corner; bottomRightRadius: 0
            Rectangle { anchors.fill: parent; anchors.margins: 2; color: "transparent"; border.color: Theme.ring; border.width: 3
                        topLeftRadius: Theme.corner - 2; topRightRadius: Theme.corner - 2; bottomLeftRadius: Theme.corner - 2 }
        }

        // Background motion (only while open + playing): scrolling caution stripes + scan sweep.
        Item {
            id: bg
            anchors.fill: parent; anchors.margins: 5
            clip: true
            readonly property bool live: deck.visible && deck.playing
            Row {
                id: stripes
                y: -20; height: parent.height + 40
                spacing: 14
                Repeater {
                    model: Math.ceil((bg.width + 120) / 28) + 2
                    Rectangle { width: 14; height: stripes.height; color: Theme.accentA; opacity: 0.05; rotation: 35 }
                }
                NumberAnimation on x { running: bg.live; from: 0; to: -28; duration: 900; loops: Animation.Infinite }
            }
            Rectangle {   // scan sweep
                id: sweep
                width: parent.width; height: 26
                gradient: Gradient {
                    GradientStop { position: 0; color: "#00ffffff" }
                    GradientStop { position: 0.5; color: "#14ffffff" }
                    GradientStop { position: 1; color: "#00ffffff" }
                }
                NumberAnimation on y { running: bg.live; from: -26; to: bg.height; duration: 2400; loops: Animation.Infinite }
                visible: bg.live
            }
        }

        // Green skewed tab
        Rectangle {
            id: tab
            x: 22; y: -12; width: 168; height: 26
            color: Theme.accentA
            SequentialAnimation on color {
                running: deck.visible && deck.playing
                loops: Animation.Infinite
                ColorAnimation { to: Theme.accentB; duration: Theme.pulseMs; easing.type: Easing.InOutSine }
                ColorAnimation { to: Theme.accentA; duration: Theme.pulseMs; easing.type: Easing.InOutSine }
                onStopped: tab.color = Theme.accentA
            }
            border.color: Theme.bg; border.width: 2
            transform: Matrix4x4 { matrix: Qt.matrix4x4(1, Theme.skew, 0, -Theme.skew * 13, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1) }
            Text {
                anchors.centerIn: parent
                text: deck.playing ? "NOW PLAYING" : "PAUSED"
                color: Theme.onAccent
                font.family: Theme.labelFont; font.pixelSize: 11; font.weight: Font.ExtraBold; font.letterSpacing: 1.6
            }
        }

        // Disc peeking out from behind the sleeve; spins only while open and playing.
        Item {
            id: disc
            x: 22 + (deck.playing ? 60 : 18); y: 38
            Behavior on x { NumberAnimation { duration: 420; easing.type: Easing.OutBack; easing.overshoot: 1.6 } }
            width: 128; height: 128
            Item {
                id: platter
                anchors.fill: parent
                Rectangle { anchors.fill: parent; radius: width / 2; color: "#0b0b0b"; border.color: "#2c2c2c"; border.width: 1 }
                Repeater {   // grooves
                    model: 5
                    Rectangle { anchors.centerIn: parent; width: 118 - index * 14; height: width; radius: width / 2
                                color: "transparent"; border.color: index % 2 ? "#1a1a1a" : "#222222"; border.width: 1 }
                }
                Rectangle {   // label
                    anchors.centerIn: parent; width: 46; height: 46; radius: 23; color: Theme.accentA
                    Rectangle { anchors.centerIn: parent; width: 46; height: 6; color: Theme.bg }        // stripe
                    Rectangle { x: 9; y: 8; width: 7; height: 7; radius: 3.5; color: Theme.bg }          // dot
                    Rectangle { x: 30; y: 31; width: 9; height: 4; color: Theme.bg; rotation: 30 }        // dash
                }
                Rectangle { anchors.centerIn: parent; width: 6; height: 6; radius: 3; color: "#d0d0d0" }  // spindle
                RotationAnimation on rotation {
                    running: deck.visible && deck.playing
                    from: platter.rotation; to: platter.rotation + 360
                    duration: 1800; loops: Animation.Infinite
                }
            }
            Rectangle {   // fixed sheen (does not rotate), makes the spin readable
                anchors.fill: parent; radius: width / 2
                gradient: Gradient {
                    orientation: Gradient.Horizontal
                    GradientStop { position: 0.30; color: "#00ffffff" }
                    GradientStop { position: 0.48; color: "#16ffffff" }
                    GradientStop { position: 0.62; color: "#00ffffff" }
                }
            }
            Item {   // tonearm: swings onto the record while playing
                id: arm
                x: 112; y: -6; width: 10; height: 10
                rotation: deck.playing ? 0 : -34
                Behavior on rotation { NumberAnimation { duration: 520; easing.type: Easing.OutBack; easing.overshoot: 2.0 } }
                transformOrigin: Item.Center
                Rectangle { anchors.centerIn: parent; width: 14; height: 14; radius: 7; color: "#3a3a3a"; border.color: Theme.bg; border.width: 2 }
                Rectangle {   // arm
                    x: 1; y: 6; width: 5; height: 70; color: "#bdbdbd"; rotation: 18; transformOrigin: Item.Top
                    Rectangle { x: -4; y: 62; width: 13; height: 12; color: Theme.accentA; border.color: Theme.bg; border.width: 2 }  // head
                }
            }
        }

        // Cover sleeve (wipes diagonally on track change)
        Rectangle {
            id: sleeve
            x: 22; y: 34; width: 136; height: 136
            color: "#1a1a1a"
            border.color: Theme.bg; border.width: 3
            clip: true
            Image {
                id: cover
                anchors.fill: parent; anchors.margins: 3
                source: deck.art
                fillMode: Image.PreserveAspectCrop
                asynchronous: true
                sourceSize.width: 260; sourceSize.height: 260
                visible: status === Image.Ready
            }
            Text {   // no cover: big italic channel mark
                anchors.centerIn: parent
                visible: !cover.visible
                text: "♪"
                color: Theme.raised
                font.pixelSize: 64
            }
            Rectangle {   // diagonal wipe
                id: wipe
                visible: trackAnim.running
                width: parent.width * 1.6; height: parent.height * 1.6
                color: Theme.accentA
                rotation: -30
                x: -width
                y: -parent.height * 0.3
            }
        }

        // Title + meta
        Column {
            x: 222; y: 28
            width: parent.width - 222 - 18
            spacing: 2
            Text {
                id: title
                width: parent.width
                text: deck.player?.trackTitle || deck.player?.identity || "NO SIGNAL"
                color: Theme.text
                elide: Text.ElideRight
                font.family: Theme.fontFor(text, Theme.numeralFont); font.weight: Font.ExtraBold
                font.italic: !Theme.nonLatin(text)
                font.pixelSize: Theme.nonLatin(text) ? 22 : 28
                height: 34; verticalAlignment: Text.AlignVCenter
                transform: Translate { id: titleT; x: 0 }
            }
            Label {
                width: parent.width
                elide: Text.ElideRight
                text: [deck.player?.trackArtist, deck.player?.trackAlbum].filter(s => s).join(" · ") || (deck.player?.identity ?? "")
                font.family: Theme.fontFor(text, Theme.labelFont)
                font.letterSpacing: Theme.nonLatin(text) ? 0 : 0.9
            }
        }

        // Seek line
        Item {
            x: 222; y: 112
            width: parent.width - 222 - 18; height: 22
            readonly property real frac: {
                const p = deck.player;
                return p && p.lengthSupported && p.length > 0 ? Math.max(0, Math.min(1, p.position / p.length)) : 0;
            }
            Rectangle { y: 9; width: parent.width; height: 3; color: Theme.ring }
            Rectangle { y: 9; width: parent.width * parent.frac; height: 3; color: Theme.accentA }
            Rectangle {   // diamond thumb
                width: 11; height: 11; rotation: 45; color: Theme.accentA; border.color: Theme.bg; border.width: 2
                x: parent.width * parent.frac - 5; y: 5
            }
            MouseArea {
                anchors.fill: parent
                enabled: deck.player?.canSeek ?? false
                cursorShape: enabled ? Qt.PointingHandCursor : Qt.ArrowCursor
                onClicked: ev => { const p = deck.player; if (p && p.length > 0) p.position = p.length * ev.x / width; }
            }
            Label {
                anchors.right: parent.right; y: -10
                font.pixelSize: 10
                text: deck.fmt(deck.player?.position ?? -1) + " / " + deck.fmt(deck.player?.length ?? -1)
            }
        }

        // Transport
        Row {
            x: 222; y: 150
            spacing: 6
            component Btn: Rectangle {
                id: btn
                property string glyph
                property bool on: false
                property bool enabledBtn: true
                signal hit()
                width: 38; height: 34
                color: on ? Theme.accentA : Theme.bg
                border.color: on ? Theme.bg : Theme.ring; border.width: 2
                opacity: enabledBtn ? 1 : 0.35
                scale: ma.pressed ? 0.9 : (ma.containsMouse ? 1.08 : 1)
                Behavior on scale { NumberAnimation { duration: 150; easing.type: Easing.OutBack; easing.overshoot: 2.4 } }
                Text { anchors.centerIn: parent; text: btn.glyph; color: btn.on ? Theme.onAccent : Theme.text; font.pixelSize: 15; font.weight: Font.Bold }
                MouseArea { id: ma; anchors.fill: parent; hoverEnabled: true; enabled: btn.enabledBtn; onClicked: btn.hit() }
            }
            Btn {
                glyph: "⇄"; on: deck.player?.shuffle ?? false
                enabledBtn: deck.player?.shuffleSupported ?? false
                onHit: deck.player.shuffle = !deck.player.shuffle
            }
            Btn { glyph: "⏮"; enabledBtn: deck.player?.canGoPrevious ?? false; onHit: deck.player.previous() }
            Rectangle {   // play/pause: green skewed plate
                width: 64; height: 34
                color: Theme.accentA
                border.color: Theme.bg; border.width: 2
                transform: Matrix4x4 { matrix: Qt.matrix4x4(1, Theme.skew, 0, -Theme.skew * 17, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1) }
                scale: pm.pressed ? 0.9 : (pm.containsMouse ? 1.08 : 1)
                Behavior on scale { NumberAnimation { duration: 150; easing.type: Easing.OutBack; easing.overshoot: 2.4 } }
                Text { anchors.centerIn: parent; text: deck.playing ? "❚❚" : "▶"; color: Theme.onAccent; font.pixelSize: 16; font.weight: Font.Black }
                MouseArea { id: pm; anchors.fill: parent; hoverEnabled: true
                            onClicked: if (deck.player?.canTogglePlaying) deck.player.togglePlaying() }
            }
            Btn { glyph: "⏭"; enabledBtn: deck.player?.canGoNext ?? false; onHit: deck.player.next() }
            Btn {
                glyph: (deck.player?.loopState ?? 0) === MprisLoopState.Track ? "↻1" : "↻"
                on: (deck.player?.loopState ?? MprisLoopState.None) !== MprisLoopState.None
                enabledBtn: deck.player?.loopSupported ?? false
                onHit: {
                    const s = deck.player.loopState;
                    deck.player.loopState = s === MprisLoopState.None ? MprisLoopState.Playlist
                                          : s === MprisLoopState.Playlist ? MprisLoopState.Track : MprisLoopState.None;
                }
            }
        }
        Label {   // player name without snap/flatpak suffixes ("Mozilla firefox_firefox" -> "MOZILLA FIREFOX")
            x: 222; y: 200; width: parent.width - 222 - 18; elide: Text.ElideRight; font.pixelSize: 10
            text: (deck.player?.identity ?? "").replace(/_[A-Za-z0-9.-]+$/, "").toUpperCase()
        }
    }

    // Open: drop in with overshoot
    SequentialAnimation {
        id: openAnim
        ParallelAnimation {
            NumberAnimation { target: drop; property: "y"; from: -18; to: 0; duration: 260; easing.type: Easing.OutBack; easing.overshoot: 1.6 }
            NumberAnimation { target: body; property: "opacity"; from: 0; to: 1; duration: 120 }
        }
    }
    // Track change: diagonal green wipe over the sleeve, title slides in
    Connections {
        target: deck.player
        function onTrackTitleChanged() { if (deck.visible) trackAnim.restart(); }
    }
    ParallelAnimation {
        id: trackAnim
        SequentialAnimation {
            NumberAnimation { target: wipe; property: "x"; from: -wipe.width; to: sleeve.width; duration: 260; easing.type: Easing.InOutQuad }
            ScriptAction { script: wipe.x = -wipe.width }
        }
        NumberAnimation { target: titleT; property: "x"; from: 24; to: 0; duration: 260; easing.type: Easing.OutBack }
    }

    // Close animation: lift + fade (reverse of the drop-in), then hide.
    property bool closing: false
    SequentialAnimation {
        id: closeAnim
        ParallelAnimation {
            NumberAnimation { target: drop; property: "y"; to: -18; duration: 150; easing.type: Easing.InBack; easing.overshoot: 1.4 }
            NumberAnimation { target: body; property: "opacity"; to: 0; duration: 150; easing.type: Easing.InQuad }
        }
        ScriptAction { script: { deck.closing = false; deck.visible = false; drop.y = 0; body.opacity = 1; } }
    }
}
