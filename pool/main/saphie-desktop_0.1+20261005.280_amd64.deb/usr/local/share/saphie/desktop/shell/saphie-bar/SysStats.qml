pragma Singleton
import Quickshell
import Quickshell.Io
import QtQuick

// CPU usage and network throughput from the kernel (/proc/stat, /proc/net/dev), every 2 s.
// Values read are validated; bad reads are skipped.
Singleton {
    id: root
    property real cpu: 0                 // 0..1
    property var cpuHistory: []          // last 30 samples
    property real rxRate: 0              // bytes/s
    property real txRate: 0
    property var prevCpu: null
    property var prevNet: null
    property real prevTime: 0
    // CPU temperature (°C, -1 = unknown) from the CPU's hwmon sensor, found by name at start:
    // hwmonN numbers can change between boots. AMD k10temp/zenpower (Tctl) or Intel coretemp.
    property real cpuTemp: -1
    property string tempPath: ""
    Process {
        running: true
        command: ["sh", "-c", "for h in /sys/class/hwmon/hwmon*; do case \"$(cat $h/name 2>/dev/null)\" in " +
                  "k10temp|zenpower|coretemp) echo $h/temp1_input; exit;; esac; done"]
        stdout: SplitParser { onRead: l => {
            if (/^\/sys\/class\/hwmon\/hwmon[0-9]+\/temp1_input$/.test(l.trim())) root.tempPath = l.trim();
        } }
    }
    FileView { id: tempf; path: root.tempPath; printErrors: false; blockLoading: true }

    FileView { id: stat; path: "/proc/stat"; printErrors: false; blockLoading: true }
    // NVIDIA runtime power state from sysfs: reading it never wakes the GPU (nvidia-smi would).
    property string gpuState: ""         // "suspended" | "active" | "" (no NVIDIA GPU)
    FileView { id: nvpm; path: "/sys/bus/pci/devices/0000:01:00.0/power/runtime_status"; printErrors: false; blockLoading: true }
    FileView { id: netdev; path: "/proc/net/dev"; printErrors: false; blockLoading: true }

    function human(bps) {
        const u = ["B", "K", "M", "G"];
        let v = Math.max(0, bps), i = 0;
        while (v >= 1000 && i < u.length - 1) { v /= 1024; i++; }
        return (v >= 100 || i === 0 ? Math.round(v) : v.toFixed(1)) + u[i];
    }

    function sample() {
        stat.reload(); netdev.reload(); nvpm.reload();
        stat.waitForJob(); netdev.waitForJob(); nvpm.waitForJob();
        if (tempPath) {
            tempf.reload(); tempf.waitForJob();
            const mc = parseInt((tempf.text() || "").trim(), 10);     // millidegrees
            if (Number.isFinite(mc) && mc > 0 && mc < 150000) cpuTemp = mc / 1000;
        }
        const st = (nvpm.text() || "").trim();
        gpuState = /^(suspended|active|suspending|resuming)$/.test(st) ? st : "";
        const now = Date.now() / 1000;
        // CPU: first line "cpu  user nice system idle iowait irq softirq steal ..."
        const line = (stat.text() || "").split("\n")[0];
        const f = line.trim().split(/\s+/);
        if (f[0] === "cpu" && f.length >= 8) {
            const v = f.slice(1, 9).map(x => Number(x));
            if (v.every(x => Number.isFinite(x) && x >= 0)) {
                const idle = v[3] + v[4], total = v.reduce((a, b) => a + b, 0);
                if (prevCpu) {
                    const dt = total - prevCpu.total, di = idle - prevCpu.idle;
                    if (dt > 0) {
                        cpu = Math.max(0, Math.min(1, 1 - di / dt));
                        const h = cpuHistory.slice(-29); h.push(cpu); cpuHistory = h;
                    }
                }
                prevCpu = { total: total, idle: idle };
            }
        }
        // Network: sum of all interfaces except loopback and virtual bridges
        let rx = 0, tx = 0, ok = false;
        for (const l of (netdev.text() || "").split("\n").slice(2)) {
            const m = l.match(/^\s*([^:\s]+):\s*(.*)$/);
            if (!m || m[1] === "lo" || /^(docker|veth|virbr|br-)/.test(m[1])) continue;
            const n = m[2].trim().split(/\s+/).map(Number);
            if (n.length >= 9 && Number.isFinite(n[0]) && Number.isFinite(n[8])) { rx += n[0]; tx += n[8]; ok = true; }
        }
        if (ok) {
            if (prevNet && now > prevTime) {
                rxRate = Math.max(0, (rx - prevNet.rx) / (now - prevTime));
                txRate = Math.max(0, (tx - prevNet.tx) / (now - prevTime));
            }
            prevNet = { rx: rx, tx: tx };
        }
        prevTime = now;
    }
    Timer { interval: 2000; running: true; repeat: true; triggeredOnStart: true; onTriggered: root.sample() }
}
