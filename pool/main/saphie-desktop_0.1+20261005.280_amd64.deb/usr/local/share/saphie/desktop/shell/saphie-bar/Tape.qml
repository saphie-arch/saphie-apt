import Quickshell.Services.Mpris
import QtQuick

// Now playing as a cassette: reels spin only while playing, caution-stripe progress.
// Click: play/pause. Right click: next. Always shown: "NO TAPE" (dim) when no player exists.
Row {
    id: root
    readonly property var players: Mpris.players.values
    readonly property var player: players.find(p => p.isPlaying) ?? players[0] ?? null
    property bool compact: false       // slim bar: shorter title and progress line
    readonly property int textWidth: compact ? 110 : 150
    spacing: 8

    Timer {   // MPRIS position is not pushed; ask for it while playing
        running: root.player?.isPlaying ?? false
        interval: 1000; repeat: true
        onTriggered: root.player.positionChanged()
    }

    Repeater {
        model: 1          // one reel (user choice)
        Rectangle {
            anchors.verticalCenter: parent.verticalCenter
            width: 14; height: 14; radius: 7
            color: "transparent"
            border.width: 2; border.color: Theme.text
            Rectangle { width: 4; height: 4; radius: 2; color: Theme.text; anchors.centerIn: parent }
            Rectangle { width: 2; height: 5; color: Theme.surface; anchors.horizontalCenter: parent.horizontalCenter; y: 0 }
            // Stepped spin (8 steps/s, one turn per 4 s): cheap redraws, VHS feel.
            Timer {
                running: root.player?.isPlaying ?? false
                interval: 125; repeat: true
                onTriggered: parent.rotation = (parent.rotation + 11.25) % 360
            }
        }
    }
    Column {
        anchors.verticalCenter: parent.verticalCenter
        spacing: 3
        Label {
            id: titleLabel
            width: root.textWidth
            height: 13                               // fixed line: tall fallback fonts stay centred
            verticalAlignment: Text.AlignVCenter
            elide: Text.ElideRight
            dim: root.player === null
            font.pixelSize: 10
            font.family: Theme.fontFor(text, Theme.labelFont)
            font.letterSpacing: Theme.nonLatin(text) ? 0 : 0.9
            text: {
                const p = root.player;
                if (!p) return "NO TAPE";
                const t = p.trackTitle || p.identity || "TAPE";
                return p.trackArtist ? t + " · " + p.trackArtist : t;
            }
        }
        Rectangle {   // progress
            width: root.textWidth; height: 5; color: Theme.ring; clip: true
            readonly property real frac: {
                const p = root.player;
                return p && p.lengthSupported && p.length > 0 ? Math.max(0, Math.min(1, p.position / p.length)) : 0;
            }
            Item {
                width: parent.width * parent.frac; height: parent.height; clip: true
                Row {
                    x: -4
                    Repeater {
                        model: 40
                        Rectangle {
                            width: 4; height: 12; y: -4
                            color: index % 2 ? Theme.bg : Theme.accentA
                            rotation: 45
                        }
                    }
                }
            }
        }
    }

    // Left: open the deck (handled by the bar). Middle: play/pause. Right: next.
    function click(button) {
        const p = root.player;
        if (!p) return;
        if (button === Qt.RightButton) { if (p.canGoNext) p.next(); }
        else if (button === Qt.MiddleButton) { if (p.canTogglePlaying) p.togglePlaying(); }
    }
}
