import Quickshell
import Quickshell.Services.SystemTray
import QtQuick

// System tray, collapsed like Windows' "show hidden icons": the bar only shows a "▾ N" button
// (N = background apps: WARP, Discord, Steam, network...) plus the icon of any app that needs
// attention. Click the button: a drop-down lists every app (TrayMenu): left click = the app's
// main action, right click or "⋯" = its options menu. Right click an attention icon = its menu.
Row {
    id: root
    required property var barWindow
    readonly property var items: SystemTray.items.values
    readonly property var urgent: items.filter(i => i.status === Status.NeedsAttention).slice(0, 2)
    spacing: 8

    function toggle() {
        if (menu.visible) menu.close();
        else { Sfx.play("open"); menu.openApps(button); }
    }

    Repeater {   // apps that need attention stay visible on the bar
        model: root.urgent
        Item {
            id: slot
            required property var modelData
            width: 20; height: 20
            anchors.verticalCenter: parent.verticalCenter
            scale: area.pressed ? 0.85 : (area.containsMouse ? 1.15 : 1.0)
            Behavior on scale { NumberAnimation { duration: 160; easing.type: Easing.OutBack; easing.overshoot: 2 } }
            Image {
                anchors.fill: parent
                source: slot.modelData.icon
                sourceSize.width: 40; sourceSize.height: 40
            }
            Rectangle {
                width: 6; height: 6; radius: 3
                anchors.right: parent.right; anchors.top: parent.top
                color: Theme.accentA; border.color: Theme.bg; border.width: 1
            }
            MouseArea {
                id: area
                anchors.fill: parent
                hoverEnabled: true
                acceptedButtons: Qt.LeftButton | Qt.RightButton | Qt.MiddleButton
                onClicked: ev => {
                    const it = slot.modelData;
                    if (ev.button === Qt.MiddleButton) it.secondaryActivate();
                    else if ((ev.button === Qt.RightButton || it.onlyMenu) && it.hasMenu) { Sfx.play("open"); menu.openFor(it, slot); }
                    else it.activate();
                }
                onWheel: ev => slot.modelData.scroll(ev.angleDelta.y / 120, false)
            }
        }
    }

    Item {   // "▾ N" button: opens the list of all tray apps
        id: button
        width: label.implicitWidth + 4; height: 20
        anchors.verticalCenter: parent.verticalCenter
        scale: bMouse.pressed ? 0.88 : (bMouse.containsMouse ? 1.08 : 1.0)
        Behavior on scale { NumberAnimation { duration: 160; easing.type: Easing.OutBack; easing.overshoot: 2 } }
        Text {
            id: label
            anchors.centerIn: parent
            text: (menu.visible ? "▴ " : "▾ ") + root.items.length
            color: menu.visible || bMouse.containsMouse ? Theme.accentA : Theme.text
            font.family: Theme.labelFont; font.pixelSize: 13; font.weight: Font.ExtraBold; font.letterSpacing: 1
        }
        MouseArea {
            id: bMouse
            anchors.fill: parent; anchors.margins: -8
            hoverEnabled: true
            acceptedButtons: Qt.LeftButton | Qt.RightButton
            onClicked: root.toggle()
        }
    }

    TrayMenu {
        id: menu
        barWindow: root.barWindow
        apps: root.items
    }
}
