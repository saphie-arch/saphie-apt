import Quickshell
import Quickshell.Services.Notifications
import QtQuick

// History of notifications under the bell sticker: newest first, CLEAR ALL, Do Not Disturb.
PopupWindow {
    id: panel
    required property Item anchorItem
    required property var barWindow
    anchor.window: barWindow
    anchor.item: anchorItem
    anchor.edges: Edges.Bottom
    anchor.gravity: Edges.Bottom
    anchor.margins.top: 10
    implicitWidth: 400
    implicitHeight: 480
    color: "transparent"
    grabFocus: true
    function toggle() {
        if (closing) return;
        if (visible) { Sfx.play("close"); closing = true; closeAnim.restart(); }
        else { Sfx.play("open"); drop.y = 0; body.opacity = 1; visible = true; }
    }
    onVisibleChanged: if (visible) { Notifs.unread = 0; Notifs.threads = []; Notifs.appNotes = []; openAnim.restart(); }

    Item {
        id: body
        anchors.fill: parent
        anchors.topMargin: 16; anchors.rightMargin: 8; anchors.bottomMargin: 8
        transform: Translate { id: drop; y: 0 }
        Rectangle { x: 6; y: 6; width: parent.width; height: parent.height; color: Theme.bg }
        Rectangle {
            anchors.fill: parent
            color: Theme.surface; border.color: Theme.bg; border.width: 2
            topLeftRadius: Theme.corner; topRightRadius: Theme.corner; bottomLeftRadius: Theme.corner; bottomRightRadius: 0
            Rectangle { anchors.fill: parent; anchors.margins: 2; color: "transparent"; border.color: Theme.ring; border.width: 3
                        topLeftRadius: Theme.corner - 2; topRightRadius: Theme.corner - 2; bottomLeftRadius: Theme.corner - 2 }
        }
        Rectangle {
            x: 18; y: -12; width: 128; height: 26
            color: Theme.accentA; border.color: Theme.bg; border.width: 2
            transform: Matrix4x4 { matrix: Qt.matrix4x4(1, Theme.skew, 0, -Theme.skew * 13, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1) }
            Text { anchors.centerIn: parent; text: "NOTIFICATIONS"; color: Theme.onAccent
                   font.family: Theme.labelFont; font.pixelSize: 10; font.weight: Font.ExtraBold; font.letterSpacing: 1.4 }
        }
        Row {   // DND + clear
            anchors.right: parent.right; anchors.rightMargin: 18; y: 26
            spacing: 10
            component Chip: Rectangle {
                id: chip
                property string label
                property bool on: false
                signal hit()
                width: t.implicitWidth + 22; height: 24
                color: on ? Theme.accentA : (m.containsMouse ? "#1f1f1f" : Theme.bg)
                border.color: on ? Theme.bg : Theme.ring; border.width: 2
                transform: Matrix4x4 { matrix: Qt.matrix4x4(1, Theme.skew, 0, -Theme.skew * 12, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1) }
                Text { id: t; anchors.centerIn: parent; text: chip.label; color: chip.on ? Theme.onAccent : Theme.textDim
                       font.family: Theme.labelFont; font.pixelSize: 10; font.weight: Font.ExtraBold; font.letterSpacing: 1 }
                MouseArea { id: m; anchors.fill: parent; hoverEnabled: true; onClicked: chip.hit() }
            }
            Chip { label: "DO NOT DISTURB"; on: Notifs.dnd; onHit: Notifs.dnd = !Notifs.dnd }
            Chip { label: "CLEAR ALL"; onHit: Notifs.clearAll() }
        }
        Flickable {
            x: 16; y: 64; width: parent.width - 32; height: parent.height - 80
            clip: true
            contentHeight: list.implicitHeight
            boundsBehavior: Flickable.StopAtBounds
            Column {
                id: list
                width: parent.width
                spacing: 6
                Repeater {
                    model: Notifs.history.slice().reverse()
                    Rectangle {
                        required property var modelData
                        width: list.width; height: col.implicitHeight + 16
                        color: m2.containsMouse ? "#1c1c1c" : "#141414"
                        border.color: modelData.urgency === NotificationUrgency.Critical ? Theme.danger : Theme.ring; border.width: 1
                        Column {
                            id: col
                            x: 12; y: 8; width: parent.width - 44
                            spacing: 2
                            Label { text: modelData.appName || "SYSTEM"; font.pixelSize: 10; color: Theme.accentA }
                            Text { width: parent.width; elide: Text.ElideRight; text: modelData.summary; textFormat: Text.PlainText
                                   color: Theme.text; font.family: Theme.labelFont; font.pixelSize: 13; font.weight: Font.Bold }
                            Text { width: parent.width; visible: text.length > 0; text: modelData.body; textFormat: Text.PlainText
                                   wrapMode: Text.WordWrap; maximumLineCount: 2; elide: Text.ElideRight
                                   color: Theme.textDim; font.family: Theme.labelFont; font.pixelSize: 11 }
                        }
                        MouseArea { id: m2; anchors.fill: parent; hoverEnabled: true; onClicked: Notifs.activate(modelData) }
                        Text { anchors.right: parent.right; anchors.rightMargin: 10; y: 8; text: "✕"
                               color: Theme.textDim; font.pixelSize: 12; font.weight: Font.Black
                               MouseArea { anchors.fill: parent; anchors.margins: -6; onClicked: Notifs.dismiss(modelData) } }
                    }
                }
                Text {
                    visible: Notifs.history.length === 0
                    text: "NO SIGNAL — ALL CLEAR"
                    color: Theme.textDim; font.family: Theme.labelFont; font.pixelSize: 12
                    topPadding: 20
                }
            }
        }
    }
    SequentialAnimation {
        id: openAnim
        ParallelAnimation {
            NumberAnimation { target: drop; property: "y"; from: -18; to: 0; duration: 260; easing.type: Easing.OutBack; easing.overshoot: 1.6 }
            NumberAnimation { target: body; property: "opacity"; from: 0; to: 1; duration: 120 }
        }
    }

    // Close animation: lift + fade (reverse of the drop-in), then hide.
    property bool closing: false
    SequentialAnimation {
        id: closeAnim
        ParallelAnimation {
            NumberAnimation { target: drop; property: "y"; to: -18; duration: 150; easing.type: Easing.InBack; easing.overshoot: 1.4 }
            NumberAnimation { target: body; property: "opacity"; to: 0; duration: 150; easing.type: Easing.InQuad }
        }
        ScriptAction { script: { panel.closing = false; panel.visible = false; drop.y = 0; body.opacity = 1; } }
    }
}
