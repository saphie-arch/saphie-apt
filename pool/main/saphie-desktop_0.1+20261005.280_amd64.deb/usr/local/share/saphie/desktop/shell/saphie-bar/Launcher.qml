import Quickshell
import Quickshell.Io
import Quickshell.Wayland
import QtQuick

// Saphie app launcher (original design, ZZZ-inspired menu screen): full-screen black with
// scanlines, indexed list on the left with a sliding green plate, detail card on the right,
// skewed search field with fuzzy matching, category chips, CRT switch-off on launch.
// Opened with Mod+D (desktop/bin/saphie-launcher -> IPC "launcher toggle").
PanelWindow {
    id: win
    required property var modelData
    screen: modelData
    property bool open: false
    visible: open
    color: "transparent"
    anchors { top: true; bottom: true; left: true; right: true }
    exclusionMode: ExclusionMode.Ignore
    WlrLayershell.layer: WlrLayer.Overlay
    WlrLayershell.namespace: "saphie-launcher"
    WlrLayershell.keyboardFocus: open ? WlrKeyboardFocus.Exclusive : WlrKeyboardFocus.None

    readonly property var categories: [
        { label: "ALL", match: [] },
        { label: "3D", match: ["Graphics", "3DGraphics"] },
        { label: "DEV", match: ["Development", "IDE"] },
        { label: "GAMES", match: ["Game"] },
        { label: "MEDIA", match: ["AudioVideo", "Audio", "Video"] }
    ]
    property int category: 0
    // Portrait monitor: stack search, card and list vertically instead of side by side.
    readonly property bool portrait: height > width
    readonly property int margin: portrait ? 40 : 64
    property string query: ""
    property bool launching: false

    function show() {
        // The list was already reset while hidden (hide()), so opening rebuilds nothing:
        // rebuilding every row here stalled the first frames of the wipe.
        if (closing) { closeAnim.stop(); closing = false; } 
        if (query !== "" || category !== 0) { query = ""; search.text = ""; category = 0; }
        launching = false;
        Sfx.play("open");
        open = true; list.currentIndex = 0;
        // Start the wipe only once the window is really on screen (first frame of a new layer
        // surface can take ~70 ms on the 165 Hz laptop panel); until then it shows the full cover.
        initOpen(); armed = true; armedFrames = 0; armTimer.restart();
        search.forceActiveFocus();
    }
    property bool armed: false
    property int armedFrames: 0
    function initOpen() {
        const tv = Theme.openStyle === "tv";
        screenRoot.scale = 1; screenRoot.opacity = 1; cardT.x = 80; wiper.x = -wiper.width * 0.2;
        tvScale.yScale = tv ? 0.004 : 1; tvLine.opacity = tv ? 1 : 0;
    }
    function startOpen() { if (!armed) return; armed = false; armTimer.stop(); openAnim.restart(); }
    Timer { id: armTimer; interval: 150; onTriggered: win.startOpen() }
    Connections { target: list.Window.window
        function onFrameSwapped() { if (win.armed && ++win.armedFrames >= 2) win.startOpen(); } }
    function hide(instant) {
        if (!open || closing) return;
        if (!launching) Sfx.play("close");
        armed = false; armTimer.stop();
        if (instant) finishClose(); else closeAnim.restart();
    }
    Timer { id: resetTimer; interval: 400; onTriggered: if (!win.open) { win.query = ""; search.text = ""; win.category = 0; list.currentIndex = 0; } }

    // Fuzzy subsequence score: higher is better, -1 = no match. Bonus for word starts and runs.
    function score(q, text) {
        if (!q) return 0;
        const t = text.toLowerCase();
        let s = 0, ti = 0, run = 0;
        for (let qi = 0; qi < q.length; qi++) {
            const c = q[qi];
            const at = t.indexOf(c, ti);
            if (at < 0) return -1;
            run = (at === ti && qi > 0) ? run + 1 : 0;
            s += 1 + run * 2 + ((at === 0 || " -_.".includes(t[at - 1])) ? 3 : 0) - Math.min(at - ti, 3) * 0.2;
            ti = at + 1;
        }
        return s + (t.startsWith(q) ? 5 : 0);
    }
    function positions(q, text) {   // matched character indices, for highlighting
        const t = text.toLowerCase(), out = [];
        let ti = 0;
        for (const c of q) { const at = t.indexOf(c, ti); if (at < 0) return []; out.push(at); ti = at + 1; }
        return out;
    }
    function esc(s) { return s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;"); }
    function highlighted(name) {
        const pos = positions(query.toLowerCase(), name);
        if (!query || pos.length === 0) return esc(name.toUpperCase());
        let out = "";
        for (let i = 0; i < name.length; i++) {
            const ch = esc(name[i].toUpperCase());
            out += pos.includes(i) ? "<font color='" + Theme.accentA + "'>" + ch + "</font>" : ch;
        }
        return out;
    }

    readonly property var apps: {
        const q = query.trim().toLowerCase();
        const cat = categories[category].match;
        const all = DesktopEntries.applications.values.filter(e => !e.noDisplay && e.name);
        const seen = {};
        const rows = [];
        for (const e of all) {
            if (seen[e.id]) continue;
            seen[e.id] = true;
            if (cat.length && !cat.some(c => (e.categories ?? []).includes(c))) continue;
            const sc = Math.max(score(q, e.name), score(q, e.genericName ?? "") - 2,
                                ...(e.keywords ?? []).map(k => score(q, k) - 3));
            if (sc < 0) continue;
            rows.push({ entry: e, score: sc });
        }
        rows.sort((a, b) => q ? b.score - a.score : a.entry.name.localeCompare(b.entry.name));
        return rows.slice(0, 60);
    }
    readonly property var current: apps.length > 0 && list.currentIndex >= 0 ? apps[Math.min(list.currentIndex, apps.length - 1)].entry : null

    // Apps that always start on the NVIDIA GPU (~/.config/saphie/gpu-apps.json, ids only).
    property var nvApps: []
    FileView {
        id: gpuPrefs
        path: (Quickshell.env("HOME") ?? "") + "/.config/saphie/gpu-apps.json"
        printErrors: false
        onLoaded: {
            try { const d = JSON.parse(text()); win.nvApps = Array.isArray(d.nvidia) ? d.nvidia.filter(x => typeof x === "string").slice(0, 200) : []; }
            catch (e) { win.nvApps = []; }
        }
    }
    function isNv(e) { return e !== null && nvApps.includes(e.id); }
    function toggleNv(e) {
        if (!e) return;
        nvApps = isNv(e) ? nvApps.filter(x => x !== e.id) : nvApps.concat([e.id]);
        gpuPrefs.setText(JSON.stringify({ nvidia: nvApps }, null, 2) + "\n");
    }
    // PRIME render offload: Vulkan (optimus layer), GLX and EGL apps render on the NVIDIA GPU,
    // the AMD iGPU keeps driving the screens.
    readonly property var nvEnv: ["__NV_PRIME_RENDER_OFFLOAD=1", "__GLX_VENDOR_LIBRARY_NAME=nvidia",
                                  "__VK_LAYER_NV_optimus=NVIDIA_only",
                                  "__EGL_VENDOR_LIBRARY_FILENAMES=/usr/share/glvnd/egl_vendor.d/10_nvidia.json"]

    // An app that already has a window is focused instead of started again (Enter / click).
    // Match: desktop file id, StartupWMClass or program name against niri's window app_id,
    // ignoring case, ".desktop" and the snap "name_" prefix (e.g. firefox_firefox -> firefox).
    function norm(s) { s = String(s ?? "").toLowerCase().replace(/\.desktop$/, ""); const i = s.lastIndexOf("_"); return [s, i > 0 ? s.slice(i + 1) : s]; }
    function runningWindow(e) {
        const keys = new Set();
        // Entries that launch a link (steam://rungameid/..., https://...) are games/sites, not the
        // program itself: never match them by program name, or a game would just focus Steam.
        const viaLink = (e.command ?? []).some(x => String(x).includes("://"));
        for (const v of [e.id, e.startupClass, viaLink ? "" : (e.command?.[0] ?? "").split("/").pop()])
            if (v) for (const k of norm(v)) keys.add(k);
        let best = null;
        for (const k in Niri.windows) {
            const w = Niri.windows[k];
            if (!w.app_id) continue;
            if (norm(w.app_id).some(a => keys.has(a))) { if (!best || w.is_focused) best = w; }
        }
        return best;
    }
    function launch(forceNv, forceNew) {
        const e = current;
        if (!e || launching) return;
        if (!forceNv && !forceNew) {
            const w = runningWindow(e);
            if (w) {   // already open: jump to it
                launching = true;
                Sfx.play("confirm");
                Niri.send({ FocusWindow: { id: w.id } });
                launchAnim.restart();
                return;
            }
        }
        launching = true;
        Sfx.play("confirm");
        // Started by niri (Spawn), so niri shows the "app starting" cursor until its window
        // appears (saphie-startup-cursor.patch). Terminal apps / own working folder: execute().
        // Not connected to niri yet: start it the old way, so a click never starts nothing.
        let cmd = (e.command ?? []).map(String);
        // Heavy 3D apps run through bin/saphie-applog, which keeps what they print (crash
        // diagnosis, see bin/saphie-health); the app itself is unchanged.
        const heavy = cmd.length ? /^(blender|unity|unityhub|resolve)$/i.exec(cmd[0].split("/").pop()) : null;
        if (heavy) cmd = [Quickshell.shellDir + "/../../bin/saphie-applog", heavy[1].toLowerCase(), "--"].concat(cmd);
        const viaNiri = Niri.canSend && cmd.length > 0;
        if (forceNv || isNv(e)) {
            // "--" must come before the NAME=VALUE settings: after them env runs "--" as a program
            const nv = ["env", "--"].concat(nvEnv, cmd);
            if (viaNiri) Niri.send({ Spawn: { command: nv } }); else Quickshell.execDetached(nv);
        } else if (!viaNiri || e.runInTerminal || e.workingDirectory) e.execute();
        else Niri.send({ Spawn: { command: cmd } });
        launchAnim.restart();
    }

    // --- background
    Item {
        id: screenRoot
        anchors.fill: parent
        transform: Scale { id: tvScale; origin.x: screenRoot.width / 2; origin.y: screenRoot.height / 2; yScale: 1 }
        transformOrigin: Item.Center

        Rectangle { anchors.fill: parent; color: "#eb000000" }
        Canvas {   // static scanlines, drawn once
            anchors.fill: parent
            opacity: 0.05
            onPaint: {
                const ctx = getContext("2d");
                ctx.fillStyle = "#ffffff";
                for (let y = 0; y < height; y += 3) ctx.fillRect(0, y, width, 1);
            }
        }
        MouseArea { anchors.fill: parent; onClicked: win.hide() }   // click outside = close

        // --- header
        Text {
            x: win.margin; y: 48
            text: "CH ▸ APPS"
            color: Theme.text
            font.family: Theme.titleFont; font.pixelSize: 22
        }
        Rectangle {   // open-style toggle (click or F2): plays the new style right away
            id: styleChip
            x: win.margin + 170; y: 48
            width: styleText.implicitWidth + 24; height: 24
            color: "transparent"
            border.color: styleMouse.containsMouse ? Theme.accentA : Theme.raised; border.width: 2
            transform: Matrix4x4 { matrix: Qt.matrix4x4(1, Theme.skew, 0, -Theme.skew * 12, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1) }
            Text {
                id: styleText
                anchors.centerIn: parent
                text: "OPEN ▸ " + Theme.openStyle.toUpperCase() + "   F2"
                color: styleMouse.containsMouse ? Theme.accentA : Theme.textDim
                font.family: Theme.labelFont; font.pixelSize: 11; font.weight: Font.ExtraBold; font.letterSpacing: 1.2
            }
            MouseArea { id: styleMouse; anchors.fill: parent; hoverEnabled: true
                        onClicked: { Theme.toggleOpenStyle(); openAnim.restart(); search.forceActiveFocus(); } }
        }
        Text {
            anchors.right: parent.right; anchors.rightMargin: win.margin; y: 40
            text: Qt.formatDateTime(clockTick.date, "HH:mm")
            color: Theme.text
            font.family: Theme.numeralFont; font.weight: Font.ExtraBold; font.italic: true; font.pixelSize: 40
            SystemClock { id: clockTick; precision: SystemClock.Minutes }
        }

        // --- search field (skewed outline, block caret)
        Item {
            id: searchBox
            x: win.margin; y: 100
            width: win.portrait ? parent.width - 2 * win.margin : Math.min(parent.width * 0.42, 640); height: 54
            Rectangle {
                anchors.fill: parent
                color: "#101010"
                border.color: search.activeFocus ? Theme.accentA : Theme.ring; border.width: 3
                transform: Matrix4x4 { matrix: Qt.matrix4x4(1, Theme.skew, 0, -Theme.skew * 27, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1) }
            }
            Text {
                x: 22; anchors.verticalCenter: parent.verticalCenter
                visible: search.text.length === 0
                text: "TYPE TO TUNE"
                color: Theme.raised
                font.family: Theme.labelFont; font.pixelSize: 18; font.letterSpacing: 2
            }
            TextInput {
                id: search
                x: 22; width: parent.width - 44; anchors.verticalCenter: parent.verticalCenter
                color: Theme.text
                font.family: Theme.labelFont; font.pixelSize: 20; font.capitalization: Font.AllUppercase
                selectionColor: Theme.accentA; selectedTextColor: Theme.onAccent
                cursorDelegate: Rectangle {
                    width: 11; color: Theme.accentA
                    SequentialAnimation on opacity { loops: Animation.Infinite; running: win.open
                        NumberAnimation { to: 0; duration: 0 } PauseAnimation { duration: 450 }
                        NumberAnimation { to: 1; duration: 0 } PauseAnimation { duration: 450 } }
                }
                maximumLength: 64
                onTextChanged: { win.query = text; list.currentIndex = 0; }
                Keys.onPressed: ev => {
                    if (ev.key === Qt.Key_Escape) { win.hide(); ev.accepted = true; }
                    else if (ev.key === Qt.Key_F2) { Theme.toggleOpenStyle(); openAnim.restart(); ev.accepted = true; }
                    else if (ev.key === Qt.Key_Down) { Sfx.play("tick"); list.incrementCurrentIndex(); ev.accepted = true; }
                    else if (ev.key === Qt.Key_Up) { Sfx.play("tick"); list.decrementCurrentIndex(); ev.accepted = true; }
                    else if (ev.key === Qt.Key_Return || ev.key === Qt.Key_Enter) { win.launch((ev.modifiers & Qt.ShiftModifier) !== 0, (ev.modifiers & Qt.ControlModifier) !== 0); ev.accepted = true; }
                    else if (ev.key === Qt.Key_Tab) { Sfx.play("tick"); win.category = (win.category + 1) % win.categories.length; list.currentIndex = 0; ev.accepted = true; }
                    else if (ev.key === Qt.Key_Backtab) { Sfx.play("tick"); win.category = (win.category + win.categories.length - 1) % win.categories.length; list.currentIndex = 0; ev.accepted = true; }
                }
            }
        }

        // --- category chips
        Row {
            x: win.margin; y: 170
            spacing: 10
            Repeater {
                model: win.categories
                Rectangle {
                    required property var modelData
                    required property int index
                    readonly property bool on: index === win.category
                    width: chipText.implicitWidth + 26; height: 26
                    color: on ? Theme.accentA : "transparent"
                    border.color: on ? Theme.bg : Theme.raised; border.width: 2
                    transform: Matrix4x4 { matrix: Qt.matrix4x4(1, Theme.skew, 0, -Theme.skew * 13, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1) }
                    Text { id: chipText; anchors.centerIn: parent; text: modelData.label
                           color: parent.on ? Theme.onAccent : Theme.textDim
                           font.family: Theme.labelFont; font.pixelSize: 12; font.weight: Font.ExtraBold; font.letterSpacing: 1.4 }
                    MouseArea { anchors.fill: parent; onClicked: { Sfx.play("tick"); win.category = index; list.currentIndex = 0; search.forceActiveFocus(); } }
                }
            }
        }

        // --- list with sliding green plate
        ListView {
            id: list
            x: win.margin
            y: win.portrait ? card.y + card.height + 40 : 220
            width: searchBox.width; height: parent.height - y - 90
            clip: true
            model: win.apps
            spacing: 2
            keyNavigationWraps: true
            highlightFollowsCurrentItem: false
            boundsBehavior: Flickable.StopAtBounds
            highlight: Item {
                width: list.width; height: 46
                y: list.currentItem ? list.currentItem.y : 0
                Behavior on y { NumberAnimation { duration: 170; easing.type: Easing.OutBack; easing.overshoot: 1.8 } }
                Rectangle {
                    id: plate
                    anchors.fill: parent
                    color: Theme.accentA
                    transform: Matrix4x4 { matrix: Qt.matrix4x4(1, Theme.skew, 0, -Theme.skew * 23, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1) }
                }
                Rectangle {   // launch flash
                    id: plateFlash
                    anchors.fill: parent; color: "#ffffff"; opacity: 0
                    transform: Matrix4x4 { matrix: Qt.matrix4x4(1, Theme.skew, 0, -Theme.skew * 23, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1) }
                    Connections { target: win; function onLaunchingChanged() { if (win.launching) flashAnim.restart(); } }
                    SequentialAnimation { id: flashAnim
                        NumberAnimation { target: plateFlash; property: "opacity"; to: 1; duration: 40 }
                        NumberAnimation { target: plateFlash; property: "opacity"; to: 0; duration: 120 } }
                }
            }
            delegate: Item {
                id: row
                required property var modelData
                required property int index
                readonly property bool sel: ListView.isCurrentItem
                width: list.width; height: 46
                opacity: 0
                transform: Translate { id: rowT; x: -24 }
                Component.onCompleted: rowIn.restart()
                Connections { target: openAnim; function onStarted() { rowIn.restart(); } }
                SequentialAnimation {
                    id: rowIn
                    ScriptAction { script: { rowT.x = -24; row.opacity = 0; } }
                    PauseAnimation { duration: 170 + Math.min(row.index, 14) * 22 }
                    ParallelAnimation {
                        NumberAnimation { target: rowT; property: "x"; to: 0; duration: 220; easing.type: Easing.OutBack; easing.overshoot: 1.6 }
                        NumberAnimation { target: row; property: "opacity"; to: 1; duration: 90 }
                    }
                }
                Text {
                    x: 14; anchors.verticalCenter: parent.verticalCenter
                    text: String(row.index + 1).padStart(2, "0")
                    color: row.sel ? Theme.onAccent : Theme.raised
                    font.family: Theme.labelFont; font.pixelSize: 15; font.weight: Font.ExtraBold
                }
                Text {
                    x: 60; width: parent.width - 80; anchors.verticalCenter: parent.verticalCenter
                    textFormat: Text.StyledText
                    text: row.sel ? win.esc(row.modelData.entry.name.toUpperCase()) : win.highlighted(row.modelData.entry.name)
                    elide: Text.ElideRight
                    color: row.sel ? Theme.onAccent : Theme.text
                    font.family: Theme.numeralFont; font.weight: Font.ExtraBold; font.pixelSize: 26
                }
                Rectangle {   // runs on NVIDIA
                    visible: win.isNv(row.modelData.entry)
                    anchors.right: parent.right; anchors.rightMargin: 14; anchors.verticalCenter: parent.verticalCenter
                    width: 30; height: 18
                    color: row.sel ? Theme.bg : Theme.accentA
                    Text { anchors.centerIn: parent; text: "NV"; color: row.sel ? Theme.accentA : Theme.onAccent
                           font.family: Theme.labelFont; font.pixelSize: 10; font.weight: Font.ExtraBold }
                }
                MouseArea {
                    anchors.fill: parent; hoverEnabled: true
                    onEntered: list.currentIndex = row.index
                    onClicked: { list.currentIndex = row.index; win.launch(false); }
                }
            }
        }

        // --- detail card (or NO SIGNAL)
        Item {
            id: card
            x: win.portrait ? win.margin : searchBox.x + searchBox.width + 80
            y: 220
            width: win.portrait ? parent.width - 2 * win.margin : Math.min(parent.width - x - 64, 620)
            height: win.portrait ? 250 : 340
            transform: Translate { id: cardT; x: 0 }
            Rectangle { x: 8; y: 8; width: parent.width; height: parent.height; color: Theme.bg }
            Rectangle {
                anchors.fill: parent
                color: Theme.surface; border.color: Theme.bg; border.width: 2
                topLeftRadius: 20; topRightRadius: 20; bottomLeftRadius: 20; bottomRightRadius: 0
                Rectangle { anchors.fill: parent; anchors.margins: 2; color: "transparent"; border.color: Theme.ring; border.width: 3
                            topLeftRadius: 18; topRightRadius: 18; bottomLeftRadius: 18 }
            }
            Image {
                x: 36; y: win.portrait ? 28 : 36
                width: win.portrait ? 96 : 128; height: width
                visible: win.current !== null
                source: win.current ? Quickshell.iconPath(win.current.icon, true) : ""
                sourceSize.width: 256; sourceSize.height: 256
                fillMode: Image.PreserveAspectFit
                asynchronous: true
            }
            Text {
                x: win.portrait ? 156 : 190; y: win.portrait ? 34 : 52; width: parent.width - x - 30
                visible: win.current !== null
                text: (win.current?.name ?? "").toUpperCase()
                wrapMode: Text.WordWrap; maximumLineCount: 2; elide: Text.ElideRight
                color: Theme.text
                font.family: Theme.numeralFont; font.weight: Font.ExtraBold; font.italic: true; font.pixelSize: 48
            }
            Label {
                x: 36; y: win.portrait ? 144 : 196; width: parent.width - 72
                visible: win.current !== null
                text: win.current?.comment || win.current?.genericName || ""
                font.capitalization: Font.MixedCase
                wrapMode: Text.WordWrap; maximumLineCount: win.portrait ? 2 : 3; elide: Text.ElideRight
                font.pixelSize: 13
            }
            Label {
                x: 36; anchors.bottom: parent.bottom; anchors.bottomMargin: win.portrait ? 20 : 26
                visible: win.current !== null
                dim: false
                text: "▸ ENTER  LAUNCH     ⇧ ENTER  ON NVIDIA"
                color: Theme.accentA
                font.weight: Font.ExtraBold
            }
            Rectangle {   // ALWAYS ON NVIDIA toggle
                visible: win.current !== null
                anchors.right: parent.right; anchors.rightMargin: 30
                anchors.bottom: parent.bottom; anchors.bottomMargin: win.portrait ? 14 : 20
                width: nvText.implicitWidth + 26; height: 28
                readonly property bool on: win.isNv(win.current)
                color: on ? Theme.accentA : (nvMouse.containsMouse ? "#1f1f1f" : Theme.bg)
                border.color: on ? Theme.bg : Theme.ring; border.width: 2
                transform: Matrix4x4 { matrix: Qt.matrix4x4(1, Theme.skew, 0, -Theme.skew * 14, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1) }
                Text { id: nvText; anchors.centerIn: parent; text: (parent.on ? "✓ " : "") + "ALWAYS ON NVIDIA"
                       color: parent.on ? Theme.onAccent : Theme.textDim
                       font.family: Theme.labelFont; font.pixelSize: 10; font.weight: Font.ExtraBold; font.letterSpacing: 1 }
                MouseArea { id: nvMouse; anchors.fill: parent; hoverEnabled: true
                            onClicked: { win.toggleNv(win.current); search.forceActiveFocus(); } }
            }
            Column {   // empty result
                anchors.centerIn: parent
                visible: win.current === null
                spacing: 6
                Text { anchors.horizontalCenter: parent.horizontalCenter; text: "NO SIGNAL"; color: Theme.text
                       font.family: Theme.numeralFont; font.weight: Font.ExtraBold; font.italic: true; font.pixelSize: 56 }
                Label { anchors.horizontalCenter: parent.horizontalCenter; text: "NOTHING ON THIS CHANNEL" }
            }
        }

        // --- hint strip
        Label {
            x: win.margin; anchors.bottom: parent.bottom; anchors.bottomMargin: 40
            text: "↑↓ SELECT    ⏎ RUN    ⇧⏎ RUN ON NVIDIA    TAB CATEGORY    ESC CLOSE    " + win.apps.length + " APPS"
        }

        // diagonal wipe panel used by the open animation
        Rectangle {
            id: wiper
            visible: (openAnim.running || closeAnim.running || win.armed) && Theme.openStyle === "wipe"          // never left on screen, whatever the monitor shape
            width: parent.width * 1.6; height: parent.height * 2
            color: Theme.accentA
            rotation: 20
            x: parent.width * 1.2; y: -parent.height * 0.5
        }
    }

    Rectangle {   // TV switch-on line
        id: tvLine
        anchors.centerIn: parent
        width: parent.width; height: 4
        color: "#ffffff"
        opacity: 0
    }

    SequentialAnimation {
        id: openAnim
        ScriptAction { script: {
            const tv = Theme.openStyle === "tv";
            screenRoot.scale = 1; screenRoot.opacity = 1; cardT.x = 80; wiper.x = -wiper.width * 0.2;
            tvScale.yScale = tv ? 0.004 : 1; tvLine.opacity = tv ? 1 : 0;
        } }
        // show() already waited for the first frames on screen (armed); no fixed pause needed.
        ParallelAnimation {
            // End far enough right that the tilted panel clears tall (portrait) screens too.
            NumberAnimation { target: wiper; property: "x"; to: win.width + win.height; duration: 380; easing.type: Easing.OutCubic }
            SequentialAnimation {   // TV switch-on (Theme.openStyle "tv")
                PauseAnimation { duration: 70 }
                ParallelAnimation {
                    NumberAnimation { target: tvScale; property: "yScale"; to: 1; duration: 340; easing.type: Easing.OutBack; easing.overshoot: 1.3 }
                    NumberAnimation { target: tvLine; property: "opacity"; to: 0; duration: 220; easing.type: Easing.InQuad }
                }
            }
            SequentialAnimation {
                PauseAnimation { duration: 120 }
                NumberAnimation { target: cardT; property: "x"; to: 0; duration: 300; easing.type: Easing.OutBack; easing.overshoot: 1.4 }
            }
        }
    }
    SequentialAnimation {   // CRT switch-off, then close
        id: launchAnim
        PauseAnimation { duration: 120 }
        NumberAnimation { target: screenRoot; property: "scale"; to: 0.98; duration: 60 }
        ParallelAnimation {
            NumberAnimation { target: screenRoot; property: "opacity"; to: 0; duration: 160; easing.type: Easing.InQuad }
            NumberAnimation { target: screenRoot; property: "scale"; to: 0.6; duration: 160; easing.type: Easing.InQuad }
        }
        ScriptAction { script: win.hide(true) }   // launch effect already played
    }

    // Close animation (reverse of the open): wipe style = green panel sweeps back over the
    // screen; tv style = screen collapses into a white line (TV switch-off). Then the window goes.
    property bool closing: false
    function finishClose() {
        closeAnim.stop(); closing = false; open = false;
        wiper.x = -wiper.width; tvScale.yScale = 1; tvLine.opacity = 0;
        resetTimer.restart();      // reset search + category after the window is gone
    }
    SequentialAnimation {
        id: closeAnim
        ScriptAction { script: { win.closing = true; wiper.x = win.width + win.height; } }
        ParallelAnimation {
            NumberAnimation { target: wiper; property: "x"; to: -wiper.width * 0.2; duration: 240; easing.type: Easing.InCubic }
            NumberAnimation { target: tvScale; property: "yScale"; to: Theme.openStyle === "tv" ? 0.004 : 1; duration: 200; easing.type: Easing.InBack }
            NumberAnimation { target: tvLine; property: "opacity"; to: Theme.openStyle === "tv" ? 1 : 0; duration: 160 }
        }
        PauseAnimation { duration: 40 }
        ScriptAction { script: win.finishClose() }
    }
}
