import Quickshell
import Quickshell.Io
import Quickshell.Wayland
import QtQuick

// Saphie bar (Quickshell). Design: docs/desktop-design-zzz.md
ShellRoot {
    id: shell
    Variants {
        model: Quickshell.screens
        delegate: Component { Bar {} }
    }
    Variants {
        model: Quickshell.screens
        delegate: Component { LayoutOsd {} }
    }
    Variants {
        model: Quickshell.screens
        delegate: Component { NotificationPopups {} }
    }
    Variants {   // app notifications (top right), separate from social messages/calls
        model: Quickshell.screens
        delegate: Component { AppNotifications {} }
    }
    Variants {
        model: Quickshell.screens
        delegate: Component { OsdPopup {} }
    }
    Variants {
        model: Quickshell.screens
        delegate: Component { ScreenshotPreview {} }
    }
    Variants {
        id: taskmanagers
        model: Quickshell.screens
        delegate: Component { TaskManager {} }
    }
    // Render34 window (render PC queue / preview / videos): bar render sticker, launcher "Render34",
    // desktop/bin/saphie-render.
    RenderApp { id: renderApp }
    IpcHandler {
        target: "render"
        function toggle(): void { renderApp.toggle(); }
        function tab(n: int): void { renderApp.showTab(n); }
    }
    function toggleRender() { renderApp.toggle(); }
    // Task manager: CPU sticker click, or Ctrl+Shift+Esc (desktop/bin/saphie-taskmanager).
    IpcHandler {
        target: "taskmanager"
        function toggle(): void { shell.toggleTaskManager("", 0); }
        function performance(): void { shell.toggleTaskManager("", 1); }
    }
    function toggleTaskManager(output, startTab) {
        if (!output) { const ws = Niri.workspaces.find(w => w.is_focused); output = ws ? ws.output : ""; }
        const all = taskmanagers.instances;
        const anyOpen = all.some(t => t.open);
        for (const t of all) t.hide();
        if (anyOpen) return;
        const target = all.find(t => t.modelData.name === output) ?? all[0];
        if (target) target.show(startTab);
    }
    // Snip bar: Super+Shift+S (desktop/bin/saphie-snip).
    Variants { id: snipWins; model: Quickshell.screens; delegate: Component { Snip {} } }
    IpcHandler {
        target: "snip"
        function toggle(): void {
            const all = snipWins.instances;
            if (all.some(s => s.open)) { for (const s of all) s.hide(); return; }
            snipWhere.running = true;     // open on the monitor the mouse is on
        }
    }
    // Which monitor is the mouse on? `niri msg cursor-output` is a Saphie niri patch
    // (desktop/niri-patches/saphie-cursor-output.patch). Older niri: falls back to the
    // focused monitor, as before.
    function snipShow(output) {
        const all = snipWins.instances;
        const ws = Niri.workspaces.find(w => w.is_focused);
        const t = all.find(s => s.modelData.name === output)
               ?? all.find(s => s.modelData.name === (ws ? ws.output : "")) ?? all[0];
        if (t) t.show();
    }
    Process {
        id: snipWhere
        property string out: ""
        command: ["niri", "msg", "--json", "cursor-output"]
        stdout: SplitParser { onRead: line => snipWhere.out += line }
        onStarted: out = ""
        onExited: {
            let name = "";
            try { const o = JSON.parse(out); name = o && typeof o.name === "string" ? o.name : ""; }
            catch (e) { name = ""; }   // old niri: unknown command
            shell.snipShow(name);
        }
    }
    // Saphie Chat: Super+N / click a message card (desktop/bin/saphie-chat).
    Variants {
        id: chatWins
        model: Quickshell.screens
        delegate: Component { Chat {} }
    }
    function chatOpen(key, toggle) {
        const all = chatWins.instances;
        if (toggle && all.some(c => c.open)) { for (const c of all) c.hide(); return; }
        const ws = Niri.workspaces.find(w => w.is_focused);
        const target = all.find(c => c.modelData.name === (ws ? ws.output : "")) ?? all[0];
        for (const c of all) if (c !== target) c.hide();
        if (target) target.show(key);
    }
    Connections { target: Notifs; function onOpenChat(key) { shell.chatOpen(key, false); } }
    IpcHandler {
        target: "chat"
        function toggle(): void { shell.chatOpen("", true); }
        function open(key: string): void { shell.chatOpen(key.slice(0, 200), false); }   // "TG|Kampanat"
    }
    // Saphie Settings: Super+S / launcher entry (desktop/bin/saphie-settings).
    Variants {
        id: settingsWins
        model: Quickshell.screens
        delegate: Component { Settings {} }
    }
    IpcHandler {
        target: "settings"
        function page(n: int): void {   // open on channel n (1-9), e.g. from scripts
            const ws = Niri.workspaces.find(w => w.is_focused);
            const all = settingsWins.instances;
            const target = all.find(s => s.modelData.name === (ws ? ws.output : "")) ?? all[0];
            if (!target) return;
            if (!target.open) target.show();
            target.go(Math.max(0, Math.min(8, n - 1)));
        }
        function toggle(): void {
            const all = settingsWins.instances;
            const anyOpen = all.some(s => s.open);
            for (const s of all) s.hide();
            if (anyOpen) return;
            const ws = Niri.workspaces.find(w => w.is_focused);
            const target = all.find(s => s.modelData.name === (ws ? ws.output : "")) ?? all[0];
            if (target) target.show();
        }
    }
    // Hotkey sheet: Super+Shift+/ (desktop/bin/saphie-hotkeys).
    Variants {
        id: hotkeySheets
        model: Quickshell.screens
        delegate: Component { Hotkeys {} }
    }
    // Once per login (not on every bar reload): marker file in the runtime dir, removed at logout.
    Process {
        running: true
        command: ["sh", "-c", 'f="${XDG_RUNTIME_DIR:?}/saphie-hotkeys-shown"; [ -e "$f" ] && exit 1; : > "$f"']
        onExited: code => { if (code === 0) firstSheet.start(); }
    }
    Timer { id: firstSheet; interval: 1800; onTriggered: if (Theme.hotkeysAtLogin) hotkeyIpc.toggle() }
    IpcHandler {
        id: hotkeyIpc
        target: "hotkeys"
        function toggle(): void {
            const all = hotkeySheets.instances;
            const anyOpen = all.some(h => h.open);
            for (const h of all) h.hide();
            if (anyOpen) return;
            const ws = Niri.workspaces.find(w => w.is_focused);
            const target = all.find(h => h.modelData.name === (ws ? ws.output : "")) ?? all[0];
            if (target) target.show();
        }
    }
    // Lock screen (Super+Alt+L, power menu, idle, before sleep via saphie-sleep-lock).
    LockScreen {}
    IpcHandler {
        target: "lock"
        function lock(): void { Locker.lock(); }
        function state(): string { return Locker.locked ? "locked" : "unlocked"; }
    }
    // Auto-lock after 10 minutes without input (apps like video players can inhibit idle).
    IdleMonitor {
        enabled: Theme.idleLockMin > 0
        timeout: Math.max(1, Theme.idleLockMin) * 60
        respectInhibitors: true
        onIsIdleChanged: if (isIdle) Locker.lock()
    }
    // Brightness + media keys (desktop/bin/saphie-key): no brightnessctl/playerctl needed.
    IpcHandler {
        target: "keys"
        function brightness(delta: int): void { if (delta >= -50 && delta <= 50) Osd.brightness(delta); }
        function media(cmd: string): void { if (["playpause", "next", "previous", "stop"].includes(cmd)) Osd.media(cmd); }
    }
    Variants {
        id: launchers
        model: Quickshell.screens
        delegate: Component { Launcher {} }
    }
    Variants {
        id: powers
        model: Quickshell.screens
        delegate: Component { PowerMenu {} }
    }
    // Super+Shift+E -> desktop/bin/saphie-power -> "quickshell ipc ... call power toggle".
    IpcHandler {
        target: "power"
        function toggle(): void {
            const ws = Niri.workspaces.find(w => w.is_focused);
            const out = ws ? ws.output : "";
            const all = powers.instances;
            const anyOpen = all.some(p => p.open);
            for (const p of all) p.hide();
            if (anyOpen) return;
            const target = all.find(p => p.modelData.name === out) ?? all[0];
            if (target) target.show();
        }
    }
    // Mod+D -> desktop/bin/saphie-launcher -> "quickshell ipc ... call launcher toggle".
    // Opens on the monitor that has keyboard focus (niri's focused workspace).
    IpcHandler {
        target: "launcher"
        function toggle(): void {
            const ws = Niri.workspaces.find(w => w.is_focused);
            const out = ws ? ws.output : "";
            const all = launchers.instances;
            const anyOpen = all.some(l => l.open);
            for (const l of all) l.hide();
            if (anyOpen) return;
            const target = all.find(l => l.modelData.name === out) ?? all[0];
            if (target) target.show();
        }
    }
}
