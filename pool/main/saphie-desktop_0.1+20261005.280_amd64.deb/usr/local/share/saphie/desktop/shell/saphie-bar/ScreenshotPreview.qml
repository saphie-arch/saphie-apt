import Quickshell
import Quickshell.Wayland
import QtQuick

// After a screenshot: white flash + shutter, then a preview sticker (bottom right of the focused
// monitor) with OPEN / FOLDER. niri already saved the PNG and copied it to the clipboard.
PanelWindow {
    id: win
    required property var modelData
    screen: modelData
    readonly property bool active: {
        const ws = Niri.workspaces.find(w => w.is_focused);
        return ws ? ws.output === modelData.name : modelData === Quickshell.screens[0];
    }
    property string path: ""
    property bool showing: false
    visible: showing && active
    anchors { top: true; bottom: true; left: true; right: true }
    exclusionMode: ExclusionMode.Ignore
    color: "transparent"
    WlrLayershell.layer: WlrLayer.Overlay
    WlrLayershell.namespace: "saphie-screenshot"
    // Only the card takes clicks; the rest of the screen stays usable.
    mask: Region { item: card }

    Connections {
        target: Niri
        function onScreenshotTaken(p) {
            if (!win.active) return;
            win.path = p;
            win.showing = true;
            Sfx.play("shutter");
            inAnim.restart(); hideTimer.restart();
        }
    }
    Timer { id: hideTimer; interval: 6000; onTriggered: if (!hover.containsMouse) outAnim.restart(); else restart() }

    Rectangle { id: flash; anchors.fill: parent; color: "#ffffff"; opacity: 0 }

    Item {
        id: card
        anchors.right: parent.right; anchors.bottom: parent.bottom
        anchors.rightMargin: 24; anchors.bottomMargin: 24
        width: 340; height: 250
        transform: Translate { id: slide; x: 0 }
        rotation: -1.5
        Rectangle { x: 6; y: 6; width: parent.width; height: parent.height; color: Theme.bg }
        Rectangle {
            anchors.fill: parent
            color: Theme.surface; border.color: Theme.bg; border.width: 2
            topLeftRadius: Theme.corner; topRightRadius: Theme.corner; bottomLeftRadius: Theme.corner; bottomRightRadius: 0
            Rectangle { anchors.fill: parent; anchors.margins: 2; color: "transparent"; border.color: Theme.ring; border.width: 3
                        topLeftRadius: Theme.corner - 2; topRightRadius: Theme.corner - 2; bottomLeftRadius: Theme.corner - 2 }
        }
        MouseArea { id: hover; anchors.fill: parent; hoverEnabled: true }
        Text {
            x: 18; y: 14
            text: "SCREENSHOT"
            color: Theme.accentA
            font.family: Theme.labelFont; font.pixelSize: 11; font.weight: Font.ExtraBold; font.letterSpacing: 1.6
        }
        Text {
            anchors.right: parent.right; anchors.rightMargin: 16; y: 12
            text: "✕"; color: closeM.containsMouse ? Theme.accentA : Theme.textDim; font.pixelSize: 14; font.weight: Font.Black
            MouseArea { id: closeM; anchors.fill: parent; anchors.margins: -6; hoverEnabled: true; onClicked: outAnim.restart() }
        }
        Rectangle {   // thumbnail
            x: 18; y: 38; width: parent.width - 36; height: 150
            color: "#0a0a0a"; border.color: Theme.bg; border.width: 2
            clip: true
            Image {
                anchors.fill: parent; anchors.margins: 2
                source: win.path ? "file://" + win.path : ""
                fillMode: Image.PreserveAspectFit
                asynchronous: true; cache: false
                sourceSize.width: 600
            }
            Text {
                anchors.centerIn: parent
                visible: !win.path
                text: "COPIED TO CLIPBOARD"; color: Theme.textDim
                font.family: Theme.labelFont; font.pixelSize: 12; font.weight: Font.ExtraBold
            }
            MouseArea { anchors.fill: parent; enabled: win.path !== ""; cursorShape: Qt.PointingHandCursor
                        onClicked: Quickshell.execDetached(["xdg-open", win.path]) }
        }
        Text {
            x: 18; y: 198
            text: win.path ? "COPIED + SAVED" : "COPIED"
            color: Theme.textDim
            font.family: Theme.labelFont; font.pixelSize: 10; font.weight: Font.ExtraBold; font.letterSpacing: 1.2
        }
        Row {
            anchors.right: parent.right; anchors.rightMargin: 18; y: 192
            spacing: 8
            visible: win.path !== ""
            component Btn: Rectangle {
                id: b
                property string label
                signal hit()
                width: bt.implicitWidth + 22; height: 26
                color: bm.containsMouse ? Theme.accentA : Theme.bg
                border.color: Theme.ring; border.width: 2
                transform: Matrix4x4 { matrix: Qt.matrix4x4(1, Theme.skew, 0, -Theme.skew * 13, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1) }
                Text { id: bt; anchors.centerIn: parent; text: b.label; color: bm.containsMouse ? Theme.onAccent : Theme.text
                       font.family: Theme.labelFont; font.pixelSize: 10; font.weight: Font.ExtraBold }
                MouseArea { id: bm; anchors.fill: parent; hoverEnabled: true; onClicked: b.hit() }
            }
            Btn { label: "OPEN"; onHit: Quickshell.execDetached(["xdg-open", win.path]) }
            Btn { label: "FOLDER"; onHit: Quickshell.execDetached(["xdg-open", win.path.substring(0, win.path.lastIndexOf("/"))]) }
        }
    }

    SequentialAnimation {
        id: inAnim
        ScriptAction { script: { slide.x = 420; flash.opacity = 0; } }
        NumberAnimation { target: flash; property: "opacity"; to: 0.75; duration: 45 }
        NumberAnimation { target: flash; property: "opacity"; to: 0; duration: 220; easing.type: Easing.OutQuad }
        NumberAnimation { target: slide; property: "x"; to: 0; duration: 320; easing.type: Easing.OutBack; easing.overshoot: 1.6 }
    }
    SequentialAnimation {
        id: outAnim
        NumberAnimation { target: slide; property: "x"; to: 420; duration: 200; easing.type: Easing.InQuad }
        ScriptAction { script: win.showing = false }
    }
}
