pragma Singleton
import Quickshell
import Quickshell.Io
import QtQuick

// User power mode for perfd (perfd/src/usermode.rs): one word in /run/perfd-mode, a file
// created at boot (systemd-tmpfiles) and owned by this user. "auto" = perfd decides from the
// running apps; performance / balanced / quiet force that mode. available = file exists
// (perfd with mode support installed).
Singleton {
    id: root
    readonly property string path: "/run/perfd-mode"
    readonly property var modes: ["auto", "performance", "balanced", "quiet"]
    property string mode: "auto"
    property bool available: false

    FileView {
        id: file
        path: root.path
        printErrors: false
        onLoaded: { const t = text().trim(); root.available = true; root.mode = root.modes.includes(t) ? t : "auto"; }
        onLoadFailed: { root.available = false; root.mode = "auto"; }
    }
    Timer { interval: 2000; running: true; repeat: true; triggeredOnStart: true; onTriggered: file.reload() }

    // In-place write (the user may change the file's contents but not create files in /run).
    Process { id: writer; onExited: file.reload() }
    function set(m) {
        if (!modes.includes(m) || !available) return;
        mode = m;
        writer.exec(["sh", "-c", 'printf "%s\\n" "$1" > /run/perfd-mode', "sh", m]);
    }
    function cycle() { set(modes[(modes.indexOf(mode) + 1) % modes.length]); }
    function label(m) { return ({ auto: "AUTO", performance: "PERF", balanced: "BAL", quiet: "QUIET" })[m] ?? "AUTO"; }
}
