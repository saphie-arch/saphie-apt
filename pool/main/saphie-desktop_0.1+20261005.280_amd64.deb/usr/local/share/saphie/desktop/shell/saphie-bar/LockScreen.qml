import Quickshell
import Quickshell.Wayland
import QtQuick

// Saphie lock screen (ext-session-lock): every monitor is covered; the laptop panel (or the
// first screen) gets the password card, others show the clock.
WlSessionLock {
    id: lock
    locked: Locker.locked

    WlSessionLockSurface {
        id: surf
        color: "#000000"
        readonly property bool main: {
            const panel = Quickshell.screens.find(s => /^(eDP|LVDS|DSI)/.test(s.name));
            return screen === (panel ?? Quickshell.screens[0]);
        }

        LockContent { main: surf.main }
    }
}
