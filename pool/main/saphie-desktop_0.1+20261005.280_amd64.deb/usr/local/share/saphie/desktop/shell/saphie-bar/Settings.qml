import Quickshell
import Quickshell.Io
import Quickshell.Wayland
import Quickshell.Networking
import Quickshell.Services.Pipewire
import QtQuick

// Saphie Settings (Super+S, launcher "Saphie Settings"), ZZZ menu style: channel list on the
// left, sticker card with the settings of the chosen channel on the right.
// Saves UI choices through Theme.saveUi() (~/.config/saphie/ui.json); system things go through
// the same tools the bar already uses (PipeWire, logind brightness, NetworkManager, saphie-theme,
// saphie-layout). Anything not covered: "MORE SETTINGS" opens GNOME Settings.
PanelWindow {
    id: win
    required property var modelData
    screen: modelData
    property bool open: false
    visible: open
    color: "transparent"
    anchors { top: true; bottom: true; left: true; right: true }
    exclusionMode: ExclusionMode.Ignore
    WlrLayershell.layer: WlrLayer.Overlay
    WlrLayershell.namespace: "saphie-settings"
    WlrLayershell.keyboardFocus: open ? WlrKeyboardFocus.Exclusive : WlrKeyboardFocus.None
    readonly property bool portrait: height > width

    property int section: 0
    readonly property var sections: [
        ["01", "APPEARANCE"], ["02", "SOUND"], ["03", "DISPLAY"], ["04", "NETWORK"],
        ["05", "POWER"], ["06", "LAYOUTS"], ["07", "KEYS"], ["08", "PROXY"], ["09", "ABOUT"]]

    function show() {
        if (closing) { closeAnim.stop(); closing = false; } Sfx.play("open"); open = true; openAnim.restart(); keys.forceActiveFocus();
        brightness = Osd.brightnessFraction();
        outputsProc.running = true; aboutProc.running = true; profileFile.reload(); wallsProc.running = true; engineProc.running = true; themeState.reload();
        proxyStatusProc.running = true; proxyMsg = "";
    }
    function hide(instant) { if (!open || closing) return; Sfx.play("close"); if (instant) finishClose(); else closeAnim.restart(); }
    function go(i) { if (i !== section) { Sfx.play("tick"); section = i; pageAnim.restart(); } }
    function run(cmd) { Quickshell.execDetached(cmd); }
    function sinkName(n) { return devName(n, false); }
    function devName(n, mic) {   // friendly device names instead of driver text
        const d = String(n.description || n.nickname || n.name || "");
        const name = String(n.name || "");
        const clean = d.replace(/\s*(analog|digital)\s*(stereo|mono|surround[^ ]*)?\s*/ig, " ").trim().toUpperCase().slice(0, 26);
        if (/bluez/i.test(name) || /bluetooth/i.test(d)) return "BLUETOOTH · " + clean;
        if (/\.usb-/.test(name)) return "USB · " + clean;
        if (/hdmi|displayport|radeon|nvidia/i.test(d)) return "MONITOR (HDMI)";
        if (/headphone/i.test(d)) return "HEADPHONES";
        if (/analog|speaker|controller|stereo|mic/i.test(d)) return mic ? "LAPTOP MIC / HEADSET JACK" : "LAPTOP SPEAKERS / HEADPHONES";
        return clean;
    }
    readonly property string bin: Quickshell.shellDir + "/../../bin/"

    // ---- Proxy (voice assistant): AI service + key, via its own proxy-setup tool
    // Proxy: your own install (~/.local/opt/proxy, development) or the saphie-proxy package
    property string proxySetup: (Quickshell.env("HOME") ?? "") + "/.local/opt/proxy/proxy-setup"
    Process {
        running: true
        command: ["sh", "-c", "for p in \"$HOME/.local/opt/proxy/proxy-setup\" /usr/local/opt/saphie/proxy/proxy-setup; do " +
                  "[ -x \"$p\" ] && echo \"$p\" && exit 0; done"]
        stdout: SplitParser { onRead: l => { if (/^\/[\w\/.-]+\/proxy-setup$/.test(l.trim())) win.proxySetup = l.trim(); } }
    }
    property var proxy: null                 // proxy-setup status (null = Proxy not installed)
    readonly property var proxyCur: proxy ? proxy.providers[proxy.provider] : null
    property string proxyMsg: ""
    property bool proxyMsgOk: false
    property string proxyPendingKey: ""
    function proxyResult(text) {
        try {
            const r = JSON.parse(text);
            if (r.detail || r.error) { proxyMsg = String(r.ok ? (r.detail || "OK") : r.error).slice(0, 120); proxyMsgOk = !!r.ok; }
            else if (r.ok) { proxyMsg = ""; }
        } catch (e) {}
        proxyStatusProc.running = true;
    }
    Process {
        id: proxyStatusProc
        command: [win.proxySetup, "status"]
        stdout: StdioCollector { onStreamFinished: { try { win.proxy = JSON.parse(text); } catch (e) { win.proxy = null; } } }
    }
    Process { id: proxyCmd; stdout: StdioCollector { onStreamFinished: win.proxyResult(text) } }
    function proxyRun(args) { if (!proxyCmd.running) { proxyCmd.command = [proxySetup].concat(args); proxyCmd.running = true; } }
    Process {   // the key goes in through stdin, never on a command line other programs can see
        id: proxyKeyProc
        stdinEnabled: true
        onStarted: { write(win.proxyPendingKey + "\n"); win.proxyPendingKey = ""; stdinEnabled = false; }
        onExited: stdinEnabled = true
        stdout: StdioCollector { onStreamFinished: win.proxyResult(text) }
    }
    function proxySaveKey(name, k) {
        if (proxyKeyProc.running || !k) return;
        proxyPendingKey = k.trim();
        proxyKeyProc.command = [proxySetup, "key", name];
        proxyKeyProc.running = true;
    }

    // ---- live data
    readonly property var sink: Pipewire.defaultAudioSink
    readonly property var sinks: Pipewire.nodes.values.filter(n => n.isSink && !n.isStream && n.audio)
    // Real microphones only (not Proxy's echo-cancel source or other virtual nodes)
    readonly property var mic: Pipewire.defaultAudioSource
    readonly property var mics: Pipewire.nodes.values.filter(n => !n.isSink && !n.isStream && n.audio
                                                              && /^(alsa_input|bluez_input)\./.test(String(n.name)))
    PwObjectTracker { objects: [win.sink, win.mic].filter(o => o) }
    property real brightness: -1
    readonly property string focusedOutput: { const ws = Niri.workspaces.find(w => w.is_focused); return ws ? ws.output : ""; }
    readonly property var wifiDev: Networking.devices.values.find(d => d.type === DeviceType.Wifi) ?? null
    readonly property var wifiNow: wifiDev ? (wifiDev.networks.values.find(n => n.connected) ?? null) : null
    property var outputs: []
    Process {
        id: outputsProc
        command: ["niri", "msg", "-j", "outputs"]
        stdout: StdioCollector { onStreamFinished: {
            try {
                const d = JSON.parse(text); const out = [];
                for (const k in d) {
                    const o = d[k]; const m = o.modes?.[o.current_mode ?? -1];
                    out.push({ name: String(k).slice(0, 32), make: String(o.make ?? "").slice(0, 40),
                               mode: m ? m.width + "x" + m.height + " @ " + (m.refresh_rate / 1000).toFixed(0) + " Hz" : "OFF",
                               rot: String(o.logical?.transform ?? "Normal"), scale: o.logical?.scale ?? 1 });
                }
                win.outputs = out;
            } catch (e) { win.outputs = []; }
        } }
    }
    // Wallpapers: ~/Pictures/Wallpapers, ~/.local/share/backgrounds, Ubuntu's backgrounds (not
    // ~/Pictures/Screenshots). Paths are checked here and again by saphie-theme (type + size).
    property var wallpapers: []
    Process {
        id: wallsProc
        command: ["sh", "-c", 'for d in "$HOME/Pictures/Wallpapers" "$HOME/.local/share/backgrounds" /usr/share/backgrounds; do ' +
                  '[ -d "$d" ] && find "$d" -maxdepth 1 -type f \\( -iname "*.png" -o -iname "*.jpg" -o -iname "*.jpeg" -o -iname "*.webp" \\) | sort; done']
        stdout: StdioCollector { onStreamFinished: {
            win.wallpapers = text.split("\n").filter(l => /^\/[^\n]{1,1000}\.(png|jpe?g|webp)$/i.test(l)).slice(0, 60);
            const webp = win.wallpapers.filter(w => /\.webp$/i.test(w));
            if (webp.length) { thumbProc.command = [win.bin + "saphie-thumb"].concat(webp); thumbProc.running = true; }
        } }
    }
    // Our Qt has no WebP decoder: those wallpapers get cached PNG thumbnails (bin/saphie-thumb).
    property var thumbs: ({})
    Process {
        id: thumbProc
        stdout: StdioCollector { onStreamFinished: {
            const t = {};
            for (const l of text.split("\n")) {
                const [src, png] = l.split("\t");
                if (src && /^\/[^\n\t]{1,1000}\.png$/.test(png ?? "")) t[src] = png;
            }
            win.thumbs = t;
        } }
    }
    // Steam Wallpaper Engine wallpapers (bin/saphie-wallpaperengine list: built-in, own, Workshop),
    // played by linux-wallpaperengine. Entries are checked here; saphie-theme re-validates the folder.
    property var engineWalls: []
    property bool engineAll: false
    property string wallEngine: ""
    Process {
        id: engineProc
        command: [win.bin + "saphie-wallpaperengine", "list"]
        stdout: StdioCollector { onStreamFinished: {
            try {
                const l = JSON.parse(text);
                win.engineWalls = Array.isArray(l) ? l.filter(w => w && typeof w.path === "string" && /^\/[^\n]{1,1000}$/.test(w.path)
                    && typeof w.title === "string" && (w.preview === "" || /^\/[^\n]{1,1000}\.(jpe?g|png|gif)$/i.test(w.preview))).slice(0, 500) : [];
            } catch (e) { win.engineWalls = []; }
        } }
    }
    // Proxy's own settings (~/.config/proxy/settings.json), shared with Proxy (audience mode etc.)
    property var proxySettings: ({})
    FileView {
        id: proxySettingsFile
        path: (Quickshell.env("HOME") ?? "") + "/.config/proxy/settings.json"
        watchChanges: true; printErrors: false
        onFileChanged: reload()
        onLoaded: { try { const d = JSON.parse(text()); win.proxySettings = (d && typeof d === "object") ? d : {}; }
                    catch (e) { win.proxySettings = {}; } }
        onLoadFailed: win.proxySettings = ({})
    }
    function proxySet(key, value) {
        const d = Object.assign({}, win.proxySettings); d[key] = value;
        win.proxySettings = d;
        proxySettingsFile.setText(JSON.stringify(d, null, 2) + "\n");
    }
    property string wallSource: ""
    property string themeMode: "bw"          // what the user chose (theme.json), not what was applied
    FileView {
        id: themeState
        path: (Quickshell.env("HOME") ?? "") + "/.config/saphie/theme.json"
        watchChanges: true; printErrors: false
        onFileChanged: reload()
        onLoaded: { try { const d = JSON.parse(text());
                          win.wallSource = typeof d.source === "string" ? d.source : "";
                          win.wallEngine = typeof d.engine === "string" ? d.engine : "";
                          win.themeMode = d.mode === "wallpaper" ? "wallpaper" : "bw"; }
                    catch (e) { win.wallSource = ""; win.wallEngine = ""; win.themeMode = "bw"; } }
        onLoadFailed: { win.wallSource = ""; win.wallEngine = ""; win.themeMode = "bw"; }
    }
    property var about: []
    Process {
        id: aboutProc
        command: ["sh", "-c",
            "echo \"OS|Saphie OS (phase 4) on $(. /etc/os-release; echo $PRETTY_NAME)\";" +
            "echo \"KERNEL|$(uname -r)\";" +
            "echo \"CPU|$(sed -n 's/^model name[^:]*: //p' /proc/cpuinfo | head -1)\";" +
            "echo \"GPU|$(lspci 2>/dev/null | grep -E 'VGA|3D controller' | sed 's/ (rev.*//; s/.*\\[\\(.*\\)\\]$/\\1/; s/ Series.*//' | sed 's#.*/##' | paste -sd '+' - | sed 's/+/ + /g')\";" +
            "echo \"MEMORY|$(awk '/MemTotal/{printf \"%.0f GB usable\", $2/1048576}' /proc/meminfo)\";" +
            "echo \"DESKTOP|$(niri --version 2>/dev/null | head -1) + Quickshell\";" +
            "echo \"UPTIME|$(uptime -p | sed 's/^up //')\""]
        stdout: StdioCollector { onStreamFinished: {
            win.about = text.split("\n").filter(l => l.includes("|")).slice(0, 10)
                .map(l => { const i = l.indexOf("|"); return [l.slice(0, i).slice(0, 12), l.slice(i + 1).slice(0, 120)]; });
        } }
    }
    property string profile: ""
    Timer { interval: 2000; repeat: true; running: win.open && win.section === 4; onTriggered: profileFile.reload() }
    FileView { id: profileFile; path: "/sys/firmware/acpi/platform_profile"; printErrors: false
               onLoaded: { const t = text().trim(); win.profile = /^[a-z-]{1,32}$/.test(t) ? t : ""; } }

    // ---- building blocks
    component Skew: Matrix4x4 { property real h: 20
        matrix: Qt.matrix4x4(1, Theme.skew, 0, -Theme.skew * h / 2, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1) }
    component RowLabel: Column {
        property string title; property string hint
        spacing: 3
        Text { text: parent.title; color: Theme.text; font.family: Theme.labelFont; font.pixelSize: 14; font.weight: Font.ExtraBold; font.letterSpacing: 1 }
        Text { visible: text.length > 0; text: parent.hint; color: parent.hint.startsWith("▸") ? Theme.accentA : Theme.textDim   // ▸ = action needed
               font.family: Theme.labelFont; font.pixelSize: 11; font.weight: parent.hint.startsWith("▸") ? Font.ExtraBold : Font.Normal }
    }
    // Segmented skewed chips: options = [[label, value], ...]
    component Chips: Row {
        id: chipsRoot
        property var options: []
        property var current
        signal picked(var value)
        spacing: 6
        Repeater {
            model: chipsRoot.options
            Item {
                id: chip
                required property var modelData
                readonly property bool on: chipsRoot.current === modelData[1]
                width: chipText.implicitWidth + 30; height: 34
                Rectangle { x: 3; y: 3; width: parent.width; height: parent.height; color: Theme.bg; transform: Skew { h: 34 } }
                Rectangle {
                    anchors.fill: parent
                    color: chip.on ? Theme.accentA : (cm.containsMouse ? "#2a2a2a" : "#1c1c1c")
                    border.color: chip.on ? Theme.bg : Theme.ring; border.width: 2
                    transform: Skew { h: 34 }
                    Behavior on color { ColorAnimation { duration: 120 } }
                }
                Text { id: chipText; anchors.centerIn: parent; text: chip.modelData[0]
                       color: chip.on ? Theme.onAccent : Theme.text
                       font.family: Theme.labelFont; font.pixelSize: 12; font.weight: Font.ExtraBold; font.letterSpacing: 1 }
                MouseArea { id: cm; anchors.fill: parent; hoverEnabled: true
                            onClicked: { if (!chip.on) { Sfx.play("tick"); chipsRoot.picked(chip.modelData[1]); } } }
            }
        }
    }
    // Caution-stripe slider 0..1
    component Slide: Item {
        id: sl
        property real value: 0
        property bool live: true          // emit while dragging
        signal moved(real v)
        signal released(real v)
        width: 360; height: 30
        Rectangle { y: 10; width: parent.width; height: 10; color: Theme.ring; clip: true
            Item { width: parent.width * Math.max(0, Math.min(1, sl.value)); height: parent.height; clip: true
                Row { x: -6; Repeater { model: Math.max(0, Math.ceil(sl.width / 8) + 2)
                    Rectangle { width: 4; height: 20; y: -5; rotation: 45; color: index % 2 ? Theme.accentB : Theme.accentA } } } } }
        Rectangle {   // knob
            x: Math.max(0, Math.min(sl.width - width, sl.width * sl.value - width / 2)); y: 3; width: 14; height: 24
            color: Theme.text; border.color: Theme.bg; border.width: 2; transform: Skew { h: 24 }
        }
        MouseArea {
            anchors.fill: parent; anchors.margins: -6
            function at(x) { return Math.max(0, Math.min(1, (x - 6) / sl.width)); }
            onPressed: ev => { sl.value = at(ev.x); if (sl.live) sl.moved(sl.value); }
            onPositionChanged: ev => { if (pressed) { sl.value = at(ev.x); if (sl.live) sl.moved(sl.value); } }
            onReleased: ev => sl.released(sl.value)
            onWheel: ev => { sl.value = Math.max(0, Math.min(1, sl.value + (ev.angleDelta.y > 0 ? 0.05 : -0.05))); sl.moved(sl.value); sl.released(sl.value); }
        }
    }
    component Act: Item {   // action button
        id: act
        property string label
        signal hit()
        width: actText.implicitWidth + 40; height: 36
        Rectangle { x: 4; y: 4; width: parent.width; height: parent.height; color: Theme.accentB; opacity: 0.5; transform: Skew { h: 36 } }
        Rectangle { anchors.fill: parent; color: am.containsMouse ? Theme.accentA : Theme.text; border.color: Theme.bg; border.width: 2
                    transform: Skew { h: 36 } }
        Text { id: actText; anchors.centerIn: parent; text: act.label + "  ▸"; color: Theme.onAccent
               font.family: Theme.labelFont; font.pixelSize: 12; font.weight: Font.ExtraBold; font.letterSpacing: 1 }
        MouseArea { id: am; anchors.fill: parent; hoverEnabled: true; onClicked: { Sfx.play("confirm"); act.hit(); } }
    }
    component Setting: Item {   // one row: label on the left, control on the right (or below on narrow)
        id: st
        property string title; property string hint
        default property alias control: holder.data
        width: parent ? parent.width : 600
        readonly property bool stacked: width < 760
        height: stacked ? lab.height + 12 + holder.childrenRect.height + 18 : Math.max(lab.height, holder.childrenRect.height) + 22
        RowLabel { id: lab; title: st.title; hint: st.hint; y: 4 }
        Item { id: holder; x: st.stacked ? 0 : Math.max(lab.width + 30, st.width * 0.42); y: st.stacked ? lab.height + 12 : 0
               width: st.width - x; height: childrenRect.height }
        Rectangle { anchors.bottom: parent.bottom; width: parent.width; height: 1; color: Theme.ring; opacity: 0.6 }
    }

    Item {
        id: screenRoot
        anchors.fill: parent
        transform: Scale { id: tvScale; origin.x: screenRoot.width / 2; origin.y: screenRoot.height / 2; yScale: 1 }
        Rectangle { anchors.fill: parent; color: "#000000"; opacity: 0.97 }
        Canvas { anchors.fill: parent; opacity: 0.05
                 onPaint: { const c = getContext("2d"); c.fillStyle = "#ffffff"; for (let y = 0; y < height; y += 3) c.fillRect(0, y, width, 1); } }
        Item {
            id: keys
            focus: true
            Keys.onPressed: ev => {
                if (ev.key === Qt.Key_Escape) win.hide();
                else if (ev.key === Qt.Key_Down || ev.key === Qt.Key_Tab) win.go((win.section + 1) % win.sections.length);
                else if (ev.key === Qt.Key_Up || ev.key === Qt.Key_Backtab) win.go((win.section + win.sections.length - 1) % win.sections.length);
                else return;
                ev.accepted = true;
            }
        }

        // ---- header
        Item {
            id: header
            x: win.portrait ? 40 : 72; y: win.portrait ? 60 : 64
            width: parent.width - 2 * x; height: 92
            Rectangle {
                width: 170; height: 30
                color: Theme.accentA; border.color: Theme.bg; border.width: 2
                transform: Skew { h: 30 }
                Text { anchors.centerIn: parent; text: "CH 00 · SYSTEM"; color: Theme.onAccent
                       font.family: Theme.labelFont; font.pixelSize: 12; font.weight: Font.ExtraBold; font.letterSpacing: 1.6 }
            }
            Text { y: 36; text: "SETTINGS"; color: Theme.text; font.family: Theme.titleFont; font.pixelSize: win.portrait ? 44 : 56 }
            Text { anchors.right: parent.right; anchors.bottom: parent.bottom; anchors.bottomMargin: 8
                   text: win.portrait ? "ESC" : "↑ ↓ CHANNEL    ESC CLOSE"; color: Theme.textDim
                   font.family: Theme.labelFont; font.pixelSize: 11; font.weight: Font.ExtraBold; font.letterSpacing: 1.4 }
        }

        // ---- channel list
        Column {
            id: nav
            x: header.x; y: header.y + header.height + 28
            width: win.portrait ? 250 : 320
            spacing: 6
            Repeater {
                model: win.sections
                Item {
                    id: navItem
                    required property var modelData
                    required property int index
                    readonly property bool on: win.section === index
                    width: nav.width; height: win.portrait ? 50 : 56
                    Rectangle { x: navItem.on ? 6 : 0; width: parent.width - 6; height: parent.height
                                color: navItem.on ? Theme.accentA : (nm.containsMouse ? "#1f1f1f" : "transparent")
                                transform: Skew { h: navItem.height }
                                Behavior on x { NumberAnimation { duration: 180; easing.type: Easing.OutBack; easing.overshoot: 2 } } }
                    Text { x: 22; anchors.verticalCenter: parent.verticalCenter; text: navItem.modelData[0]
                           color: navItem.on ? Theme.onAccent : Theme.accentA
                           font.family: Theme.numeralFont; font.italic: true; font.weight: Font.ExtraBold; font.pixelSize: 30 }
                    Text { x: 70; anchors.verticalCenter: parent.verticalCenter; text: navItem.modelData[1]
                           color: navItem.on ? Theme.onAccent : Theme.text
                           font.family: Theme.titleFont; font.pixelSize: win.portrait ? 15 : 17 }
                    MouseArea { id: nm; anchors.fill: parent; hoverEnabled: true; onClicked: win.go(navItem.index) }
                }
            }
        }

        // ---- page card
        Item {
            id: page
            x: nav.x + nav.width + (win.portrait ? 24 : 40); y: nav.y
            width: parent.width - x - header.x; height: parent.height - y - (win.portrait ? 60 : 72)
            transform: Translate { id: pageT; x: 0 }
            Rectangle { x: Theme.shadow + 2; y: Theme.shadow + 2; width: parent.width; height: parent.height; color: Theme.accentB; opacity: 0.35
                        topLeftRadius: Theme.corner; topRightRadius: Theme.corner; bottomLeftRadius: Theme.corner }
            Rectangle {
                anchors.fill: parent
                color: Theme.surface; border.color: Theme.bg; border.width: 2
                topLeftRadius: Theme.corner; topRightRadius: Theme.corner; bottomLeftRadius: Theme.corner; bottomRightRadius: 0
                Rectangle { anchors.fill: parent; anchors.margins: 2; color: "transparent"; border.color: Theme.ring; border.width: 3
                            topLeftRadius: Theme.corner - 2; topRightRadius: Theme.corner - 2; bottomLeftRadius: Theme.corner - 2 }
            }
            Text { x: 32; y: 22; text: win.sections[win.section][0]; color: Theme.accentA
                   font.family: Theme.numeralFont; font.italic: true; font.weight: Font.ExtraBold; font.pixelSize: 54 }
            Text { x: 100; y: 36; text: win.sections[win.section][1]; color: Theme.text; font.family: Theme.titleFont; font.pixelSize: 26 }

            Flickable {
                x: 32; y: 100; width: parent.width - 64; height: parent.height - 120
                clip: true; contentHeight: pages.height; boundsBehavior: Flickable.StopAtBounds
                Item {
                    id: pages
                    width: parent.width
                    height: [p0, p1, p2, p3, p4, p5, p6, p8, p7][win.section].height

                    // 01 APPEARANCE
                    Column { id: p0; width: parent.width; visible: win.section === 0; spacing: 4
                        Setting { title: "OPEN STYLE"; hint: "How launcher and menus appear"
                            Chips { options: [["WIPE", "wipe"], ["TV", "tv"]]; current: Theme.openStyle
                                    onPicked: v => { Theme.openStyle = v; Theme.saveUi(); } } }
                        Setting { title: "COLORS"
                            hint: win.themeMode === "wallpaper" && win.wallSource === "" ? "▸ PICK A WALLPAPER BELOW: the colors come from it"
                                : "Black & white + green, or colors from the wallpaper"
                            Chips { options: [["BLACK & WHITE", "bw"], ["WALLPAPER", "wallpaper"]]
                                    current: win.themeMode
                                    onPicked: v => { win.themeMode = v; win.run([win.bin + "saphie-theme", v]); } } }
                        Setting { title: "WALLPAPER"; hint: "Add your own to ~/Pictures/Wallpapers"
                            Flow {
                                width: parent.width; spacing: 10
                                Repeater {
                                    model: [""].concat(win.wallpapers)
                                    Item {
                                        id: wp
                                        required property string modelData
                                        readonly property bool on: win.wallEngine === "" && modelData === win.wallSource
                                        width: 152; height: 86
                                        Rectangle { x: 4; y: 4; width: parent.width; height: parent.height; color: wp.on ? Theme.accentB : Theme.bg }
                                        Rectangle { anchors.fill: parent; color: "#101010"; border.width: wp.on ? 3 : 2
                                                    border.color: wp.on ? Theme.accentA : (wm.containsMouse ? Theme.text : Theme.ring) }
                                        Image { id: thumb; anchors.fill: parent; anchors.margins: 3; visible: wp.modelData !== ""
                                                readonly property string file: /\.webp$/i.test(wp.modelData) ? (win.thumbs[wp.modelData] ?? "") : wp.modelData
                                                source: file ? "file://" + file : ""
                                                asynchronous: true; cache: true; fillMode: Image.PreserveAspectCrop
                                                sourceSize.width: 300; sourceSize.height: 170 }
                                        Text { anchors.centerIn: parent; width: parent.width - 12; horizontalAlignment: Text.AlignHCenter
                                               elide: Text.ElideMiddle; visible: wp.modelData === "" || thumb.status === Image.Error
                                               text: wp.modelData === "" ? "NONE" : wp.modelData.split("/").pop(); color: Theme.textDim
                                               font.family: Theme.labelFont; font.pixelSize: 12; font.weight: Font.ExtraBold }
                                        Rectangle { visible: wp.on; anchors.left: parent.left; anchors.bottom: parent.bottom; width: 30; height: 18
                                                    color: Theme.accentA
                                                    Text { anchors.centerIn: parent; text: "ON"; color: Theme.onAccent
                                                           font.family: Theme.labelFont; font.pixelSize: 10; font.weight: Font.ExtraBold } }
                                        MouseArea { id: wm; anchors.fill: parent; hoverEnabled: true
                                            onClicked: { if (wp.on) return; Sfx.play("confirm");
                                                win.run(wp.modelData ? [win.bin + "saphie-theme", "set", wp.modelData] : [win.bin + "saphie-theme", "clear"]); } }
                                    }
                                }
                            } }
                        Setting { title: "WALLPAPER ENGINE"
                            hint: win.engineWalls.length ? ("Your Steam Wallpaper Engine wallpapers, animated. Paused while 3D apps and games are in front"
                                                            + (win.engineWalls.some(w => w.playable === false) ? ". WEB · OFF: web wallpapers need a sandbox Ubuntu blocks" : ""))
                                                        : "Install Wallpaper Engine in Steam to use its wallpapers here"
                            visible: win.engineWalls.length > 0
                            Column {
                                width: parent.width; spacing: 10
                                Flow {
                                    width: parent.width; spacing: 10
                                    Repeater {
                                        model: win.engineAll ? win.engineWalls : win.engineWalls.slice(0, 24)
                                        Item {
                                            id: ew
                                            required property var modelData
                                            readonly property bool on: modelData.path === win.wallEngine
                                            readonly property bool ok: modelData.playable !== false
                                            width: 152; height: 106
                                            opacity: ok ? 1 : 0.4
                                            Rectangle { x: 4; y: 4; width: parent.width; height: 86; color: ew.on ? Theme.accentB : Theme.bg }
                                            Rectangle { width: parent.width; height: 86; color: "#101010"; border.width: ew.on ? 3 : 2
                                                        border.color: ew.on ? Theme.accentA : (em.containsMouse ? Theme.text : Theme.ring) }
                                            Image { x: 3; y: 3; width: parent.width - 6; height: 80; visible: ew.modelData.preview !== ""
                                                    source: ew.modelData.preview ? "file://" + ew.modelData.preview : ""
                                                    asynchronous: true; cache: true; fillMode: Image.PreserveAspectCrop
                                                    sourceSize.width: 300; sourceSize.height: 170 }
                                            Rectangle { visible: ew.modelData.type === "video" || ew.modelData.type === "web"
                                                        anchors.right: parent.right; y: 0; width: tl.width + 10; height: 16; color: Theme.bg
                                                        Text { id: tl; anchors.centerIn: parent; text: ew.modelData.type.toUpperCase() + (ew.ok ? "" : " · OFF"); color: Theme.textDim
                                                               font.family: Theme.labelFont; font.pixelSize: 9; font.weight: Font.ExtraBold } }
                                            Rectangle { visible: ew.on; x: 0; y: 68; width: 30; height: 18; color: Theme.accentA
                                                        Text { anchors.centerIn: parent; text: "ON"; color: Theme.onAccent
                                                               font.family: Theme.labelFont; font.pixelSize: 10; font.weight: Font.ExtraBold } }
                                            Text { y: 90; width: parent.width; elide: Text.ElideRight; text: ew.modelData.title
                                                   color: ew.on ? Theme.accentA : Theme.textDim
                                                   font.family: Theme.labelFont; font.pixelSize: 11; font.weight: Font.Bold }
                                            MouseArea { id: em; anchors.fill: parent; hoverEnabled: true
                                                onClicked: { if (ew.on || !ew.ok) return; Sfx.play("confirm");
                                                    win.run([win.bin + "saphie-theme", "engine", ew.modelData.path]); } }
                                        }
                                    }
                                }
                                Rectangle {
                                    visible: win.engineWalls.length > 24
                                    width: moreT.width + 28; height: 30; color: moreM.containsMouse ? Theme.raised : Theme.bg
                                    border.color: Theme.ring; border.width: 2
                                    Text { id: moreT; anchors.centerIn: parent
                                           text: win.engineAll ? "SHOW LESS" : "SHOW ALL (" + win.engineWalls.length + ")"
                                           color: Theme.text; font.family: Theme.labelFont; font.pixelSize: 11; font.weight: Font.ExtraBold }
                                    MouseArea { id: moreM; anchors.fill: parent; hoverEnabled: true
                                                onClicked: { Sfx.play("tick"); win.engineAll = !win.engineAll; } }
                                }
                            } }
                        Setting { title: "HOTKEY SHEET AT LOGIN"; hint: "Super+Shift+/ always shows it"
                            Chips { options: [["ON", true], ["OFF", false]]; current: Theme.hotkeysAtLogin
                                    onPicked: v => { Theme.hotkeysAtLogin = v; Theme.saveUi(); } } }
                    }
                    // 02 SOUND
                    Column { id: p1; width: parent.width; visible: win.section === 1; spacing: 4
                        Setting { title: "VOLUME"; hint: win.sink ? Math.round((win.sink.audio?.volume ?? 0) * 100) + " %" : "No output"
                            Slide { value: win.sink?.audio?.volume ?? 0; width: Math.min(420, parent.width)
                                    onMoved: v => { if (win.sink?.audio) win.sink.audio.volume = v; } } }
                        Setting { title: "MUTE"
                            Chips { options: [["SOUND ON", false], ["MUTED", true]]; current: win.sink?.audio?.muted ?? false
                                    onPicked: v => { if (win.sink?.audio) win.sink.audio.muted = v; } } }
                        Setting { title: "OUTPUT"; hint: "Speakers, headphones, HDMI"
                            Column { spacing: 6
                                Repeater { model: win.sinks
                                    Chips { required property var modelData
                                            options: [[win.sinkName(modelData), modelData.id]]
                                            current: win.sink?.id ?? -1
                                            onPicked: v => { Pipewire.preferredDefaultAudioSink = modelData; } } } } }
                        Setting { title: "INPUT"; hint: win.mics.length ? "Microphone (headsets switch in by themselves)" : "No microphone found"
                            Column { spacing: 6
                                Repeater { model: win.mics
                                    Chips { required property var modelData
                                            options: [[win.devName(modelData, true), modelData.id]]
                                            current: win.mic?.id ?? -1
                                            onPicked: v => { Pipewire.preferredDefaultAudioSource = modelData; } } } } }
                        Setting { title: "MIC LEVEL"; hint: win.mic ? Math.round((win.mic.audio?.volume ?? 0) * 100) + " %" : "No microphone"
                            Slide { value: win.mic?.audio?.volume ?? 0; width: Math.min(420, parent.width)
                                    onMoved: v => { if (win.mic?.audio) win.mic.audio.volume = v; } } }
                        Setting { title: "MIC"
                            Chips { options: [["ON", false], ["MUTED", true]]; current: win.mic?.audio?.muted ?? false
                                    onPicked: v => { if (win.mic?.audio) win.mic.audio.muted = v; } } }
                        Setting { title: "UI SOUNDS"; hint: "Clicks, pings, TV switches"
                            Chips { options: [["ON", true], ["OFF", false]]; current: Theme.uiSounds
                                    onPicked: v => { Theme.uiSounds = v; Theme.saveUi(); if (v) Sfx.play("confirm"); } } }
                        Setting { title: "UI SOUND LEVEL"; hint: Math.round(Theme.soundVolume * 100) + " %"
                            Slide { value: Theme.soundVolume; width: Math.min(420, parent.width); live: false
                                    onReleased: v => { Theme.soundVolume = Math.round(v * 100) / 100; Theme.saveUi(); Sfx.play("notify"); } } }
                    }
                    // 03 DISPLAY
                    Column { id: p2; width: parent.width; visible: win.section === 2; spacing: 4
                        Setting { title: "BRIGHTNESS"; hint: win.brightness < 0 ? "No backlight control" : "Laptop screen · " + Math.round(win.brightness * 100) + " %"
                            Slide { visible: win.brightness >= 0; value: Math.max(0, win.brightness); width: Math.min(420, parent.width)
                                    onMoved: v => { win.brightness = v; Osd.setBrightnessFraction(v); } } }
                        Repeater { model: win.outputs
                            Setting { required property var modelData
                                      title: "SCREEN · " + modelData.name; hint: modelData.make
                                Text { text: modelData.mode + "   ROT " + modelData.rot.toUpperCase() + "   ×" + modelData.scale
                                       color: Theme.accentA; font.family: Theme.labelFont; font.pixelSize: 13; font.weight: Font.ExtraBold } } }
                        Setting { title: "ARRANGE + RESOLUTION"; hint: "Saved in the niri config (desktop/config/niri)"
                            Act { label: "MORE DISPLAY SETTINGS"; onHit: { win.hide(); win.run(["env", "XDG_CURRENT_DESKTOP=GNOME", "gnome-control-center", "display"]); } } }
                    }
                    // 04 NETWORK
                    Column { id: p3; width: parent.width; visible: win.section === 3; spacing: 4
                        Setting { title: "WI-FI"
                            Chips { options: [["ON", true], ["OFF", false]]; current: Networking.wifiEnabled
                                    onPicked: v => Networking.wifiEnabled = v } }
                        Setting { title: "CONNECTED TO"; hint: "Pick networks from the Wi-Fi sticker on the bar"
                            Text { text: win.wifiNow ? win.wifiNow.name : "—"; color: Theme.accentA
                                   font.family: Theme.titleFont; font.pixelSize: 18 } }
                        Setting { title: "VPN, PROXY, WIRED"
                            Act { label: "NETWORK SETTINGS"; onHit: { win.hide(); win.run(["env", "XDG_CURRENT_DESKTOP=GNOME", "gnome-control-center", "network"]); } } }
                    }
                    // 05 POWER
                    Column { id: p4; width: parent.width; visible: win.section === 4; spacing: 4
                        Setting { title: "POWER MODE"
                            hint: !PowerMode.available ? "perfd is not running (systemctl status perfd)"
                                : PowerMode.mode === "auto" ? "AUTO: performance while Blender/Unity/games run, balanced otherwise"
                                : "Forced until AUTO or a reboot, also on battery (click PWR on the bar to cycle)"
                            Chips { options: [["AUTO", "auto"], ["PERFORMANCE", "performance"], ["BALANCED", "balanced"], ["QUIET", "quiet"]]
                                    current: PowerMode.mode; enabled: PowerMode.available; opacity: enabled ? 1 : 0.4
                                    onPicked: v => PowerMode.set(v) } }
                        Setting { title: "FIRMWARE PROFILE NOW"; hint: "What perfd has set right now"
                            Text { text: win.profile ? win.profile.toUpperCase() : "—"; color: Theme.accentA
                                   font.family: Theme.titleFont; font.pixelSize: 18 } }
                        Setting { title: "AUTO-LOCK"; hint: "Lock after no input (videos and games can block it)"
                            Chips { options: Theme.idleLockChoices.map(m => [m ? m + " MIN" : "NEVER", m]); current: Theme.idleLockMin
                                    onPicked: v => { Theme.idleLockMin = v; Theme.saveUi(); } } }
                        Setting { title: "LOCK NOW"; hint: "Super+Alt+L"
                            Act { label: "LOCK"; onHit: { win.hide(); Locker.lock(); } } }
                        Setting { title: "BATTERY + SLEEP"
                            Act { label: "POWER SETTINGS"; onHit: { win.hide(); win.run(["env", "XDG_CURRENT_DESKTOP=GNOME", "gnome-control-center", "power"]); } } }
                    }
                    // 06 LAYOUTS
                    Column { id: p5; width: parent.width; visible: win.section === 5; spacing: 4
                        Setting { title: "LAYOUT"; hint: "Workspace on " + (win.focusedOutput || "this screen") + " · Super+Space cycles"
                            Flow { width: parent.width; spacing: 6
                                Chips { options: [["SCROLL", "scroll"], ["MASTER", "master"], ["DWINDLE", "dwindle"]]
                                        current: Niri.layoutFor(win.focusedOutput)
                                        onPicked: v => win.run(["/usr/local/opt/saphie/saphie-layout/bin/saphie-layout", "set", v]) }
                                Chips { options: [["GRID", "grid"], ["MONOCLE", "monocle"]]
                                        current: Niri.layoutFor(win.focusedOutput)
                                        onPicked: v => win.run(["/usr/local/opt/saphie/saphie-layout/bin/saphie-layout", "set", v]) } } }
                    }
                    // 07 KEYS
                    Column { id: p6; width: parent.width; visible: win.section === 6; spacing: 4
                        Setting { title: "HOTKEY SHEET"; hint: "All important keys in one place"
                            Act { label: "SHOW HOTKEYS"; onHit: { win.hide(); win.run([win.bin + "saphie-hotkeys"]); } } }
                        Setting { title: "KEYBOARD LAYOUT + SPEED"
                            Act { label: "KEYBOARD SETTINGS"; onHit: { win.hide(); win.run(["env", "XDG_CURRENT_DESKTOP=GNOME", "gnome-control-center", "keyboard"]); } } }
                    }
                    // 08 PROXY (voice assistant)
                    Column { id: p8; width: parent.width; visible: win.section === 7; spacing: 4
                        Setting { visible: !win.proxy; title: "PROXY IS NOT INSTALLED"; hint: "The voice assistant lives in ~/.local/opt/proxy"
                            Text { text: "—"; color: Theme.textDim; font.family: Theme.titleFont; font.pixelSize: 18 } }
                        Setting { visible: !!win.proxy; title: "AI SERVICE"
                            hint: !win.proxyCur ? "" : !win.proxyCur.supported ? "▸ COMING IN THE NEXT PROXY UPDATE: pick GEMINI for now"
                                : (win.proxyCur.tested ? "" : "▸ NEW, NOT TRIED WITH A REAL KEY YET · ")
                                  + (win.proxyCur.live ? "Talks live: interrupt it anytime" : "Step by step: your speech is turned into text on this PC first")
                            Chips { options: [["GEMINI", "gemini"], ["OPENAI", "openai"], ["CLAUDE", "claude"], ["LOCAL", "ollama"]]
                                    current: win.proxy ? win.proxy.provider : ""
                                    onPicked: v => { win.proxyMsg = ""; win.proxyRun(["provider", v]); } } }
                        Setting { visible: !!win.proxyCur && win.proxyCur.needs_key; title: "API KEY"
                            hint: !win.proxyCur ? "" : win.proxyCur.has_key ? "Saved on this PC only (~/.config/proxy/env)"
                                : "▸ PASTE YOUR KEY · get one at " + win.proxyCur.get_key
                            Row { spacing: 10
                                Item { width: 300; height: 36
                                    Rectangle { anchors.fill: parent; color: "#141414"; border.width: 2
                                                border.color: keyIn.activeFocus ? Theme.accentA : Theme.ring; transform: Skew { h: 36 } }
                                    TextInput { id: keyIn; x: 14; width: parent.width - 28; anchors.verticalCenter: parent.verticalCenter
                                                echoMode: TextInput.Password; color: Theme.text; clip: true; maximumLength: 300
                                                font.family: Theme.labelFont; font.pixelSize: 13
                                                onAccepted: { win.proxySaveKey(win.proxy.provider, text); text = ""; }
                                        Text { visible: !keyIn.text && !keyIn.activeFocus; anchors.verticalCenter: parent.verticalCenter
                                               text: win.proxyCur && win.proxyCur.has_key ? "•••• saved · paste to replace" : "paste key here"
                                               color: Theme.textDim; font.family: Theme.labelFont; font.pixelSize: 12 } }
                                    MouseArea { anchors.fill: parent; cursorShape: Qt.IBeamCursor; onClicked: keyIn.forceActiveFocus() } }
                                Act { label: "SAVE"; onHit: { win.proxySaveKey(win.proxy.provider, keyIn.text); keyIn.text = ""; keys.forceActiveFocus(); } }
                                Act { visible: !!win.proxyCur && win.proxyCur.has_key; label: "FORGET"
                                      onHit: { win.proxyMsg = ""; win.proxyRun(["forget", win.proxy.provider]); } } } }
                        Setting { visible: !!win.proxyCur; title: "MODEL"; hint: "Which model of this service Proxy uses"
                            Text { text: win.proxyCur ? win.proxyCur.model : ""; color: Theme.accentA; font.family: Theme.titleFont; font.pixelSize: 18 } }
                        Setting { visible: !!win.proxy; title: "AUDIENCE MODE"
                            hint: "Proxy watches your screen and reacts out loud (games, videos). Or say \"watch me play\""
                            Chips { options: [["ON", true], ["OFF", false]]; current: !!win.proxySettings.audience
                                    onPicked: v => win.proxySet("audience", v) } }
                        Setting { visible: !!win.proxyCur; title: "CHECK"
                            hint: win.proxyMsg ? (win.proxyMsgOk ? "OK: " : "▸ ") + win.proxyMsg.toUpperCase()
                                : "One small request to see that the key / server works"
                            Act { label: "TEST"; onHit: { win.proxyMsg = "testing…"; win.proxyMsgOk = true; win.proxyRun(["test", win.proxy.provider]); } } }
                    }
                    // 09 ABOUT
                    Column { id: p7; width: parent.width; visible: win.section === 8; spacing: 4
                        Image { width: Math.min(parent.width, 480); height: width * 768 / 2048
                                source: "file://" + Quickshell.shellDir + "/../../brand/logo/saphie-lockup.png"
                                sourceSize.width: 960; fillMode: Image.PreserveAspectFit; smooth: true; mipmap: true }
                        Repeater { model: win.about
                            Setting { required property var modelData; title: modelData[0]
                                Text { width: parent.width; wrapMode: Text.Wrap; text: modelData[1]; color: Theme.text
                                       font.family: Theme.labelFont; font.pixelSize: 13; font.weight: Font.Bold } } }
                        Setting { title: "EVERYTHING ELSE"
                            Act { label: "MORE SETTINGS"; onHit: { win.hide(); win.run(["env", "XDG_CURRENT_DESKTOP=GNOME", "gnome-control-center"]); } } }
                    }
                }
            }
        }

        Rectangle { id: wiper; visible: (openAnim.running || closeAnim.running) && Theme.openStyle === "wipe"
                    width: parent.width * 1.6; height: parent.height * 2; color: Theme.accentA; rotation: 20; x: -width; y: -parent.height * 0.5 }
    }
    Rectangle { id: tvLine; y: win.height / 2 - 2; width: win.width; height: 4; color: "#ffffff"; opacity: 0 }
    NumberAnimation { id: pageAnim; target: pageT; property: "x"; from: 26; to: 0; duration: 260; easing.type: Easing.OutBack; easing.overshoot: 1.8 }
    SequentialAnimation {
        id: openAnim
        ScriptAction { script: {
            const tv = Theme.openStyle === "tv";
            wiper.x = -wiper.width * 0.2; tvScale.yScale = tv ? 0.004 : 1; tvLine.opacity = tv ? 1 : 0;
        } }
        PauseAnimation { duration: 70 }
        ParallelAnimation {
            NumberAnimation { target: wiper; property: "x"; to: win.width + win.height; duration: 380; easing.type: Easing.OutCubic }
            NumberAnimation { target: tvScale; property: "yScale"; to: 1; duration: 340; easing.type: Easing.OutBack; easing.overshoot: 1.3 }
            NumberAnimation { target: tvLine; property: "opacity"; to: 0; duration: 220 }
            NumberAnimation { target: pageT; property: "x"; from: 40; to: 0; duration: 380; easing.type: Easing.OutBack; easing.overshoot: 1.5 }
        }
    }

    // Close animation (reverse of the open): wipe style = green panel sweeps back over the
    // screen; tv style = screen collapses into a white line (TV switch-off). Then the window goes.
    property bool closing: false
    function finishClose() {
        closeAnim.stop(); closing = false; open = false;
        wiper.x = -wiper.width; tvScale.yScale = 1; tvLine.opacity = 0;
    }
    SequentialAnimation {
        id: closeAnim
        ScriptAction { script: { win.closing = true; wiper.x = win.width + win.height; } }
        ParallelAnimation {
            NumberAnimation { target: wiper; property: "x"; to: -wiper.width * 0.2; duration: 240; easing.type: Easing.InCubic }
            NumberAnimation { target: tvScale; property: "yScale"; to: Theme.openStyle === "tv" ? 0.004 : 1; duration: 200; easing.type: Easing.InBack }
            NumberAnimation { target: tvLine; property: "opacity"; to: Theme.openStyle === "tv" ? 1 : 0; duration: 160 }
        }
        PauseAnimation { duration: 40 }
        ScriptAction { script: win.finishClose() }
    }
}
