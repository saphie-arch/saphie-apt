import Quickshell
import QtQuick

// VCR-style clock: big italic time, stacked mono date.
Row {
    property bool compact: false
    spacing: 8
    SystemClock { id: clock; precision: SystemClock.Minutes }

    Text {
        id: time
        anchors.verticalCenter: parent.verticalCenter
        text: Qt.formatDateTime(clock.date, "HH:mm")
        // Minute change: digits flip in from below.
        onTextChanged: tick.restart()
        transform: Translate { id: tickT; y: 0 }
        NumberAnimation { id: tick; target: tickT; property: "y"; from: 12; to: 0; duration: 300; easing.type: Easing.OutBack; easing.overshoot: 2.0 }
        color: Theme.text
        font.family: Theme.numeralFont
        font.weight: Font.ExtraBold
        font.italic: true
        font.pixelSize: compact ? 22 : 28
    }
    Column {
        anchors.verticalCenter: parent.verticalCenter
        visible: !compact
        Label { text: Qt.formatDateTime(clock.date, "ddd dd"); font.pixelSize: 10 }
        Label { text: Qt.formatDateTime(clock.date, "MMM yyyy"); font.pixelSize: 10 }
    }
}
