import QtQuick

// Small mono caps label.
Text {
    property bool dim: true
    color: dim ? Theme.textDim : Theme.text
    font.family: Theme.labelFont
    font.pixelSize: 11
    font.weight: Font.Medium
    font.letterSpacing: 0.9
    font.capitalization: Font.AllUppercase
    renderType: Text.NativeRendering
}
