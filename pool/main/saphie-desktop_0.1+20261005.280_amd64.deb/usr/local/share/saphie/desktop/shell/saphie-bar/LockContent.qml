import Quickshell
import QtQuick

// Visual content of the lock screen (also used by the preview in lock-test.qml).
Item {
    id: root
    anchors.fill: parent
    property bool main: true
    transform: Scale { id: tv; origin.x: root.width / 2; origin.y: root.height / 2; yScale: 1; xScale: 1 }
    Component.onCompleted: enter.start()
    Connections { target: Locker; function onUnlockingChanged() { if (Locker.unlocking) leave.restart(); } }
    Canvas {
        anchors.fill: parent; opacity: 0.05
        onPaint: { const c = getContext("2d"); c.fillStyle = "#ffffff"; for (let y = 0; y < height; y += 3) c.fillRect(0, y, width, 1); }
    }
    SystemClock { id: clock; precision: SystemClock.Seconds }

    Row {   // header: Saphie OS mark + name (same as the login screen)
        x: 48; y: 36; spacing: 10
        Image { width: 34; height: 34; anchors.verticalCenter: parent.verticalCenter
                source: "file://" + Quickshell.shellDir + "/../../brand/logo/saphie-96.png"
                sourceSize.width: 68; sourceSize.height: 68; smooth: true; mipmap: true }
        Text { anchors.verticalCenter: parent.verticalCenter; text: "SAPHIE"; color: Theme.text
               font.family: Theme.titleFont; font.pixelSize: 24 }
        Text { anchors.verticalCenter: parent.verticalCenter; text: "//  CH ▸ LOCKED"; color: Theme.textDim
               font.family: Theme.labelFont; font.pixelSize: 13; font.weight: Font.ExtraBold }
    }

    Column {
        anchors.centerIn: parent
        anchors.verticalCenterOffset: root.main ? -120 : 0
        spacing: 0
        Text {
            anchors.horizontalCenter: parent.horizontalCenter
            id: bigClock
            text: Qt.formatDateTime(clock.date, "HH:mm")
            color: Theme.text
            transform: Translate { id: clockT; y: 0 }
            onTextChanged: if (enterDone) flip.restart()
            property bool enterDone: false
            font.family: Theme.numeralFont; font.weight: Font.ExtraBold; font.italic: true
            font.pixelSize: Math.min(220, root.width / 5)
        }
        Rectangle {   // date on a green skewed plate
            id: datePlate
            anchors.horizontalCenter: parent.horizontalCenter
            width: dateText.implicitWidth + 40; height: 34
            color: Theme.accentA
            transform: Matrix4x4 { matrix: Qt.matrix4x4(1, Theme.skew, 0, -Theme.skew * 17, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1) }
            Text { id: dateText; anchors.centerIn: parent
                   text: Qt.formatDateTime(clock.date, "dddd  dd MMMM yyyy").toUpperCase()
                   color: Theme.onAccent; font.family: Theme.labelFont; font.pixelSize: 14; font.weight: Font.ExtraBold; font.letterSpacing: 2 }
        }
        Item { width: 1; height: 14 }
        Row {   // seconds: 60 ticks, one lights up per second (1 redraw/s)
            id: ticks
            anchors.horizontalCenter: parent.horizontalCenter
            spacing: 3
            readonly property int sec: clock.date.getSeconds()
            Repeater {
                model: 60
                Rectangle {
                    required property int index
                    width: 4; height: index % 5 === 0 ? 12 : 7
                    anchors.bottom: parent.bottom
                    color: index <= ticks.sec ? (index === ticks.sec ? "#ffffff" : Theme.accentA) : "#262626"
                }
            }
        }
    }

    // Password card (main screen only)
    Item {
        id: card
        visible: root.main
        anchors.horizontalCenter: parent.horizontalCenter
        anchors.top: parent.verticalCenter; anchors.topMargin: 60
        width: Math.min(520, root.width - 80); height: 170
        transform: [ Translate { id: shakeT; x: 0 }, Translate { id: riseT; y: 0 } ]
        Rectangle { x: 8; y: 8; width: parent.width; height: parent.height; color: "#000000"; border.color: "#1a1a1a" }
        Rectangle {
            anchors.fill: parent
            color: Theme.surface; border.color: Theme.bg; border.width: 2
            topLeftRadius: 20; topRightRadius: 20; bottomLeftRadius: 20; bottomRightRadius: 0
            Rectangle { anchors.fill: parent; anchors.margins: 2; color: "transparent"
                        border.color: Locker.error ? Theme.danger : Theme.ring; border.width: 3
                        topLeftRadius: 18; topRightRadius: 18; bottomLeftRadius: 18 }
        }
        Text {
            x: 28; y: 20
            text: (Quickshell.env("USER") ?? "USER").toUpperCase()
            color: Theme.text
            font.family: Theme.numeralFont; font.weight: Font.ExtraBold; font.italic: true; font.pixelSize: 34
        }
        Text {
            anchors.right: parent.right; anchors.rightMargin: 28; y: 30
            text: "SESSION LOCKED"
            color: Theme.accentA
            font.family: Theme.labelFont; font.pixelSize: 11; font.weight: Font.ExtraBold; font.letterSpacing: 1.6
        }
        Item {   // password field
            x: 28; y: 74; width: parent.width - 56; height: 48
            Rectangle {
                anchors.fill: parent
                color: "#0c0c0c"; border.color: pw.activeFocus ? Theme.accentA : Theme.ring; border.width: 3
                transform: Matrix4x4 { matrix: Qt.matrix4x4(1, Theme.skew, 0, -Theme.skew * 24, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1) }
            }
            Rectangle {
                id: errFill
                anchors.fill: parent; color: Theme.danger; opacity: 0
                transform: Matrix4x4 { matrix: Qt.matrix4x4(1, Theme.skew, 0, -Theme.skew * 24, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1) }
                SequentialAnimation { id: redFlash
                    NumberAnimation { target: errFill; property: "opacity"; to: 0.6; duration: 60 }
                    NumberAnimation { target: errFill; property: "opacity"; to: 0; duration: 400 } }
            }
            Row {   // typed characters as green diamonds
                x: 22; anchors.verticalCenter: parent.verticalCenter
                spacing: 7
                Repeater {
                    model: Math.min(pw.text.length, 24)
                    Rectangle {
                        width: 10; height: 10; rotation: 45; color: Theme.accentA
                        scale: 0
                        Component.onCompleted: pop.start()
                        NumberAnimation on scale { id: pop; running: false; from: 0; to: 1; duration: 180; easing.type: Easing.OutBack; easing.overshoot: 3 }
                    }
                }
            }
            Text {
                x: 22; anchors.verticalCenter: parent.verticalCenter
                visible: pw.text.length === 0
                text: "PASSWORD"; color: Theme.raised
                font.family: Theme.labelFont; font.pixelSize: 16; font.letterSpacing: 2
            }
            TextInput {
                id: pw
                anchors.fill: parent
                opacity: 0                      // drawn as diamonds above
                echoMode: TextInput.Password
                maximumLength: 256
                focus: root.main
                enabled: !Locker.busy
                Keys.onReturnPressed: { Locker.submit(text); text = ""; }
                Keys.onEnterPressed: { Locker.submit(text); text = ""; }
                Keys.onEscapePressed: text = ""
                Component.onCompleted: if (root.main) forceActiveFocus()
            }
        }
        Text {
            x: 28; y: 134
            text: Locker.message || "ENTER TO UNLOCK"
            color: Locker.error ? Theme.danger : Theme.textDim
            font.family: Theme.labelFont; font.pixelSize: 11; font.weight: Font.ExtraBold; font.letterSpacing: 1.4
        }
        Connections {
            target: Locker
            function onFailed() { Sfx.play("error"); shake.restart(); redFlash.restart(); pw.forceActiveFocus(); }
        }
        SequentialAnimation {
            id: shake
            NumberAnimation { target: shakeT; property: "x"; to: -16; duration: 45 }
            NumberAnimation { target: shakeT; property: "x"; to: 14; duration: 60 }
            NumberAnimation { target: shakeT; property: "x"; to: -9; duration: 55 }
            NumberAnimation { target: shakeT; property: "x"; to: 0; duration: 140; easing.type: Easing.OutBack }
        }
    }
    MouseArea { anchors.fill: parent; z: -1; onClicked: pw.forceActiveFocus() }

    Rectangle { id: tvLine; anchors.centerIn: parent; width: parent.width; height: 4; color: "#ffffff"; opacity: 0 }

    // Enter: TV switch-on, clock drops, date and ticks fade in, card rises
    SequentialAnimation {
        id: enter
        ScriptAction { script: {
            tv.yScale = 0.004; tvLine.opacity = 1; clockT.y = -60; bigClock.opacity = 0;
            datePlate.opacity = 0; riseT.y = 80; card.opacity = 0; ticks.opacity = 0;
        } }
        PauseAnimation { duration: 60 }
        ParallelAnimation {
            NumberAnimation { target: tv; property: "yScale"; to: 1; duration: 340; easing.type: Easing.OutBack; easing.overshoot: 1.3 }
            NumberAnimation { target: tvLine; property: "opacity"; to: 0; duration: 220 }
        }
        ParallelAnimation {
            NumberAnimation { target: clockT; property: "y"; to: 0; duration: 360; easing.type: Easing.OutBack; easing.overshoot: 1.8 }
            NumberAnimation { target: bigClock; property: "opacity"; to: 1; duration: 120 }
            SequentialAnimation { PauseAnimation { duration: 90 } NumberAnimation { target: datePlate; property: "opacity"; to: 1; duration: 100 } }
            SequentialAnimation { PauseAnimation { duration: 150 } NumberAnimation { target: ticks; property: "opacity"; to: 1; duration: 200 } }
            SequentialAnimation {
                PauseAnimation { duration: 180 }
                ParallelAnimation {
                    NumberAnimation { target: riseT; property: "y"; to: 0; duration: 380; easing.type: Easing.OutBack; easing.overshoot: 1.6 }
                    NumberAnimation { target: card; property: "opacity"; to: 1; duration: 120 }
                }
            }
        }
        ScriptAction { script: bigClock.enterDone = true }
    }
    // Minute change: digits flip in from below
    NumberAnimation { id: flip; target: clockT; property: "y"; from: 30; to: 0; duration: 320; easing.type: Easing.OutBack; easing.overshoot: 2 }
    // Unlock: TV switch-off (Locker releases the lock after 300 ms)
    SequentialAnimation {
        id: leave
        NumberAnimation { target: tv; property: "xScale"; to: 1.03; duration: 50 }
        ParallelAnimation {
            NumberAnimation { target: tv; property: "yScale"; to: 0.004; duration: 170; easing.type: Easing.InQuad }
            NumberAnimation { target: tvLine; property: "opacity"; to: 1; duration: 170 }
        }
        ParallelAnimation {
            NumberAnimation { target: tv; property: "xScale"; to: 0; duration: 90; easing.type: Easing.InQuad }
            NumberAnimation { target: root; property: "opacity"; to: 0; duration: 90 }
        }
    }
}
