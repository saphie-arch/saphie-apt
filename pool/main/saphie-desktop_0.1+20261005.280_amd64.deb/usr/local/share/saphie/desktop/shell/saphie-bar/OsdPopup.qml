import Quickshell
import Quickshell.Wayland
import QtQuick

// Volume / brightness pop-up: bottom centre of the focused monitor, ~1.2 s, click-through.
PanelWindow {
    id: win
    required property var modelData
    screen: modelData
    // Brightness belongs to the built-in panel (eDP/LVDS), so show it there; everything else
    // shows on the focused monitor.
    readonly property bool isPanel: /^(eDP|LVDS|DSI)/.test(modelData.name)
    readonly property bool hasPanel: Quickshell.screens.some(s => /^(eDP|LVDS|DSI)/.test(s.name))
    readonly property bool active: {
        if (Osd.kind === "BRIGHTNESS" && hasPanel) return isPanel;
        const ws = Niri.workspaces.find(w => w.is_focused);
        return ws ? ws.output === modelData.name : modelData === Quickshell.screens[0];
    }
    property bool showing: false
    visible: showing && active
    anchors.bottom: true
    margins.bottom: 90
    implicitWidth: 420; implicitHeight: 110
    exclusionMode: ExclusionMode.Ignore
    color: "transparent"
    mask: Region {}
    WlrLayershell.layer: WlrLayer.Overlay
    WlrLayershell.namespace: "saphie-osd-level"

    Connections {
        target: Osd
        function onSerialChanged() {
            if (!win.active) return;
            if (!win.showing) { win.showing = true; inAnim.restart(); } else bump.restart();
            hideTimer.restart();
        }
    }
    Timer { id: hideTimer; interval: 1200; onTriggered: outAnim.restart() }

    Item {
        id: card
        anchors.centerIn: parent
        width: 380; height: 84
        transform: Translate { id: slide; y: 0 }
        Rectangle { x: 6; y: 6; width: parent.width; height: parent.height; color: Theme.bg }
        Rectangle {
            anchors.fill: parent
            color: Theme.surface; border.color: Theme.bg; border.width: 2
            topLeftRadius: Theme.corner; topRightRadius: Theme.corner; bottomLeftRadius: Theme.corner; bottomRightRadius: 0
            Rectangle { anchors.fill: parent; anchors.margins: 2; color: "transparent"; border.color: Theme.ring; border.width: 3
                        topLeftRadius: Theme.corner - 2; topRightRadius: Theme.corner - 2; bottomLeftRadius: Theme.corner - 2 }
        }
        Text {
            x: 22; y: 12
            text: Osd.kind
            color: Osd.kind.indexOf("MUTED") >= 0 ? Theme.danger : Theme.accentA
            font.family: Theme.labelFont; font.pixelSize: 11; font.weight: Font.ExtraBold; font.letterSpacing: 1.6
        }
        Text {
            id: num
            anchors.right: parent.right; anchors.rightMargin: 22; y: 4
            text: Math.round(Osd.value * 100)
            color: Theme.text
            font.family: Theme.numeralFont; font.weight: Font.ExtraBold; font.italic: true; font.pixelSize: 40
        }
        Row {   // 20 blocks
            x: 22; y: 46
            spacing: 3
            Repeater {
                model: 20
                Rectangle {
                    required property int index
                    readonly property bool lit: Osd.kind.indexOf("MUTED") < 0 && Osd.value * 20 > index + 0.25
                    width: 13; height: 20
                    color: lit ? (index >= 16 ? Theme.accentA : Theme.text) : Theme.ring
                    transform: Matrix4x4 { matrix: Qt.matrix4x4(1, Theme.skew, 0, -Theme.skew * 10, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1) }
                    Behavior on color { ColorAnimation { duration: 80 } }
                }
            }
        }
    }
    SequentialAnimation {
        id: inAnim
        ScriptAction { script: { slide.y = 40; card.opacity = 0; card.scale = 1; } }
        ParallelAnimation {
            NumberAnimation { target: slide; property: "y"; to: 0; duration: 260; easing.type: Easing.OutBack; easing.overshoot: 1.8 }
            NumberAnimation { target: card; property: "opacity"; to: 1; duration: 90 }
        }
    }
    SequentialAnimation {
        id: bump
        NumberAnimation { target: card; property: "scale"; to: 1.04; duration: 50 }
        NumberAnimation { target: card; property: "scale"; to: 1; duration: 180; easing.type: Easing.OutBack; easing.overshoot: 2.5 }
    }
    SequentialAnimation {
        id: outAnim
        ParallelAnimation {
            NumberAnimation { target: slide; property: "y"; to: 30; duration: 160; easing.type: Easing.InQuad }
            NumberAnimation { target: card; property: "opacity"; to: 0; duration: 160 }
        }
        ScriptAction { script: win.showing = false }
    }
}
