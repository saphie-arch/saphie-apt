import QtQuick

// Bar content for Render34: "R 42% · cam2" with a thin progress bar while the render PC works,
// "QUEUE 2" when jobs wait, "✓ cam2" for 10 min after a render finished. Hidden otherwise
// (show = false), and when the render PC isn't set up or can't be reached.
Row {
    id: root
    readonly property var cur: Render.current
    readonly property var done: Render.state ? Render.state.last_done : null
    readonly property bool recentDone: !!done && !!done.finished_at
                                       && (Date.now() / 1000 - Number(done.finished_at)) < 600
    readonly property bool show: Render.configured && Render.online && (!!cur || Render.queued > 0 || recentDone)
    property bool flash: false
    spacing: 8

    // a finished render flashes the sticker green once
    property string lastDoneId: ""
    onDoneChanged: {
        if (done && done.id !== lastDoneId) {
            if (lastDoneId !== "") { flash = true; flashOff.restart(); Sfx.play("notify"); }
            lastDoneId = done.id;
        }
    }
    Timer { id: flashOff; interval: 2500; onTriggered: root.flash = false }

    Text {   // "R" mark
        anchors.verticalCenter: parent.verticalCenter
        text: root.cur ? "R" : (Render.queued > 0 ? "Q" : "✓")
        color: Theme.accentA
        font.family: Theme.titleFont; font.pixelSize: 15
    }
    Column {
        anchors.verticalCenter: parent.verticalCenter
        spacing: 3
        Text {
            text: root.cur
                  ? Math.round(root.cur.percent || 0) + "%  " + Render.shortName(root.cur.blend).toUpperCase().slice(0, 18)
                  : (Render.queued > 0 ? "QUEUE " + Render.queued
                                       : Render.shortName(root.done ? root.done.blend : "").toUpperCase().slice(0, 18))
            color: root.flash ? Theme.accentA : Theme.text
            font.family: Theme.labelFont; font.pixelSize: 11; font.weight: Font.ExtraBold; font.letterSpacing: 1
        }
        Rectangle {   // progress
            visible: !!root.cur
            width: 96; height: 4
            color: Theme.raised
            Rectangle {
                width: parent.width * Math.max(0, Math.min(1, (root.cur ? root.cur.percent : 0) / 100))
                height: parent.height; color: Theme.accentA
                Behavior on width { NumberAnimation { duration: 400; easing.type: Easing.OutCubic } }
            }
        }
    }
}
