import Quickshell
import Quickshell.Wayland
import Quickshell.Services.Notifications
import QtQuick

// App notifications (downloads, updates, system, the Claude app...): compact sticker cards at the
// top right under the bar, separate from social messages/calls (NotificationPopups.qml, bottom
// right). Icon, app name, title, text and the app's own buttons. Click = the app's default
// action. Not added to Saphie Chat.
PanelWindow {
    id: win
    required property var modelData
    screen: modelData
    readonly property bool active: {
        const ws = Niri.workspaces.find(w => w.is_focused);
        return ws ? ws.output === modelData.name : modelData === Quickshell.screens[0];
    }
    visible: active && Notifs.appNotes.length > 0
    anchors { top: true; right: true }
    readonly property int pad: 16
    margins { top: 46 }
    implicitWidth: 340 + 12 + pad
    implicitHeight: Math.max(1, stack.implicitHeight + 2 * pad)
    exclusionMode: ExclusionMode.Ignore
    color: "transparent"
    WlrLayershell.layer: WlrLayer.Overlay
    WlrLayershell.namespace: "saphie-app-notifications"

    Column {
        id: stack
        x: win.pad; y: win.pad
        width: 340 - 6
        spacing: 8
        Repeater {
            model: Notifs.appNotes
            Item {
                id: card
                required property var modelData
                readonly property var n: modelData.n
                readonly property bool critical: n.urgency === NotificationUrgency.Critical
                readonly property var buttons: Notifs.acts(n).filter(a => a.identifier !== "default" && a.text).slice(0, 3)
                width: stack.width
                height: col.implicitHeight + 20
                transform: Translate { id: slide; x: 380 }
                Component.onCompleted: inAnim.start()
                Timer {
                    running: !card.critical && !hover.containsMouse
                    interval: card.n.expireTimeout > 0 ? Math.min(card.n.expireTimeout, 20) * 1000 : 5000
                    onTriggered: Notifs.removeApp(card.modelData.id)
                }
                NumberAnimation { id: inAnim; target: slide; property: "x"; to: 0; duration: 280; easing.type: Easing.OutBack; easing.overshoot: 1.4 }

                Rectangle { x: 4; y: 4; width: parent.width; height: parent.height; color: Theme.bg }
                Rectangle {
                    anchors.fill: parent; color: Theme.surface
                    border.color: card.critical ? Theme.danger : Theme.ring; border.width: 2
                    topLeftRadius: 10; topRightRadius: 10; bottomLeftRadius: 10; bottomRightRadius: 0
                }
                MouseArea { id: hover; anchors.fill: parent; hoverEnabled: true; onClicked: Notifs.activateApp(card.modelData) }

                Column {
                    id: col
                    x: 12; y: 10; width: parent.width - 36
                    spacing: 6
                    Row {
                        width: parent.width; spacing: 10
                        Image {
                            id: icon
                            width: 26; height: 26; visible: status === Image.Ready
                            source: card.n.image || (card.n.appIcon ? Quickshell.iconPath(card.n.appIcon, true) : "")
                            sourceSize.width: 52; sourceSize.height: 52; fillMode: Image.PreserveAspectFit; asynchronous: true
                        }
                        Column {
                            width: parent.width - (icon.visible ? 36 : 0); spacing: 1
                            Text { text: (card.n.appName || "SYSTEM").toUpperCase(); color: card.critical ? Theme.danger : Theme.textDim
                                   font.family: Theme.labelFont; font.pixelSize: 9; font.weight: Font.ExtraBold; font.letterSpacing: 1
                                   width: parent.width; elide: Text.ElideRight }
                            Text { width: parent.width; elide: Text.ElideRight; text: card.n.summary; textFormat: Text.PlainText
                                   color: Theme.text; font.family: Theme.fontFor(text, Theme.labelFont); font.pixelSize: 13; font.weight: Font.Bold }
                            Text { width: parent.width; visible: text.length > 0; text: Notifs.cleanBody(card.n.body); textFormat: Text.PlainText
                                   wrapMode: Text.Wrap; maximumLineCount: 2; elide: Text.ElideRight
                                   color: Theme.textDim; font.family: Theme.fontFor(text, Theme.labelFont); font.pixelSize: 11 }
                        }
                    }
                    Row {   // the app's own buttons
                        visible: card.buttons.length > 0
                        spacing: 6
                        Repeater {
                            model: card.buttons
                            Rectangle {
                                required property var modelData
                                width: bt.implicitWidth + 18; height: 22
                                color: bm.containsMouse ? Theme.accentA : "transparent"; border.color: Theme.raised; border.width: 1
                                Text { id: bt; anchors.centerIn: parent; text: parent.modelData.text.toUpperCase().slice(0, 24)
                                       color: bm.containsMouse ? Theme.onAccent : Theme.text
                                       font.family: Theme.labelFont; font.pixelSize: 10; font.weight: Font.ExtraBold }
                                MouseArea { id: bm; anchors.fill: parent; hoverEnabled: true
                                            onClicked: { parent.modelData.invoke(); Notifs.removeApp(card.modelData.id); } }
                            }
                        }
                    }
                }
                Text {
                    anchors.right: parent.right; anchors.rightMargin: 10; y: 8
                    text: "✕"; color: cm.containsMouse ? Theme.accentA : Theme.raised; font.pixelSize: 11; font.weight: Font.Black
                    MouseArea { id: cm; anchors.fill: parent; anchors.margins: -6; hoverEnabled: true; onClicked: Notifs.dismissApp(card.modelData) }
                }
            }
        }
    }
}
