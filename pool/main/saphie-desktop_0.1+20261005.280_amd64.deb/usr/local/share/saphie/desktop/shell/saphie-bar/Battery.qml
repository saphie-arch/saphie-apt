import Quickshell.Services.UPower
import QtQuick

// Laptop battery: segmented cell, %, charging bolt, time left. Hidden when no battery exists.
Row {
    id: root
    readonly property var dev: UPower.displayDevice
    readonly property bool present: dev && dev.ready && dev.isPresent && dev.isLaptopBattery
    readonly property real pct: present ? Math.max(0, Math.min(100, dev.percentage > 1 ? dev.percentage : dev.percentage * 100)) : 0
    readonly property bool charging: present && (dev.state === UPowerDeviceState.Charging || dev.state === UPowerDeviceState.FullyCharged)
    readonly property bool low: present && !charging && pct <= 15
    visible: present
    spacing: 8

    function hm(secs) {
        if (!(secs > 0)) return "";
        const h = Math.floor(secs / 3600), m = Math.round((secs % 3600) / 60);
        return h > 0 ? h + "H" + String(m).padStart(2, "0") : m + "M";
    }

    Item {   // battery cell
        anchors.verticalCenter: parent.verticalCenter
        width: 30; height: 14
        Rectangle { width: 27; height: 14; color: "transparent"; border.color: root.low ? Theme.danger : Theme.text; border.width: 2 }
        Rectangle { x: 27; y: 4; width: 3; height: 6; color: root.low ? Theme.danger : Theme.text }
        Row {
            x: 4; y: 4; spacing: 1
            Repeater {
                model: 5
                Rectangle {
                    required property int index
                    width: 3; height: 6
                    color: root.pct > index * 20 + 5 ? (root.low ? Theme.danger : (root.charging ? Theme.accentA : Theme.text)) : "transparent"
                }
            }
        }
        SequentialAnimation on opacity {   // low battery blink
            running: root.low; loops: Animation.Infinite
            NumberAnimation { to: 0.3; duration: 500 } NumberAnimation { to: 1; duration: 500 }
            onStopped: parent.opacity = 1
        }
    }
    Label {
        anchors.verticalCenter: parent.verticalCenter
        dim: false
        font.weight: Font.ExtraBold
        color: root.low ? Theme.danger : (root.charging ? Theme.accentA : Theme.text)
        text: (root.charging ? "⚡" : "") + Math.round(root.pct) + "%"
    }
    Label {
        anchors.verticalCenter: parent.verticalCenter
        font.pixelSize: 10
        visible: text.length > 0
        text: root.charging ? root.hm(root.dev.timeToFull) : root.hm(root.dev.timeToEmpty)
    }
}
