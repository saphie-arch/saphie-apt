import Quickshell
import Quickshell.Wayland
import QtQuick

// "Channel change" card shown for ~1 s on a monitor when its layout changes (MASTER, GRID, ...).
// ZZZ-style: bright green skewed plate, big italic name, white flash, snap in / slide out.
// Click-through (empty input mask) and hidden when idle, so it never blocks anything.
PanelWindow {
    id: osd
    required property var modelData
    screen: modelData

    readonly property string mode: Niri.layoutFor(modelData.name)
    property bool ready: false          // ignore the initial load of the status file
    property bool showing: false

    visible: showing
    color: "transparent"
    implicitWidth: 560
    implicitHeight: 190
    exclusionMode: ExclusionMode.Ignore
    mask: Region {}
    WlrLayershell.layer: WlrLayer.Overlay
    WlrLayershell.namespace: "saphie-osd"

    Timer { interval: 1500; running: true; onTriggered: osd.ready = true }
    onModeChanged: if (ready) { showing = true; play.restart(); Sfx.play("layout"); }

    Item {
        id: card
        anchors.centerIn: parent
        width: 460; height: 120
        opacity: 0
        transform: Translate { id: slide; x: -90 }

        Rectangle {   // hard shadow plate
            x: 8; y: 8; width: parent.width; height: parent.height
            color: Theme.bg
            transform: Matrix4x4 { matrix: Qt.matrix4x4(1, Theme.skew, 0, -Theme.skew * 60, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1) }
        }
        Rectangle {   // green plate
            id: plate
            anchors.fill: parent
            color: Theme.accentA
            border.color: Theme.bg; border.width: 4
            transform: Matrix4x4 { matrix: Qt.matrix4x4(1, Theme.skew, 0, -Theme.skew * 60, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1) }
            Rectangle {   // scanlines
                anchors.fill: parent; anchors.margins: 4
                color: "transparent"
                Column {
                    anchors.fill: parent
                    spacing: 2
                    Repeater {
                        model: 37
                        Rectangle { width: parent.width; height: 1; color: "#18000000" }
                    }
                }
            }
        }
        Text {
            x: 34; y: 12
            text: "LAYOUT  //  " + osd.modelData.name
            color: Theme.onAccent
            font.family: Theme.labelFont; font.pixelSize: 12; font.weight: Font.ExtraBold
            font.letterSpacing: 1.5
        }
        Text {
            x: 30; anchors.bottom: parent.bottom; anchors.bottomMargin: 2
            text: osd.mode.toUpperCase()
            color: Theme.onAccent
            font.family: Theme.numeralFont; font.weight: Font.ExtraBold; font.italic: true
            font.pixelSize: 84
        }
        Rectangle {   // white flash
            id: flash
            anchors.fill: parent
            color: "#ffffff"; opacity: 0
            transform: Matrix4x4 { matrix: Qt.matrix4x4(1, Theme.skew, 0, -Theme.skew * 60, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1) }
        }
    }

    SequentialAnimation {
        id: play
        ScriptAction { script: { slide.x = -90; card.scale = 0.7; card.opacity = 0; flash.opacity = 0; } }
        ParallelAnimation {
            NumberAnimation { target: slide; property: "x"; to: 0; duration: 260; easing.type: Easing.OutBack; easing.overshoot: 1.8 }
            NumberAnimation { target: card; property: "scale"; to: 1; duration: 260; easing.type: Easing.OutBack; easing.overshoot: 2.2 }
            NumberAnimation { target: card; property: "opacity"; to: 1; duration: 70 }
            SequentialAnimation {
                NumberAnimation { target: flash; property: "opacity"; to: 0.85; duration: 40 }
                NumberAnimation { target: flash; property: "opacity"; to: 0; duration: 180 }
            }
        }
        PauseAnimation { duration: 550 }
        ParallelAnimation {
            NumberAnimation { target: slide; property: "x"; to: 110; duration: 180; easing.type: Easing.InQuad }
            NumberAnimation { target: card; property: "opacity"; to: 0; duration: 180 }
        }
        ScriptAction { script: osd.showing = false }
    }
}
