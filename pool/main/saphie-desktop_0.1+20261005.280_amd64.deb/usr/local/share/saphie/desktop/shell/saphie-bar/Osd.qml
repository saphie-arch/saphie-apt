pragma Singleton
import Quickshell
import Quickshell.Io
import Quickshell.Services.Pipewire
import Quickshell.Services.Mpris
import QtQuick

// Volume / brightness / mic state for the on-screen pop-up, plus the actions behind the
// media and brightness keys (no brightnessctl/playerctl needed: logind + MPRIS).
Singleton {
    id: root
    property string kind: ""        // "VOLUME" | "MUTED" | "BRIGHTNESS" | "MIC" | "MIC MUTED"
    property real value: 0          // 0..1
    property int serial: 0          // bumps on every show (restarts the hide timer/animation)
    function show(k, v) { kind = k; value = Math.max(0, Math.min(1, v)); serial++; }

    // --- volume (any source: keys, bar, apps)
    readonly property var sink: Pipewire.defaultAudioSink
    readonly property var source: Pipewire.defaultAudioSource
    PwObjectTracker { objects: [root.sink, root.source].filter(o => o) }
    property bool ready: false
    Timer { interval: 1500; running: true; onTriggered: root.ready = true }   // ignore startup values
    Connections {
        target: root.sink?.audio ?? null
        function onVolumesChanged() { if (root.ready) root.show(root.sink.audio.muted ? "MUTED" : "VOLUME", root.sink.audio.volume); }
        function onMutedChanged() { if (root.ready) root.show(root.sink.audio.muted ? "MUTED" : "VOLUME", root.sink.audio.volume); }
    }
    Connections {
        target: root.source?.audio ?? null
        function onMutedChanged() { if (root.ready) root.show(root.source.audio.muted ? "MIC MUTED" : "MIC", root.source.audio.volume); }
    }

    // --- brightness: sysfs to read, logind SetBrightness to write (works without root)
    property string backlight: ""
    property int maxBrightness: 0
    Process {
        running: true
        command: ["sh", "-c", "ls /sys/class/backlight | head -1"]
        stdout: SplitParser { onRead: l => { if (/^[A-Za-z0-9_.-]+$/.test(l.trim())) root.backlight = l.trim(); } }
    }
    FileView { id: bMax; path: root.backlight ? "/sys/class/backlight/" + root.backlight + "/max_brightness" : ""
               printErrors: false; blockLoading: true }
    FileView { id: bCur; path: root.backlight ? "/sys/class/backlight/" + root.backlight + "/brightness" : ""
               printErrors: false; blockLoading: true }
    function brightness(deltaPct) {
        if (!backlight) return;
        bMax.reload(); bCur.reload();
        bMax.waitForJob(); bCur.waitForJob();     // reload() is async: read the fresh value
        const max = parseInt(bMax.text()), cur = parseInt(bCur.text());
        if (!(max > 0) || !(cur >= 0)) return;
        const minV = Math.ceil(max * 0.01);                       // never fully black
        const next = Math.round(Math.max(minV, Math.min(max, cur + max * deltaPct / 100)));
        Quickshell.execDetached(["busctl", "call", "org.freedesktop.login1", "/org/freedesktop/login1/session/auto",
                                 "org.freedesktop.login1.Session", "SetBrightness", "ssu", "backlight", backlight, String(next)]);
        show("BRIGHTNESS", next / max);
    }

    // Absolute brightness for Saphie Settings: fraction 0..1 (read) and set (1 % minimum).
    function brightnessFraction() {
        if (!backlight) return -1;
        bMax.reload(); bCur.reload(); bMax.waitForJob(); bCur.waitForJob();
        const max = parseInt(bMax.text()), cur = parseInt(bCur.text());
        return max > 0 && cur >= 0 ? cur / max : -1;
    }
    function setBrightnessFraction(f) {
        if (!backlight) return;
        bMax.reload(); bMax.waitForJob();
        const max = parseInt(bMax.text());
        if (!(max > 0) || !(f >= 0 && f <= 1)) return;
        const next = Math.round(Math.max(Math.ceil(max * 0.01), Math.min(max, max * f)));
        Quickshell.execDetached(["busctl", "call", "org.freedesktop.login1", "/org/freedesktop/login1/session/auto",
                                 "org.freedesktop.login1.Session", "SetBrightness", "ssu", "backlight", backlight, String(next)]);
    }

    // --- media keys via MPRIS (playing player first)
    function media(cmd) {
        const ps = Mpris.players.values;
        const p = ps.find(x => x.isPlaying) ?? ps[0];
        if (!p) return;
        if (cmd === "playpause" && p.canTogglePlaying) p.togglePlaying();
        else if (cmd === "next" && p.canGoNext) p.next();
        else if (cmd === "previous" && p.canGoPrevious) p.previous();
        else if (cmd === "stop") p.stop();
    }
}
