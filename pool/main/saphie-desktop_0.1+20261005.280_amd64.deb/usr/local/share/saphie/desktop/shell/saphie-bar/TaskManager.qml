import Quickshell
import Quickshell.Io
import Quickshell.Wayland
import QtQuick

// Saphie task manager (click CPU on the bar, or Ctrl+Shift+Esc). ZZZ menu style.
// PROCESSES: current CPU (sampled), RAM, END TASK (SIGTERM) / FORCE KILL (SIGKILL, confirm).
// Only your own processes can be ended. PERFORMANCE: cores, CPU history, RAM, GPU.
// Search: just start typing (or Ctrl+F / click the box) - matches name, app (firefox finds its
// "Isolated Web Co" helpers) or PID. Esc clears the search first, then closes.
// Data comes from desktop/bin/saphie-top, which runs only while this is open.
PanelWindow {
    id: win
    required property var modelData
    screen: modelData
    property bool open: false
    visible: open
    color: "transparent"
    anchors { top: true; bottom: true; left: true; right: true }
    exclusionMode: ExclusionMode.Ignore
    WlrLayershell.layer: WlrLayer.Overlay
    WlrLayershell.namespace: "saphie-taskmanager"
    WlrLayershell.keyboardFocus: open ? WlrKeyboardFocus.Exclusive : WlrKeyboardFocus.None

    property var stats: null           // latest sample from saphie-top (not "data": reserved)
    property var history: []
    property int tab: 0                 // 0 processes, 1 performance
    property string sortBy: "cpu"           // cpu | mem | disk | gpu
    readonly property int colsW: 110 + 90 + 90 + 70 + 60     // CPU RAM DISK GPU THR
    // Thin track + bright green thumb for a Flickable (shown only when it overflows); draggable.
    component GreenBar: Rectangle {
        id: gb
        property Flickable target
        visible: target && target.contentHeight > target.height + 1
        width: 6; color: Theme.ring
        Rectangle {
            id: thumb
            width: parent.width; color: Theme.accentA
            height: gb.target ? Math.max(30, gb.height * gb.target.height / Math.max(1, gb.target.contentHeight)) : 30
            y: gb.target ? (gb.height - height) * (gb.target.contentY / Math.max(1, gb.target.contentHeight - gb.target.height)) : 0
        }
        MouseArea {
            anchors.fill: parent; anchors.margins: -6
            function go(py) { const t = gb.target; t.contentY = Math.max(0, Math.min(t.contentHeight - t.height,
                                   (py - thumb.height / 2) / Math.max(1, gb.height - thumb.height) * (t.contentHeight - t.height))); }
            onPressed: ev => go(ev.y)
            onPositionChanged: ev => { if (pressed) go(ev.y); }
        }
    }
    function rate(b) { return b === null || b === undefined ? "—" : (b < 1024 ? "0" : human(b) + "/S"); }
    property int selPid: -1
    property bool confirmKill: false
    property string query: ""
    readonly property bool portrait: height > width

    function show(startTab) { if (closing) { closeAnim.stop(); closing = false; } Sfx.play("open"); open = true; tab = startTab === 1 ? 1 : 0; selPid = -1; confirmKill = false; search.clear(); openAnim.restart(); keys.forceActiveFocus(); }
    function hide(instant) { if (!open || closing) return; Sfx.play("close"); if (instant) finishClose(); else closeAnim.restart(); }
    function human(b) {
        const u = ["B", "K", "M", "G", "T"]; let v = Math.max(0, b), i = 0;
        while (v >= 1024 && i < u.length - 1) { v /= 1024; i++; }
        return (v >= 100 || i === 0 ? Math.round(v) : v.toFixed(1)) + u[i];
    }
    readonly property var rows: {
        if (!stats || !Array.isArray(stats.procs)) return [];
        // Hide kernel threads (no memory, not ours): clutter for a desktop task manager.
        const q = query.trim().toLowerCase();
        const r = stats.procs.filter(p => (p.own || p.mem > 0) && (!q || matches(p, q)));
        const key = { mem: r => r.mem, disk: r => r.disk ?? -1, gpu: r => r.gpu ?? -1 }[sortBy];
        r.sort((a, b) => key ? key(b) - key(a) || (b.cpu - a.cpu) : (b.cpu - a.cpu) || (b.mem - a.mem));
        return q ? r : r.slice(0, 150);
    }
    function matches(p, q) {
        const n = p.name.toLowerCase();
        return n.includes(q) || (appAlias[p.name] ?? "").includes(q) || String(p.pid).startsWith(q);
    }
    readonly property var sel: rows.find(r => r.pid === selPid) ?? null

    // Process name -> icon path, cached: installed app's icon (heuristic match on the name),
    // else an icon theme entry with the process name, else "" (letter tile).
    property var iconCache: ({})
    // Helper processes that belong to a known app (icon + search).
    readonly property var appAlias: ({ "Isolated Web Co": "firefox", "Web Content": "firefox", "RDD Process": "firefox",
                                       "Socket Process": "firefox", "Utility Process": "firefox", "WebExtensions": "firefox",
                                       "Privileged Cont": "firefox", "steamwebhelper": "steam", "claude-desktop": "claude" })
    function iconFor(name) {
        const key = name;
        if (key in iconCache) return iconCache[key];
        let path = "";
        if (appAlias[name]) name = appAlias[name];
        const base = name.replace(/[-_ ](bin|helper|wrapper)$/i, "").replace(/webhelper$/i, "");
        const e = DesktopEntries.heuristicLookup(base) ?? DesktopEntries.heuristicLookup(name);
        if (e && e.icon) path = Quickshell.iconPath(e.icon, true);
        if (!path) path = Quickshell.iconPath(base.toLowerCase(), true);
        iconCache[key] = path;
        return path;
    }

    function endTask(force) {
        const r = sel;
        if (!r || !r.own || !Number.isInteger(r.pid) || r.pid <= 1) return;
        Quickshell.execDetached(["kill", force ? "-KILL" : "-TERM", String(r.pid)]);
        confirmKill = false; selPid = -1;
    }

    Process {
        id: sampler
        running: win.open
        command: [Quickshell.shellDir + "/../../bin/saphie-top", "1.5"]
        stdout: SplitParser {
            onRead: line => {
                try {
                    const d = JSON.parse(line);
                    if (d && typeof d.total === "number") {
                        const y = list.contentY;          // new rows array would reset the scroll
                        win.stats = d;
                        list.contentY = y;
                        Qt.callLater(() => { list.contentY = Math.max(0, Math.min(y, list.contentHeight - list.height)); });
                        const h = win.history.slice(-59); h.push(d.total / 100); win.history = h;
                    }
                } catch (e) {}
            }
        }
    }

    Item {
        id: screenRoot
        anchors.fill: parent
        transform: Scale { id: tvScale; origin.x: screenRoot.width / 2; origin.y: screenRoot.height / 2; yScale: 1 }
        Rectangle { anchors.fill: parent; color: "#000000" }
        Canvas { anchors.fill: parent; opacity: 0.05
                 onPaint: { const c = getContext("2d"); c.fillStyle = "#ffffff"; for (let y = 0; y < height; y += 3) c.fillRect(0, y, width, 1); } }
        Item {
            id: keys
            focus: true
            Keys.onPressed: ev => {
                if (ev.key === Qt.Key_Escape) { if (win.confirmKill) win.confirmKill = false; else if (win.query) search.clear(); else win.hide(); }
                else if (ev.key === Qt.Key_F && (ev.modifiers & Qt.ControlModifier)) { win.tab = 0; search.forceActiveFocus(); search.selectAll(); }
                else if (win.tab === 0 && ev.text.length === 1 && ev.text.charCodeAt(0) > 32 && !(ev.modifiers & (Qt.ControlModifier | Qt.AltModifier))) {
                    search.forceActiveFocus(); search.insert(search.length, ev.text);
                }
                else if (ev.key === Qt.Key_Tab) win.tab = 1 - win.tab;
                else if (ev.key === Qt.Key_Delete) { if (win.sel?.own) win.endTask(false); }
                else if (ev.key === Qt.Key_Down || ev.key === Qt.Key_Up) {
                    const i = win.rows.findIndex(r => r.pid === win.selPid);
                    const n = Math.max(0, Math.min(win.rows.length - 1, (i < 0 ? -1 : i) + (ev.key === Qt.Key_Down ? 1 : -1)));
                    if (win.rows[n]) win.selPid = win.rows[n].pid;
                } else return;
                ev.accepted = true;
            }
        }

        // Search box (processes tab), right of the tabs
        Item {
            id: searchBox
            visible: win.tab === 0
            x: 56 + 330; y: 86; width: Math.min(360, parent.width - x - 340); height: 30
            readonly property bool active: search.activeFocus || win.query.length > 0
            Rectangle {
                anchors.fill: parent
                color: Theme.bg; border.color: searchBox.active ? Theme.accentA : Theme.raised; border.width: 2
                transform: Matrix4x4 { matrix: Qt.matrix4x4(1, Theme.skew, 0, -Theme.skew * 15, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1) }
            }
            Text { id: glass; x: 12; anchors.verticalCenter: parent.verticalCenter; text: "⌕"
                   color: searchBox.active ? Theme.accentA : Theme.textDim; font.pixelSize: 16; font.weight: Font.Black }
            TextInput {
                id: search
                x: 34; width: parent.width - 34 - 34; anchors.verticalCenter: parent.verticalCenter
                onTextChanged: { win.query = text; win.selPid = -1; win.confirmKill = false; list.contentY = 0; }
                color: Theme.text; selectionColor: Theme.accentA; selectedTextColor: Theme.onAccent
                font.family: Theme.fontFor(text, Theme.labelFont); font.pixelSize: 13; font.weight: Font.Bold
                clip: true; maximumLength: 64
                Keys.onPressed: ev => {
                    if (ev.key === Qt.Key_Escape) { search.clear(); keys.forceActiveFocus(); }
                    else if (ev.key === Qt.Key_Down || ev.key === Qt.Key_Up || ev.key === Qt.Key_Return || ev.key === Qt.Key_Enter) {
                        // leave the box and select the first match (arrows then move, Del ends it)
                        if (win.rows.length && (win.selPid < 0 || !win.sel)) win.selPid = win.rows[0].pid;
                        keys.forceActiveFocus();
                    } else if (ev.key === Qt.Key_Tab) { win.tab = 1; keys.forceActiveFocus(); }
                    else return;
                    ev.accepted = true;
                }
                Text { visible: !search.text; anchors.verticalCenter: parent.verticalCenter
                       text: "TYPE TO SEARCH"; color: Theme.raised
                       font.family: Theme.labelFont; font.pixelSize: 11; font.weight: Font.ExtraBold; font.letterSpacing: 1.2 }
            }
            MouseArea { anchors.fill: parent; anchors.rightMargin: 30; cursorShape: Qt.IBeamCursor
                        onClicked: search.forceActiveFocus(); }
            Text {   // clear
                visible: win.query.length > 0
                anchors.right: parent.right; anchors.rightMargin: 12; anchors.verticalCenter: parent.verticalCenter
                text: "✕"; color: clr.containsMouse ? Theme.accentA : Theme.textDim; font.pixelSize: 12; font.weight: Font.Black
                MouseArea { id: clr; anchors.fill: parent; anchors.margins: -8; hoverEnabled: true
                            onClicked: { search.clear(); keys.forceActiveFocus(); } }
            }
            Text {   // match count
                visible: win.query.length > 0
                anchors.left: parent.right; anchors.leftMargin: 14; anchors.verticalCenter: parent.verticalCenter
                text: win.rows.length + (win.rows.length === 1 ? " MATCH" : " MATCHES")
                color: win.rows.length ? Theme.accentA : Theme.danger
                font.family: Theme.labelFont; font.pixelSize: 11; font.weight: Font.ExtraBold; font.letterSpacing: 1.2
            }
        }

        // Header
        Text { x: 56; y: 44; text: "CH ▸ SYSTEM"; color: Theme.text; font.family: Theme.titleFont; font.pixelSize: 22 }
        Row {
            x: 56; y: 86; spacing: 10
            Repeater {
                model: ["PROCESSES", "PERFORMANCE"]
                Rectangle {
                    required property string modelData
                    required property int index
                    readonly property bool on: win.tab === index
                    width: tt.implicitWidth + 30; height: 30
                    color: on ? Theme.accentA : "transparent"
                    border.color: on ? Theme.bg : Theme.raised; border.width: 2
                    transform: Matrix4x4 { matrix: Qt.matrix4x4(1, Theme.skew, 0, -Theme.skew * 15, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1) }
                    Text { id: tt; anchors.centerIn: parent; text: modelData; color: parent.on ? Theme.onAccent : Theme.textDim
                           font.family: Theme.labelFont; font.pixelSize: 12; font.weight: Font.ExtraBold; font.letterSpacing: 1.4 }
                    MouseArea { anchors.fill: parent; onClicked: win.tab = index }
                }
            }
        }
        Text {   // big total CPU
            anchors.right: parent.right; anchors.rightMargin: 56; y: 30
            text: (win.stats ? Math.round(win.stats.total) : "--") + "%"
            color: win.stats && win.stats.total > 80 ? Theme.accentA : Theme.text
            font.family: Theme.numeralFont; font.weight: Font.ExtraBold; font.italic: true; font.pixelSize: 64
            Text { anchors.right: parent.left; anchors.rightMargin: 10; anchors.bottom: parent.bottom; anchors.bottomMargin: 12
                   text: "CPU"; color: Theme.textDim; font.family: Theme.labelFont; font.pixelSize: 12; font.weight: Font.ExtraBold }
        }

        // ---------- PROCESSES ----------
        Item {
            visible: win.tab === 0
            x: 56; y: 140; width: parent.width - 112; height: parent.height - 140 - 110
            Row {   // column headers (click to sort)
                id: hdr
                width: parent.width; height: 24
                Text { width: 70; text: "PID"; color: Theme.textDim; font.family: Theme.labelFont; font.pixelSize: 11; font.weight: Font.ExtraBold }
                Text { width: parent.width - 70 - win.colsW; leftPadding: 40; text: "NAME"; color: Theme.textDim; font.family: Theme.labelFont; font.pixelSize: 11; font.weight: Font.ExtraBold }
                Text { width: 110; text: (win.sortBy === "cpu" ? "▼ " : "") + "CPU"; color: win.sortBy === "cpu" ? Theme.accentA : Theme.textDim
                       font.family: Theme.labelFont; font.pixelSize: 11; font.weight: Font.ExtraBold
                       MouseArea { anchors.fill: parent; onClicked: win.sortBy = "cpu" } }
                Text { width: 90; text: (win.sortBy === "mem" ? "▼ " : "") + "RAM"; color: win.sortBy === "mem" ? Theme.accentA : Theme.textDim
                       font.family: Theme.labelFont; font.pixelSize: 11; font.weight: Font.ExtraBold
                       MouseArea { anchors.fill: parent; onClicked: win.sortBy = "mem" } }
                Text { width: 90; text: (win.sortBy === "disk" ? "▼ " : "") + "DISK"; color: win.sortBy === "disk" ? Theme.accentA : Theme.textDim
                       font.family: Theme.labelFont; font.pixelSize: 11; font.weight: Font.ExtraBold
                       MouseArea { anchors.fill: parent; onClicked: win.sortBy = "disk" } }
                Text { width: 70; text: (win.sortBy === "gpu" ? "▼ " : "") + "GPU"; color: win.sortBy === "gpu" ? Theme.accentA : Theme.textDim
                       font.family: Theme.labelFont; font.pixelSize: 11; font.weight: Font.ExtraBold
                       MouseArea { anchors.fill: parent; onClicked: win.sortBy = "gpu" } }
                Text { width: 60; text: "THR"; color: Theme.textDim; font.family: Theme.labelFont; font.pixelSize: 11; font.weight: Font.ExtraBold }
            }
            GreenBar { target: list; x: parent.width + 14; y: 28; height: parent.height - 28 }
            Text { visible: win.query.length > 0 && win.rows.length === 0 && win.stats !== null; y: 60
                   text: "NO PROCESS MATCHES \"" + win.query.toUpperCase() + "\""; textFormat: Text.PlainText; color: Theme.textDim
                   font.family: Theme.numeralFont; font.weight: Font.ExtraBold; font.italic: true; font.pixelSize: 22 }
            ListView {
                id: list
                y: 28; width: parent.width; height: parent.height - 28
                clip: true
                model: win.rows
                spacing: 2
                boundsBehavior: Flickable.StopAtBounds
                delegate: Item {
                    id: row
                    required property var modelData
                    required property int index
                    readonly property bool selected: modelData.pid === win.selPid
                    width: list.width; height: 38
                    Rectangle {
                        anchors.fill: parent
                        color: row.selected ? Theme.accentA : (rm.containsMouse ? "#181818" : "transparent")
                        transform: Matrix4x4 { matrix: Qt.matrix4x4(1, Theme.skew, 0, -Theme.skew * 19, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1) }
                    }
                    Text { x: 0; width: 70; anchors.verticalCenter: parent.verticalCenter; text: row.modelData.pid
                           color: row.selected ? Theme.onAccent : Theme.raised; font.family: Theme.labelFont; font.pixelSize: 12 }
                    Item {   // app icon, or a letter tile
                        x: 70; width: 28; height: 28; anchors.verticalCenter: parent.verticalCenter
                        readonly property string src: win.iconFor(row.modelData.name)
                        Image {
                            id: picon
                            anchors.fill: parent
                            source: parent.src
                            sourceSize.width: 56; sourceSize.height: 56
                            fillMode: Image.PreserveAspectFit
                            asynchronous: true
                            visible: status === Image.Ready
                        }
                        Rectangle {
                            anchors.fill: parent
                            visible: !picon.visible
                            color: row.modelData.own ? Theme.accentA : "#2a2a2a"
                            border.color: Theme.bg; border.width: 2
                            transform: Matrix4x4 { matrix: Qt.matrix4x4(1, Theme.skew, 0, -Theme.skew * 14, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1) }
                            Text { anchors.centerIn: parent; text: row.modelData.name.charAt(0).toUpperCase()
                                   color: row.modelData.own ? Theme.onAccent : Theme.textDim
                                   font.family: Theme.numeralFont; font.weight: Font.ExtraBold; font.italic: true; font.pixelSize: 17 }
                        }
                    }
                    Text {
                        x: 110; width: parent.width - 110 - win.colsW - 10; anchors.verticalCenter: parent.verticalCenter
                        text: row.modelData.name.toUpperCase() + (row.modelData.own ? "" : "  ·  SYSTEM")
                        textFormat: Text.PlainText
                        elide: Text.ElideRight
                        color: row.selected ? Theme.onAccent : (row.modelData.own ? Theme.text : Theme.textDim)
                        font.family: Theme.numeralFont; font.weight: Font.ExtraBold; font.italic: true; font.pixelSize: 20
                    }
                    Item {   // CPU bar + value
                        x: parent.width - win.colsW; width: 110; height: parent.height
                        Rectangle { y: 26; width: 100; height: 4; color: row.selected ? "#3a5a00" : Theme.ring }
                        Rectangle { y: 26; width: Math.min(100, row.modelData.cpu); height: 4
                                    color: row.selected ? Theme.onAccent : (row.modelData.cpu > 25 ? Theme.accentA : Theme.text) }
                        Text { y: 4; text: row.modelData.cpu.toFixed(1) + "%"; color: row.selected ? Theme.onAccent : Theme.text
                               font.family: Theme.labelFont; font.pixelSize: 13; font.weight: Font.Bold }
                    }
                    Text { x: parent.width - win.colsW + 110; anchors.verticalCenter: parent.verticalCenter; text: win.human(row.modelData.mem)
                           color: row.selected ? Theme.onAccent : Theme.text; font.family: Theme.labelFont; font.pixelSize: 13; font.weight: Font.Bold }
                    Text { x: parent.width - win.colsW + 200; anchors.verticalCenter: parent.verticalCenter; text: win.rate(row.modelData.disk)
                           color: row.selected ? Theme.onAccent : ((row.modelData.disk ?? 0) > 1048576 ? Theme.accentA : Theme.textDim)
                           font.family: Theme.labelFont; font.pixelSize: 12; font.weight: Font.Bold }
                    Text { x: parent.width - win.colsW + 290; anchors.verticalCenter: parent.verticalCenter
                           text: row.modelData.gpu === null || row.modelData.gpu === undefined ? "—" : Math.round(row.modelData.gpu) + "%"
                           color: row.selected ? Theme.onAccent : ((row.modelData.gpu ?? 0) > 10 ? Theme.accentA : Theme.textDim)
                           font.family: Theme.labelFont; font.pixelSize: 12; font.weight: Font.Bold }
                    Text { x: parent.width - win.colsW + 360; anchors.verticalCenter: parent.verticalCenter; text: row.modelData.threads ?? ""
                           color: row.selected ? Theme.onAccent : Theme.textDim; font.family: Theme.labelFont; font.pixelSize: 12 }
                    MouseArea { id: rm; anchors.fill: parent; hoverEnabled: true
                                onClicked: { win.selPid = row.modelData.pid; win.confirmKill = false; keys.forceActiveFocus(); } }
                }
            }
        }
        // Action bar for processes
        Row {
            visible: win.tab === 0
            x: 56; anchors.bottom: parent.bottom; anchors.bottomMargin: 50
            spacing: 12
            component Act: Rectangle {
                id: act
                property string label
                property bool danger: false
                property bool enabledAct: true
                signal hit()
                width: at.implicitWidth + 34; height: 38
                opacity: enabledAct ? 1 : 0.35
                color: am.containsMouse && enabledAct ? (danger ? Theme.danger : Theme.accentA) : Theme.bg
                border.color: danger ? Theme.danger : Theme.ring; border.width: 2
                transform: Matrix4x4 { matrix: Qt.matrix4x4(1, Theme.skew, 0, -Theme.skew * 19, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1) }
                scale: am.pressed ? 0.94 : 1
                Behavior on scale { NumberAnimation { duration: 140; easing.type: Easing.OutBack; easing.overshoot: 2.4 } }
                Text { id: at; anchors.centerIn: parent; text: act.label
                       color: am.containsMouse && act.enabledAct ? (act.danger ? "#ffffff" : Theme.onAccent) : Theme.text
                       font.family: Theme.labelFont; font.pixelSize: 12; font.weight: Font.ExtraBold; font.letterSpacing: 1.2 }
                MouseArea { id: am; anchors.fill: parent; hoverEnabled: true; enabled: act.enabledAct; onClicked: act.hit() }
            }
            Act { label: "END TASK"; enabledAct: win.sel?.own ?? false; onHit: win.endTask(false) }
            Act { label: win.confirmKill ? "CONFIRM FORCE KILL" : "FORCE KILL"; danger: true
                  enabledAct: win.sel?.own ?? false
                  onHit: { if (win.confirmKill) win.endTask(true); else win.confirmKill = true; } }
            Text {
                anchors.verticalCenter: parent.verticalCenter
                text: win.sel ? (win.sel.own ? "SELECTED: " + win.sel.name.toUpperCase() + "  (PID " + win.sel.pid + ")"
                                             : "SYSTEM PROCESS — CANNOT END")
                              : "TYPE TO SEARCH    ↑↓ MOVE    DEL END TASK    TAB PERFORMANCE    ESC CLOSE"
                color: win.sel && !win.sel.own ? Theme.danger : Theme.textDim
                font.family: Theme.labelFont; font.pixelSize: 11; font.weight: Font.ExtraBold; font.letterSpacing: 1
            }
        }

        // ---------- PERFORMANCE ----------
        Flickable {
            id: perfFlick
            visible: win.tab === 1
            x: 56; y: 150; width: parent.width - 112; height: parent.height - 260
            clip: true; contentHeight: perfCol.height + 20; boundsBehavior: Flickable.StopAtBounds
            GreenBar { target: perfFlick; parent: perfFlick.parent; x: perfFlick.x + perfFlick.width + 14; y: perfFlick.y
                       height: perfFlick.height; visible: perfFlick.visible && perfFlick.contentHeight > perfFlick.height + 1 }
            Column {
                id: perfCol
                width: parent.width; spacing: 26
                Text { text: "CORES"; color: Theme.textDim; font.family: Theme.labelFont; font.pixelSize: 11; font.weight: Font.ExtraBold }
                Row {   // per-core bars
                    spacing: 6
                    Repeater {
                        model: win.stats ? win.stats.cores : []
                        Item {
                            required property real modelData
                            required property int index
                            width: Math.max(18, Math.min(48, (win.width - 112) / 18)); height: 110
                            Rectangle { anchors.bottom: parent.bottom; anchors.bottomMargin: 18; width: parent.width - 4; height: 92; color: "#141414" }
                            Rectangle {
                                anchors.bottom: parent.bottom; anchors.bottomMargin: 18
                                width: parent.width - 4; height: 92 * modelData / 100
                                color: modelData > 80 ? Theme.accentA : Theme.text
                                Behavior on height { NumberAnimation { duration: 300; easing.type: Easing.OutCubic } }
                            }
                            Text { anchors.bottom: parent.bottom; text: index; color: Theme.raised; font.family: Theme.labelFont; font.pixelSize: 10 }
                        }
                    }
                }
                Text { text: "CPU · LAST 90 S"; color: Theme.textDim; font.family: Theme.labelFont; font.pixelSize: 11; font.weight: Font.ExtraBold }
                Row {   // history
                    spacing: 2; height: 70
                    Repeater {
                        model: 60
                        Rectangle {
                            required property int index
                            readonly property real v: { const h = win.history; const i = h.length - 60 + index; return i >= 0 ? h[i] : 0; }
                            anchors.bottom: parent.bottom
                            width: Math.max(4, (win.width - 112) / 60 - 2); height: Math.max(2, 70 * v)
                            color: v > 0.8 ? Theme.accentA : (v > 0.4 ? Theme.text : Theme.textDim)
                        }
                    }
                }
                Flow {   // RAM + GPU + network cards (wrap on narrow/portrait screens)
                    width: parent.width
                    spacing: 24
                    component Stat: Item {
                        id: st
                        property string title
                        property string big
                        property string small
                        property real frac: 0
                        width: win.portrait ? (win.width - 112 - 24) / 2 : 320; height: 120
                        Rectangle { x: 6; y: 6; width: parent.width; height: parent.height; color: Theme.bg }
                        Rectangle { anchors.fill: parent; color: Theme.surface; border.color: Theme.ring; border.width: 3
                                    topLeftRadius: 16; topRightRadius: 16; bottomLeftRadius: 16 }
                        Text { x: 18; y: 14; text: st.title; color: Theme.accentA; font.family: Theme.labelFont; font.pixelSize: 11; font.weight: Font.ExtraBold; font.letterSpacing: 1.4 }
                        Text { x: 18; y: 32; text: st.big; color: Theme.text; font.family: Theme.numeralFont; font.weight: Font.ExtraBold; font.italic: true; font.pixelSize: 38 }
                        Text { x: 18; y: 78; text: st.small; color: Theme.textDim; font.family: Theme.labelFont; font.pixelSize: 11 }
                        Rectangle { id: track; x: 18; y: 100; width: st.width - 36; height: 5; color: Theme.ring
                            Rectangle { width: track.width * Math.max(0, Math.min(1, st.frac)); height: 5; color: st.frac > 0.85 ? Theme.accentA : Theme.text } }
                    }
                    Stat {
                        title: "CPU · RYZEN 7 5800H"
                        readonly property var c: win.stats ? win.stats.cpu : null
                        frac: win.stats ? win.stats.total / 100 : 0
                        big: c ? Math.round(win.stats.total) + "%  ·  " + (c.temp !== null ? Math.round(c.temp) + "°C" : "") : "--"
                        small: c ? (c.ghzAvg ?? "-") + " GHZ AVG  ·  " + (c.ghzMax ?? "-") + " PEAK  ·  LOAD " + (c.load[0] ?? "-")
                                   + "  ·  " + (c.profile || "").toUpperCase() : ""
                    }
                    Stat {
                        title: "MEMORY"
                        readonly property var m: win.stats ? win.stats.mem : null
                        frac: m ? 1 - m.available / m.total : 0
                        big: m ? win.human(m.total - m.available) + " / " + win.human(m.total) : "--"
                        small: m ? "CACHE " + win.human(m.cached) + "  ·  SWAP " + win.human(m.swapTotal - m.swapFree) + " / " + win.human(m.swapTotal) : ""
                    }
                    Stat {
                        title: win.stats && win.stats.gpu && win.stats.gpu.name ? "NVIDIA · " + win.stats.gpu.name.replace(/NVIDIA GeForce /, "").toUpperCase() : "NVIDIA GPU"
                        readonly property var g: win.stats ? win.stats.gpu : null
                        frac: g && !g.sleep ? (g.util ?? 0) / 100 : 0
                        big: g ? (g.sleep ? "SLEEPING" : Math.round(g.util ?? 0) + "%  ·  " + Math.round(g.temp ?? 0) + "°C") : "--"
                        small: g ? (g.sleep ? "SAVING POWER (NOT WOKEN BY THIS VIEW)"
                                            : "VRAM " + win.human(g.memUsed) + " / " + win.human(g.memTotal) + "  ·  " + Math.round(g.power ?? 0) + " W  ·  " + Math.round(g.clock ?? 0) + " MHZ")
                                 : "NO NVIDIA GPU"
                    }
                    Stat {
                        title: "AMD · RADEON (DISPLAY)"
                        readonly property var a: win.stats ? win.stats.igpu : null
                        visible: a !== null
                        frac: a ? (a.busy ?? 0) / 100 : 0
                        big: a ? Math.round(a.busy ?? 0) + "%  ·  " + Math.round(a.temp ?? 0) + "°C" : "--"
                        small: a ? "VRAM " + win.human(a.vramUsed ?? 0) + " / " + win.human(a.vramTotal ?? 0) + "  ·  " + Math.round(a.power ?? 0) + " W" : ""
                    }
                    Repeater {
                        model: win.stats ? win.stats.disks : []
                        Stat {
                            required property var modelData
                            readonly property var mt: modelData.mounts.length ? modelData.mounts[0] : null
                            title: "DISK · " + (modelData.model || modelData.name).toUpperCase()
                            frac: mt ? mt.used / mt.total : 0
                            big: "R " + win.human(modelData.read) + "  W " + win.human(modelData.write)
                            small: (modelData.temp !== null ? Math.round(modelData.temp) + "°C  ·  " : "")
                                   + (mt ? (mt.mount === "/" ? "SYSTEM" : mt.mount.split("/").pop().toUpperCase()) + " " + win.human(mt.used) + " / " + win.human(mt.total) : "NOT MOUNTED")
                        }
                    }
                    Stat {
                        title: "NETWORK"
                        frac: 0
                        big: "↓ " + SysStats.human(SysStats.rxRate)
                        small: "↑ " + SysStats.human(SysStats.txRate) + " / S"
                    }
                }
            }
        }
        Text {
            visible: win.tab === 1
            x: 56; anchors.bottom: parent.bottom; anchors.bottomMargin: 50
            text: (win.stats ? win.stats.count : 0) + " PROCESSES  ·  " + (win.stats ? win.stats.threads : 0) + " THREADS  ·  UP "
                  + (win.stats && win.stats.cpu.uptime ? Math.floor(win.stats.cpu.uptime / 3600) + "H " + Math.floor(win.stats.cpu.uptime % 3600 / 60) + "M" : "-")
                  + "    TAB PROCESSES    ESC CLOSE"
            color: Theme.textDim; font.family: Theme.labelFont; font.pixelSize: 11; font.weight: Font.ExtraBold; font.letterSpacing: 1
        }

        Rectangle { id: wiper; visible: (openAnim.running || closeAnim.running) && Theme.openStyle === "wipe"
                    width: parent.width * 1.6; height: parent.height * 2; color: Theme.accentA; rotation: 20; x: -width; y: -parent.height * 0.5 }
    }
    Rectangle { id: tvLine; y: win.height / 2 - 2; width: win.width; height: 4; color: "#ffffff"; opacity: 0 }
    SequentialAnimation {
        id: openAnim
        ScriptAction { script: {
            const tv = Theme.openStyle === "tv";
            wiper.x = -wiper.width * 0.2; tvScale.yScale = tv ? 0.004 : 1; tvLine.opacity = tv ? 1 : 0;
        } }
        PauseAnimation { duration: 70 }
        ParallelAnimation {
            NumberAnimation { target: wiper; property: "x"; to: win.width + win.height; duration: 380; easing.type: Easing.OutCubic }
            NumberAnimation { target: tvScale; property: "yScale"; to: 1; duration: 340; easing.type: Easing.OutBack; easing.overshoot: 1.3 }
            NumberAnimation { target: tvLine; property: "opacity"; to: 0; duration: 220 }
        }
    }

    // Close animation (reverse of the open): wipe style = green panel sweeps back over the
    // screen; tv style = screen collapses into a white line (TV switch-off). Then the window goes.
    property bool closing: false
    function finishClose() {
        closeAnim.stop(); closing = false; open = false;
        wiper.x = -wiper.width; tvScale.yScale = 1; tvLine.opacity = 0;
    }
    SequentialAnimation {
        id: closeAnim
        ScriptAction { script: { win.closing = true; wiper.x = win.width + win.height; } }
        ParallelAnimation {
            NumberAnimation { target: wiper; property: "x"; to: -wiper.width * 0.2; duration: 240; easing.type: Easing.InCubic }
            NumberAnimation { target: tvScale; property: "yScale"; to: Theme.openStyle === "tv" ? 0.004 : 1; duration: 200; easing.type: Easing.InBack }
            NumberAnimation { target: tvLine; property: "opacity"; to: Theme.openStyle === "tv" ? 1 : 0; duration: 160 }
        }
        PauseAnimation { duration: 40 }
        ScriptAction { script: win.finishClose() }
    }
}
