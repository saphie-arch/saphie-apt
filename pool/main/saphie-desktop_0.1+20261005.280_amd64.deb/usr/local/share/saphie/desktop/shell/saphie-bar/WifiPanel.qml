import Quickshell
import Quickshell.Io
import Quickshell.Networking
import QtQuick

// Wi-Fi picker under the network sticker: on/off switch, networks by signal, connect
// (saved -> directly, new secured -> inline password), disconnect. Scans only while open;
// REFRESH (and opening the panel) asks NetworkManager for a fresh scan right away.
PopupWindow {
    id: panel
    required property Item anchorItem
    required property var barWindow
    anchor.window: barWindow
    anchor.item: anchorItem
    anchor.edges: Edges.Bottom
    anchor.gravity: Edges.Bottom
    anchor.margins.top: 10
    implicitWidth: 380
    implicitHeight: 440
    color: "transparent"
    grabFocus: true

    readonly property var device: Networking.devices.values.find(d => d.type === DeviceType.Wifi) ?? null
    readonly property var networks: {
        if (!device) return [];
        const list = device.networks.values.filter(n => n.name);
        list.sort((a, b) => (b.connected - a.connected) || (b.signalStrength - a.signalStrength));
        return list.slice(0, 40);
    }
    property var pwFor: null           // network waiting for a password
    function toggle() {
        if (closing) return;
        if (visible) { Sfx.play("close"); closing = true; closeAnim.restart(); }
        else { Sfx.play("open"); drop.y = 0; body.opacity = 1; visible = true; }
    }
    onVisibleChanged: {
        if (device) device.scannerEnabled = visible;
        pwFor = null;
        if (visible) { openAnim.restart(); rescan(); }
    }
    // Fresh scan: NetworkManager refuses a rescan right after the last one (it's still fresh), so
    // errors are ignored; the list updates by itself when the results arrive (~2-4 s).
    property bool scanning: false
    function rescan() {
        if (!Networking.wifiEnabled || !device || scanning) return;
        scanning = true;
        scanProc.running = true;
        scanHold.restart();
    }
    Process { id: scanProc; command: ["nmcli", "device", "wifi", "rescan"] }
    Timer { id: scanHold; interval: 3500; onTriggered: panel.scanning = false }
    function secured(n) { return n.security !== WifiSecurityType.Open && n.security !== WifiSecurityType.Owe; }
    function choose(n) {
        if (n.connected) return;
        if (n.known || !secured(n)) { n.connect(); pwFor = null; }
        else { pwFor = n; pw.text = ""; pw.forceActiveFocus(); refocus.restart(); }
    }
    // The bar only takes the keyboard once pwFor is set (Bar.qml): focus the box again after that.
    Timer { id: refocus; interval: 120; onTriggered: if (panel.pwFor) pw.forceActiveFocus() }

    Item {
        id: body
        anchors.fill: parent
        anchors.topMargin: 16; anchors.rightMargin: 8; anchors.bottomMargin: 8
        transform: Translate { id: drop; y: 0 }

        Rectangle { x: 6; y: 6; width: parent.width; height: parent.height; color: Theme.bg }
        Rectangle {
            anchors.fill: parent
            color: Theme.surface; border.color: Theme.bg; border.width: 2
            topLeftRadius: Theme.corner; topRightRadius: Theme.corner; bottomLeftRadius: Theme.corner; bottomRightRadius: 0
            Rectangle { anchors.fill: parent; anchors.margins: 2; color: "transparent"; border.color: Theme.ring; border.width: 3
                        topLeftRadius: Theme.corner - 2; topRightRadius: Theme.corner - 2; bottomLeftRadius: Theme.corner - 2 }
        }
        Rectangle {   // tab
            x: 18; y: -12; width: 96; height: 26
            color: Theme.accentA; border.color: Theme.bg; border.width: 2
            transform: Matrix4x4 { matrix: Qt.matrix4x4(1, Theme.skew, 0, -Theme.skew * 13, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1) }
            Text { anchors.centerIn: parent; text: "WI-FI"; color: Theme.onAccent
                   font.family: Theme.labelFont; font.pixelSize: 11; font.weight: Font.ExtraBold; font.letterSpacing: 1.6 }
        }

        // On/off switch
        Row {
            x: 20; y: 26; spacing: 12
            Text { anchors.verticalCenter: parent.verticalCenter; text: "NETWORKS"
                   color: Theme.text; font.family: Theme.titleFont; font.pixelSize: 18 }
        }
        Rectangle {   // refresh
            id: refreshBtn
            anchors.right: sw.left; anchors.rightMargin: 14; y: 28
            width: 104; height: 26
            readonly property bool usable: Networking.wifiEnabled && panel.device !== null
            color: refreshMouse.containsMouse && usable && !panel.scanning ? Theme.raised : Theme.bg
            border.color: panel.scanning ? Theme.accentA : Theme.ring; border.width: 2
            opacity: usable ? 1 : 0.4
            transform: Matrix4x4 { matrix: Qt.matrix4x4(1, Theme.skew, 0, -Theme.skew * 13, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1) }
            Row {
                anchors.centerIn: parent; spacing: 6
                Text {
                    id: spin
                    text: "↻"; color: panel.scanning ? Theme.accentA : Theme.text
                    font.pixelSize: 14; font.weight: Font.Bold
                    anchors.verticalCenter: parent.verticalCenter
                    RotationAnimation on rotation { running: panel.scanning; loops: Animation.Infinite; from: 0; to: 360; duration: 700
                                                    onRunningChanged: if (!running) spin.rotation = 0 }
                }
                Text { text: panel.scanning ? "SCANNING" : "REFRESH"; color: panel.scanning ? Theme.accentA : Theme.text
                       anchors.verticalCenter: parent.verticalCenter
                       font.family: Theme.labelFont; font.pixelSize: 11; font.weight: Font.ExtraBold; font.letterSpacing: 1 }
            }
            MouseArea { id: refreshMouse; anchors.fill: parent; hoverEnabled: true
                        onClicked: { Sfx.play("tick"); panel.rescan(); } }
        }
        Rectangle {
            id: sw
            anchors.right: parent.right; anchors.rightMargin: 20; y: 28
            width: 58; height: 26
            readonly property bool on: Networking.wifiEnabled
            color: on ? Theme.accentA : Theme.bg
            border.color: on ? Theme.bg : Theme.ring; border.width: 2
            transform: Matrix4x4 { matrix: Qt.matrix4x4(1, Theme.skew, 0, -Theme.skew * 13, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1) }
            Text { anchors.centerIn: parent; text: sw.on ? "ON" : "OFF"; color: sw.on ? Theme.onAccent : Theme.textDim
                   font.family: Theme.labelFont; font.pixelSize: 11; font.weight: Font.ExtraBold }
            MouseArea { anchors.fill: parent; onClicked: Networking.wifiEnabled = !Networking.wifiEnabled }
        }

        // Network list: clipped + scrollable (wheel / drag), green scroll bar on the right
        Flickable {
            id: flick
            x: 16; y: 70
            width: parent.width - 32
            height: parent.height - y - 14 - (panel.pwFor !== null ? 86 : 0)
            clip: true
            contentHeight: listCol.height
            boundsBehavior: Flickable.StopAtBounds
            flickableDirection: Flickable.VerticalFlick
            Behavior on contentY { enabled: !flick.moving; NumberAnimation { duration: 160; easing.type: Easing.OutCubic } }
            WheelHandler {   // one notch = one row, smooth
                onWheel: ev => {
                    const step = ev.angleDelta.y !== 0 ? -ev.angleDelta.y / 120 * 42 : -ev.pixelDelta.y;
                    flick.contentY = Math.max(0, Math.min(flick.contentHeight - flick.height, flick.contentY + step));
                }
            }
        Column {
            id: listCol
            width: flick.width - 10
            spacing: 4
            Repeater {
                model: panel.networks
                Item {
                    id: rowItem
                    required property var modelData
                    required property int index
                    readonly property bool hot: rowMouse.containsMouse || modelData.connected
                    width: parent.width; height: 38
                    opacity: 0
                    transform: Translate { id: rT; x: -20 }
                    Connections { target: openAnim; function onStarted() { rIn.restart(); } }
                    Component.onCompleted: rIn.restart()
                    SequentialAnimation { id: rIn
                        ScriptAction { script: { rT.x = -20; rowItem.opacity = 0; } }
                        PauseAnimation { duration: 60 + Math.min(rowItem.index, 10) * 25 }
                        ParallelAnimation {
                            NumberAnimation { target: rT; property: "x"; to: 0; duration: 220; easing.type: Easing.OutBack; easing.overshoot: 1.6 }
                            NumberAnimation { target: rowItem; property: "opacity"; to: 1; duration: 90 } } }
                    Rectangle {
                        anchors.fill: parent; anchors.leftMargin: 8
                        color: modelData.connected ? Theme.accentA : (rowMouse.containsMouse ? "#1f1f1f" : "transparent")
                        transform: Matrix4x4 { matrix: Qt.matrix4x4(1, Theme.skew, 0, -Theme.skew * 19, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1) }
                    }
                    Row {   // signal bars
                        x: 12; anchors.verticalCenter: parent.verticalCenter
                        spacing: 2; height: 16
                        Repeater {
                            model: 4
                            Rectangle {
                                required property int index
                                anchors.bottom: parent.bottom
                                width: 4; height: 4 + index * 4
                                color: rowItem.modelData.signalStrength > index / 4 + 0.05
                                       ? (rowItem.modelData.connected ? Theme.onAccent : Theme.text)
                                       : (rowItem.modelData.connected ? "#3a5a00" : Theme.raised)
                            }
                        }
                    }
                    Text {
                        x: 44; anchors.verticalCenter: parent.verticalCenter
                        width: parent.width - 44 - 120; elide: Text.ElideRight
                        text: rowItem.modelData.name
                        color: rowItem.modelData.connected ? Theme.onAccent : Theme.text
                        font.family: Theme.labelFont; font.pixelSize: 13; font.weight: Font.Bold
                    }
                    Text {
                        anchors.right: parent.right; anchors.rightMargin: 12; anchors.verticalCenter: parent.verticalCenter
                        text: rowItem.modelData.connected ? (discMouse.containsMouse ? "DISCONNECT" : "CONNECTED")
                            : rowItem.modelData.stateChanging ? "…"
                            : (panel.secured(rowItem.modelData) ? "🔒 " : "") + (rowItem.modelData.known ? "SAVED" : "")
                        color: rowItem.modelData.connected ? Theme.onAccent : Theme.textDim
                        font.family: Theme.labelFont; font.pixelSize: 10; font.weight: Font.ExtraBold; font.letterSpacing: 1
                        MouseArea { id: discMouse; anchors.fill: parent; anchors.margins: -6; hoverEnabled: true
                                    enabled: rowItem.modelData.connected
                                    onClicked: rowItem.modelData.disconnect() }
                    }
                    MouseArea { id: rowMouse; anchors.fill: parent; hoverEnabled: true; z: -1
                                onClicked: panel.choose(rowItem.modelData) }
                }
            }
            Text {
                visible: panel.networks.length === 0
                text: !Networking.wifiEnabled ? "WI-FI IS OFF" : (panel.device ? "SCANNING…" : "NO WI-FI DEVICE")
                color: Theme.textDim; font.family: Theme.labelFont; font.pixelSize: 12
            }
        }
        }
        Rectangle {   // scroll bar: thin track + bright green thumb (only when the list overflows)
            visible: flick.contentHeight > flick.height + 1
            anchors.right: flick.right; y: flick.y; width: 4; height: flick.height
            color: Theme.raised
            Rectangle {
                width: parent.width; color: Theme.accentA
                height: Math.max(24, parent.height * flick.height / Math.max(1, flick.contentHeight))
                y: (parent.height - height) * (flick.contentY / Math.max(1, flick.contentHeight - flick.height))
            }
        }

        // Password field for a new secured network
        Item {
            visible: panel.pwFor !== null
            x: 16; anchors.bottom: parent.bottom; anchors.bottomMargin: 18
            width: parent.width - 32; height: 64
            Text { text: "PASSWORD FOR " + (panel.pwFor?.name ?? "").toUpperCase(); color: Theme.accentA
                   font.family: Theme.labelFont; font.pixelSize: 10; font.weight: Font.ExtraBold }
            Rectangle {
                y: 18; width: parent.width - 96; height: 38
                color: "#101010"; border.color: pw.activeFocus ? Theme.accentA : Theme.ring; border.width: 2
                transform: Matrix4x4 { matrix: Qt.matrix4x4(1, Theme.skew, 0, -Theme.skew * 19, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1) }
                TextInput {
                    id: pw
                    x: 12; width: parent.width - 24; anchors.verticalCenter: parent.verticalCenter
                    echoMode: TextInput.Password
                    maximumLength: 63
                    color: Theme.text; font.family: Theme.labelFont; font.pixelSize: 15
                    Keys.onReturnPressed: go.hit()
                    Keys.onEscapePressed: panel.pwFor = null
                }
            }
            Rectangle {
                id: go
                function hit() { if (panel.pwFor && pw.text.length >= 8) { panel.pwFor.connectWithPsk(pw.text); pw.text = ""; panel.pwFor = null; } }
                anchors.right: parent.right; y: 18; width: 86; height: 38
                color: pw.text.length >= 8 ? Theme.accentA : Theme.bg
                border.color: Theme.ring; border.width: 2
                Text { anchors.centerIn: parent; text: "CONNECT"; color: pw.text.length >= 8 ? Theme.onAccent : Theme.raised
                       font.family: Theme.labelFont; font.pixelSize: 11; font.weight: Font.ExtraBold }
                MouseArea { anchors.fill: parent; onClicked: go.hit() }
            }
        }
    }

    SequentialAnimation {
        id: openAnim
        ParallelAnimation {
            NumberAnimation { target: drop; property: "y"; from: -18; to: 0; duration: 260; easing.type: Easing.OutBack; easing.overshoot: 1.6 }
            NumberAnimation { target: body; property: "opacity"; from: 0; to: 1; duration: 120 }
        }
    }

    // Close animation: lift + fade (reverse of the drop-in), then hide.
    property bool closing: false
    SequentialAnimation {
        id: closeAnim
        ParallelAnimation {
            NumberAnimation { target: drop; property: "y"; to: -18; duration: 150; easing.type: Easing.InBack; easing.overshoot: 1.4 }
            NumberAnimation { target: body; property: "opacity"; to: 0; duration: 150; easing.type: Easing.InQuad }
        }
        ScriptAction { script: { panel.closing = false; panel.visible = false; drop.y = 0; body.opacity = 1; } }
    }
}
