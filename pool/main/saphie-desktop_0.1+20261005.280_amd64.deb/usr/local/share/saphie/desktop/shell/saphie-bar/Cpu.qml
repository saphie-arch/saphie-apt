import QtQuick

// CPU usage with a small history graph (last 30 samples, 2 s each = 1 minute).
Row {
    spacing: 8
    Label { anchors.verticalCenter: parent.verticalCenter; text: "CPU" }
    Item {
        anchors.verticalCenter: parent.verticalCenter
        width: 30 * 3 - 1; height: 18
        Rectangle { anchors.bottom: parent.bottom; width: parent.width; height: 1; color: Theme.ring }   // baseline
    Row {
        anchors.bottom: parent.bottom
        spacing: 1; height: 18
        Repeater {
            model: 30
            Rectangle {
                required property int index
                readonly property real v: {
                    const h = SysStats.cpuHistory;
                    const i = h.length - 30 + index;
                    return i >= 0 ? h[i] : 0;
                }
                anchors.bottom: parent.bottom
                width: 2; height: Math.max(2, v * 18)
                color: v > 0.8 ? Theme.accentA : (v > 0.4 ? Theme.text : Theme.textDim)
            }
        }
    }
    }
    Label {
        anchors.verticalCenter: parent.verticalCenter
        width: 34
        dim: false
        font.weight: Font.ExtraBold
        text: Math.round(SysStats.cpu * 100) + "%"
        color: SysStats.cpu > 0.8 ? Theme.accentA : Theme.text
    }
    Label {   // CPU temperature: green when hot (85+), red when very hot (95+)
        anchors.verticalCenter: parent.verticalCenter
        visible: SysStats.cpuTemp >= 0
        width: 30
        dim: false
        font.weight: Font.ExtraBold
        text: Math.round(SysStats.cpuTemp) + "°"
        color: SysStats.cpuTemp >= 95 ? Theme.danger : (SysStats.cpuTemp >= 85 ? Theme.accentA : Theme.textDim)
    }
}
