import Quickshell
import QtQuick

// Tray drop-down in the Saphie style (like the Wi-Fi panel). Two views:
//  - apps: every background app (icon + name); left click = its main action, right click / "⋯" =
//    its options trayMenu (opens in place, BACK returns to the list)
//  - menu: one app's own trayMenu (DBusMenu): separators, disabled items, check boxes / radio
//    buttons, submenus (open in place with a BACK row).
// Click outside or Esc closes it.
PopupWindow {
    id: trayMenu
    required property var barWindow
    property var apps: []            // all SystemTrayItems (apps view)
    property bool appsView: false    // opened from the "▾ N" button: list first
    property var item: null          // the SystemTrayItem whose trayMenu is shown
    property Item anchorItem: null
    property var stack: []           // submenu handles, last = shown
    readonly property var handle: stack.length ? stack[stack.length - 1] : (item ? item.menu : null)

    anchor.window: barWindow
    anchor.item: anchorItem
    anchor.edges: Edges.Bottom
    anchor.gravity: Edges.Bottom
    anchor.margins.top: 14
    implicitWidth: 280
    implicitHeight: Math.min(560, body.implicitHeight + 24)
    color: "transparent"
    grabFocus: true
    visible: false

    function show() { visible = true; drop.y = -14; body.opacity = 0; openAnim.restart(); }
    function openFor(it, slotItem) { appsView = false; item = it; anchorItem = slotItem; stack = []; show(); }
    function openApps(slotItem) { appsView = true; item = null; anchorItem = slotItem; stack = []; show(); }
    function close() { if (visible) Sfx.play("close"); visible = false; item = null; stack = []; }
    function enter(entry) { stack = stack.concat([entry]); }
    function back() {
        if (stack.length) stack = stack.slice(0, -1);
        else if (appsView) item = null;          // from an app's trayMenu back to the app list
    }
    readonly property bool listing: appsView && item === null
    readonly property bool canBack: stack.length > 0 || (appsView && item !== null)

    QsMenuOpener { id: opener; menu: trayMenu.handle }

    Item {
        id: frame
        anchors.fill: parent
        anchors.rightMargin: 6; anchors.bottomMargin: 6
        focus: true
        Keys.onEscapePressed: trayMenu.close()
        transform: Translate { id: drop; y: 0 }

        Rectangle { x: 6; y: 6; width: parent.width; height: parent.height; color: Theme.bg }   // hard shadow
        Rectangle {
            anchors.fill: parent
            color: Theme.surface; border.color: Theme.bg; border.width: 2
            topLeftRadius: Theme.corner; topRightRadius: Theme.corner; bottomLeftRadius: Theme.corner; bottomRightRadius: 0
            Rectangle { anchors.fill: parent; anchors.margins: 2; color: "transparent"; border.color: Theme.ring; border.width: 3
                        topLeftRadius: Theme.corner - 2; topRightRadius: Theme.corner - 2; bottomLeftRadius: Theme.corner - 2 }
        }

        Flickable {
            anchors.fill: parent; anchors.margins: 10
            contentHeight: body.implicitHeight
            clip: true
            boundsBehavior: Flickable.StopAtBounds

            Column {
                id: body
                width: parent.width
                spacing: 2

                // header: app name (or BACK inside a submenu)
                Item {
                    width: parent.width; height: 30
                    Text {
                        anchors.verticalCenter: parent.verticalCenter; x: 6
                        width: parent.width - 12; elide: Text.ElideRight
                        text: trayMenu.listing ? "BACKGROUND APPS · " + trayMenu.apps.length
                              : (trayMenu.canBack ? "‹ " : "") + (trayMenu.stack.length ? "BACK"
                              : (trayMenu.item?.tooltipTitle || trayMenu.item?.title || trayMenu.item?.id || "APP").toUpperCase())
                        color: trayMenu.canBack && backMouse.containsMouse ? Theme.accentA : Theme.text
                        font.family: Theme.labelFont; font.pixelSize: 12; font.weight: Font.ExtraBold; font.letterSpacing: 1.4
                    }
                    MouseArea { id: backMouse; anchors.fill: parent; hoverEnabled: true; enabled: trayMenu.canBack
                                onClicked: { Sfx.play("tick"); trayMenu.back(); } }
                }
                Rectangle { width: parent.width; height: 2; color: Theme.ring }

                Repeater {   // apps view
                    model: trayMenu.listing ? trayMenu.apps : []
                    Item {
                        id: app
                        required property var modelData
                        width: body.width; height: 34
                        Rectangle {
                            anchors.fill: parent; anchors.leftMargin: 6
                            color: appMouse.containsMouse ? Theme.accentA : "transparent"
                            transform: Matrix4x4 { matrix: Qt.matrix4x4(1, Theme.skew, 0, -Theme.skew * 17, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1) }
                        }
                        Image {
                            x: 12; anchors.verticalCenter: parent.verticalCenter
                            width: 20; height: 20; sourceSize.width: 40; sourceSize.height: 40
                            source: app.modelData.icon
                        }
                        Text {
                            x: 42; anchors.verticalCenter: parent.verticalCenter
                            width: parent.width - 42 - 40; elide: Text.ElideRight
                            text: app.modelData.tooltipTitle || app.modelData.title || app.modelData.id
                            color: appMouse.containsMouse ? Theme.onAccent : Theme.text
                            font.family: Theme.labelFont; font.pixelSize: 13; font.weight: Font.Bold
                        }
                        MouseArea {
                            id: appMouse
                            anchors.fill: parent
                            hoverEnabled: true
                            acceptedButtons: Qt.LeftButton | Qt.RightButton | Qt.MiddleButton
                            onClicked: ev => {
                                const it = app.modelData;
                                Sfx.play("tick");
                                if (ev.button === Qt.MiddleButton) { it.secondaryActivate(); trayMenu.close(); }
                                else if ((ev.button === Qt.RightButton || it.onlyMenu) && it.hasMenu) { trayMenu.item = it; trayMenu.stack = []; }
                                else { it.activate(); trayMenu.close(); }
                            }
                        }
                        Text {   // "⋯" = options trayMenu
                            visible: app.modelData.hasMenu
                            anchors.right: parent.right; anchors.rightMargin: 8; anchors.verticalCenter: parent.verticalCenter
                            text: "⋯"; font.pixelSize: 18; font.weight: Font.Bold
                            color: dotsMouse.containsMouse ? Theme.bg : (appMouse.containsMouse ? Theme.onAccent : Theme.textDim)
                            MouseArea { id: dotsMouse; anchors.fill: parent; anchors.margins: -8; hoverEnabled: true
                                        onClicked: { Sfx.play("tick"); trayMenu.item = app.modelData; trayMenu.stack = []; } }
                        }
                    }
                }

                Repeater {   // trayMenu view
                    model: !trayMenu.listing && opener.children ? opener.children.values : []
                    Item {
                        id: row
                        required property var modelData
                        width: body.width
                        height: modelData.isSeparator ? 10 : 30
                        readonly property bool usable: !modelData.isSeparator && modelData.enabled

                        Rectangle {   // separator
                            visible: row.modelData.isSeparator
                            anchors.verticalCenter: parent.verticalCenter
                            width: parent.width; height: 1; color: Theme.raised
                        }
                        Rectangle {   // hover bar (skewed like the Wi-Fi rows)
                            visible: !row.modelData.isSeparator
                            anchors.fill: parent; anchors.leftMargin: 6
                            color: rowMouse.containsMouse && row.usable ? Theme.accentA : "transparent"
                            transform: Matrix4x4 { matrix: Qt.matrix4x4(1, Theme.skew, 0, -Theme.skew * 15, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1) }
                        }
                        Row {
                            visible: !row.modelData.isSeparator
                            x: 10; spacing: 8
                            anchors.verticalCenter: parent.verticalCenter
                            Rectangle {   // check box / radio button
                                visible: row.modelData.buttonType !== QsMenuButtonType.None
                                anchors.verticalCenter: parent.verticalCenter
                                width: 12; height: 12
                                radius: row.modelData.buttonType === QsMenuButtonType.RadioButton ? 6 : 2
                                color: row.modelData.checkState === Qt.Checked
                                       ? (rowMouse.containsMouse && row.usable ? Theme.onAccent : Theme.accentA) : "transparent"
                                border.color: rowMouse.containsMouse && row.usable ? Theme.onAccent : Theme.text; border.width: 2
                            }
                            Image {
                                visible: row.modelData.icon !== ""
                                anchors.verticalCenter: parent.verticalCenter
                                width: 16; height: 16; sourceSize.width: 32; sourceSize.height: 32
                                source: row.modelData.icon
                            }
                            Text {
                                anchors.verticalCenter: parent.verticalCenter
                                width: body.width - 70; elide: Text.ElideRight
                                text: row.modelData.text.replace(/_(?=\w)/, "")   // drop mnemonic underscores
                                color: !row.usable ? Theme.textDim
                                       : (rowMouse.containsMouse ? Theme.onAccent : Theme.text)
                                opacity: row.usable ? 1 : 0.5
                                font.family: Theme.labelFont; font.pixelSize: 13; font.weight: Font.Bold
                            }
                        }
                        Text {   // submenu arrow
                            visible: row.modelData.hasChildren
                            anchors.right: parent.right; anchors.rightMargin: 10; anchors.verticalCenter: parent.verticalCenter
                            text: "›"; font.pixelSize: 16; font.weight: Font.Bold
                            color: rowMouse.containsMouse && row.usable ? Theme.onAccent : Theme.text
                        }
                        MouseArea {
                            id: rowMouse
                            anchors.fill: parent
                            hoverEnabled: true
                            enabled: row.usable
                            onClicked: {
                                Sfx.play("tick");
                                if (row.modelData.hasChildren) { trayMenu.enter(row.modelData); return; }
                                row.modelData.triggered();
                                trayMenu.close();
                            }
                        }
                    }
                }
                Text {
                    visible: trayMenu.listing ? trayMenu.apps.length === 0 : (!opener.children || opener.children.values.length === 0)
                    x: 6; text: trayMenu.listing ? "NO BACKGROUND APPS" : "NO OPTIONS"
                    color: Theme.textDim; font.family: Theme.labelFont; font.pixelSize: 11
                }
            }
        }
    }

    ParallelAnimation {
        id: openAnim
        NumberAnimation { target: drop; property: "y"; from: -14; to: 0; duration: 240; easing.type: Easing.OutBack; easing.overshoot: 1.6 }
        NumberAnimation { target: body; property: "opacity"; from: 0; to: 1; duration: 120 }
    }
    // Clicking elsewhere (focus leaves the popup) closes it.
    onVisibleChanged: if (visible) frame.forceActiveFocus()
}
