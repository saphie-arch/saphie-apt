import Quickshell
import Quickshell.Wayland
import Quickshell.Widgets
import QtQuick

// Saphie Chat (Super+N, or click a message card): a phone-style messenger in the middle of the
// screen, built from the messages Saphie received this session (Notifs.convos, memory only).
// Left: chats (avatar, preview, unread, missed calls). Right: the conversation as bubbles,
// quick-reply chips and a reply box for apps with inline reply; other apps get OPEN IN APP.
PanelWindow {
    id: win
    required property var modelData
    screen: modelData
    property bool open: false
    property bool closing: false
    visible: open
    onOpenChanged: Notifs.chatOpen = open
    // A new message in the chat being viewed is read right away.
    Connections {
        target: Notifs
        function onConvosChanged() { if (win.open && win.convo && win.convo.unread > 0) Notifs.markRead(win.convo.key); }
    }
    color: "transparent"
    anchors { top: true; bottom: true; left: true; right: true }
    exclusionMode: ExclusionMode.Ignore
    WlrLayershell.layer: WlrLayer.Overlay
    WlrLayershell.namespace: "saphie-chat"
    // While an assisted reply is typed into the app (behind this page), the page lets go of the
    // keyboard; it takes it back as soon as the helper finishes. The page itself stays open.
    property bool sendingAssist: false
    WlrLayershell.keyboardFocus: open && !sendingAssist ? WlrKeyboardFocus.Exclusive : WlrKeyboardFocus.None
    Connections {
        target: Notifs
        function onAssistResult(ok, sender, label) {
            if (!win.sendingAssist) return;
            win.sendingAssist = false;
            Qt.callLater(() => win.focusInput());
        }
    }
    readonly property bool portrait: height > width

    property string selKey: ""
    readonly property var convo: Notifs.convos.find(c => c.key === selKey) ?? Notifs.convos[0] ?? null
    readonly property bool canReply: Notifs.convoCanReply(convo)
    readonly property var quick: ["OK", "ON MY WAY", "LATER", "ได้เลย", "เดี๋ยวตอบนะ"]

    function show(key) {
        if (closing) { closeAnim.stop(); closing = false; }
        Notifs.recheckWtype();
        selKey = key || (Notifs.convos[0]?.key ?? "");
        if (convo) Notifs.markRead(convo.key);
        if (!open) { Sfx.play("open"); open = true; openAnim.restart(); }
        input.text = ""; Qt.callLater(() => input.forceActiveFocus());
    }
    function focusInput() { if (canReply) input.forceActiveFocus(); else keys.forceActiveFocus(); }
    function hide() { if (!open || closing) return; Sfx.play("close"); closeAnim.restart(); }
    function select(i) {
        const c = Notifs.convos[i]; if (!c) return;
        if (c.key !== selKey) Sfx.play("tick");
        selKey = c.key; Notifs.markRead(c.key); input.text = ""; switchAnim.restart();
    }
    function send(text) {
        if (!convo) return;
        const assisted = Notifs.isAssisted(convo);
        if (assisted) sendingAssist = true;              // release the keyboard before the helper types
        if (Notifs.convoReply(convo, text)) {
            input.text = "";
        } else { sendingAssist = false; Sfx.play("error"); }
    }
    function ago(t) {
        const s = Math.max(0, Math.round((Date.now() - t) / 1000));
        return s < 60 ? "NOW" : s < 3600 ? Math.floor(s / 60) + "M" : Math.floor(s / 3600) + "H";
    }

    component Avatar: Item {
        id: av
        property var c
        property int size: 40
        width: size; height: size
        ClippingRectangle {
            anchors.fill: parent; radius: width / 2
            color: pic.status === Image.Ready ? "transparent" : Theme.accentA
            border.color: Theme.bg; border.width: 2
            Image { id: pic; anchors.fill: parent; fillMode: Image.PreserveAspectCrop; asynchronous: true
                    source: av.c ? (av.c.image || (av.c.appIcon ? Quickshell.iconPath(av.c.appIcon, true) : "")) : ""
                    sourceSize.width: 96; sourceSize.height: 96; visible: status === Image.Ready }
            Text { anchors.centerIn: parent; visible: pic.status !== Image.Ready
                   text: av.c ? String(av.c.sender).trim().charAt(0).toUpperCase() : "?"
                   color: Theme.onAccent; font.family: Theme.fontFor(text, Theme.numeralFont)
                   font.weight: Font.ExtraBold; font.italic: true; font.pixelSize: av.size * 0.45 }
        }
    }

    // ---- backdrop
    Rectangle { id: dim; anchors.fill: parent; color: "#000000"; opacity: 0.6
                MouseArea { anchors.fill: parent; onClicked: win.hide() } }

    // ---- the phone panel
    Item {
        id: panel
        width: Math.min(win.width - 48, 980); height: Math.min(win.height - 120, win.portrait ? 900 : 640)
        x: (win.width - width) / 2; y: (win.height - height) / 2 + 10
        transform: [ Translate { id: panelT; y: 0 }, Scale { id: panelS; origin.x: panel.width / 2; origin.y: panel.height / 2; xScale: 1; yScale: 1 } ]
        MouseArea { anchors.fill: parent }      // clicks inside don't close

        Item {
            id: keys
            focus: true
            Keys.onPressed: ev => {
                const i = Notifs.convos.findIndex(c => c.key === (win.convo?.key ?? ""));
                if (ev.key === Qt.Key_Escape) win.hide();
                else if (ev.key === Qt.Key_Down && ev.modifiers & Qt.AltModifier) win.select(Math.min(Notifs.convos.length - 1, i + 1));
                else if (ev.key === Qt.Key_Up && ev.modifiers & Qt.AltModifier) win.select(Math.max(0, i - 1));
                else return;
                ev.accepted = true;
            }
        }

        Rectangle { x: 8; y: 8; width: parent.width; height: parent.height; color: Theme.bg }   // hard shadow
        Rectangle {
            anchors.fill: parent; color: Theme.surface; border.color: Theme.bg; border.width: 2
            topLeftRadius: 22; topRightRadius: 22; bottomLeftRadius: 22; bottomRightRadius: 0
            Rectangle { anchors.fill: parent; anchors.margins: 2; color: "transparent"; border.color: Theme.ring; border.width: 3
                        topLeftRadius: 20; topRightRadius: 20; bottomLeftRadius: 20 }
        }

        // header
        Item {
            id: head
            x: 22; y: 14; width: parent.width - 44; height: 44
            Rectangle {
                anchors.verticalCenter: parent.verticalCenter
                width: 130; height: 26; color: Theme.accentA; border.color: Theme.bg; border.width: 2
                transform: Matrix4x4 { matrix: Qt.matrix4x4(1, Theme.skew, 0, -Theme.skew * 13, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1) }
                Text { anchors.centerIn: parent; text: "CH ▸ CHAT"; color: Theme.onAccent
                       font.family: Theme.labelFont; font.pixelSize: 12; font.weight: Font.ExtraBold; font.letterSpacing: 1.4 }
            }
            Text { x: 150; anchors.verticalCenter: parent.verticalCenter; text: "MESSAGES"; color: Theme.text
                   font.family: Theme.titleFont; font.pixelSize: 24 }
            Text { anchors.right: parent.right; anchors.verticalCenter: parent.verticalCenter
                   text: win.portrait ? "ESC" : "ALT ↑↓ CHAT    ENTER SEND    ESC CLOSE"; color: Theme.textDim
                   font.family: Theme.labelFont; font.pixelSize: 10; font.weight: Font.ExtraBold; font.letterSpacing: 1 }
        }
        Rectangle { x: 14; y: head.y + head.height + 8; width: parent.width - 28; height: 2; color: Theme.ring }

        // ---- chat list
        ListView {
            id: list
            x: 14; y: head.y + head.height + 18
            width: win.portrait ? 230 : 290; height: parent.height - y - 18
            clip: true; spacing: 4; boundsBehavior: Flickable.StopAtBounds
            model: Notifs.convos
            property var chat: win           // delegates reach the window through ListView.view (id lookup failed there)
            delegate: Item {
                id: row
                required property var modelData
                required property int index
                readonly property bool on: modelData.key === (win.convo?.key ?? "")
                width: list.width - 8; height: 60
                Rectangle { anchors.fill: parent; anchors.leftMargin: 8
                            color: row.on ? Theme.accentA : (rm.containsMouse ? "#1f1f1f" : "transparent")
                            transform: Matrix4x4 { matrix: Qt.matrix4x4(1, Theme.skew * 0.4, 0, -Theme.skew * 12, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1) } }
                Avatar { x: 16; anchors.verticalCenter: parent.verticalCenter; c: row.modelData; size: 40 }
                Column {
                    x: 66; anchors.verticalCenter: parent.verticalCenter; width: parent.width - 66 - 44
                    Text { width: parent.width; elide: Text.ElideRight; text: row.modelData.sender; textFormat: Text.PlainText
                           color: row.on ? Theme.onAccent : Theme.text; font.family: Theme.fontFor(text, Theme.labelFont)
                           font.pixelSize: 14; font.weight: Font.Bold }
                    Text {
                        readonly property var last: row.modelData.msgs[row.modelData.msgs.length - 1]
                        width: parent.width; elide: Text.ElideRight; textFormat: Text.PlainText
                        text: last ? (last.call ? "📞 CALL" : (last.mine ? "YOU: " : "") + last.t.replace(/\n/g, " ")) : ""
                        color: row.on ? "#27500A" : (last && last.call ? Theme.danger : Theme.textDim)
                        font.family: Theme.fontFor(text, Theme.labelFont); font.pixelSize: 11
                    }
                }
                Column {
                    anchors.right: parent.right; anchors.rightMargin: 4; anchors.verticalCenter: parent.verticalCenter
                    spacing: 4
                    Text { anchors.right: parent.right; text: win.ago(row.modelData.at); color: row.on ? Theme.onAccent : Theme.raised
                           font.family: Theme.labelFont; font.pixelSize: 9; font.weight: Font.Bold }
                    Rectangle { anchors.right: parent.right; visible: row.modelData.unread > 0 && !row.on
                                width: Math.max(18, unr.implicitWidth + 8); height: 16; radius: 8; color: Theme.accentA
                                Text { id: unr; anchors.centerIn: parent; text: row.modelData.unread; color: Theme.onAccent
                                       font.family: Theme.labelFont; font.pixelSize: 10; font.weight: Font.ExtraBold } }
                }
                MouseArea { id: rm; anchors.fill: parent; hoverEnabled: true; onClicked: { const c = row.ListView.view.chat; c.select(row.index); c.focusInput(); } }
            }
            Text { visible: Notifs.convos.length === 0; x: 16; y: 20; width: parent.width - 32; wrapMode: Text.Wrap
                   text: "NO CHATS YET\nMessages from Messenger, WhatsApp, IG, Telegram, Discord... appear here as they arrive."
                   color: Theme.textDim; font.family: Theme.labelFont; font.pixelSize: 11; lineHeight: 1.3 }
        }
        Rectangle { x: list.x + list.width + 6; y: list.y; width: 2; height: list.height; color: Theme.ring }

        // ---- conversation
        Item {
            id: conv
            x: list.x + list.width + 22; y: list.y; width: parent.width - x - 22; height: list.height
            transform: Translate { id: convT; x: 0 }
            visible: win.convo !== null
            Item {   // contact header
                id: ch
                width: parent.width; height: 48
                Avatar { anchors.verticalCenter: parent.verticalCenter; c: win.convo; size: 40 }
                Text { x: 52; anchors.verticalCenter: parent.verticalCenter; width: parent.width - 52 - 220; elide: Text.ElideRight
                       text: win.convo?.sender ?? ""; textFormat: Text.PlainText; color: Theme.text
                       font.family: Theme.fontFor(text, Theme.numeralFont); font.weight: Font.ExtraBold
                       font.italic: !Theme.nonLatin(text); font.pixelSize: Theme.nonLatin(text) ? 19 : 26 }
                Rectangle { anchors.right: parent.right; anchors.verticalCenter: parent.verticalCenter
                            width: tagT.implicitWidth + 16; height: 20; color: Theme.accentA; border.color: Theme.bg; border.width: 1
                            transform: Matrix4x4 { matrix: Qt.matrix4x4(1, Theme.skew, 0, -Theme.skew * 10, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1) }
                            Text { id: tagT; anchors.centerIn: parent; text: win.convo ? Notifs.serviceName(win.convo) : ""
                                   color: Theme.onAccent; font.family: Theme.labelFont; font.pixelSize: 10; font.weight: Font.ExtraBold } }
            }
            Rectangle { y: ch.height + 4; width: parent.width; height: 1; color: Theme.ring; opacity: 0.6 }

            ListView {   // bubbles, newest at the bottom
                id: msgs
                y: ch.height + 12; width: parent.width; height: parent.height - y - compose.height - 14
                clip: true; spacing: 8; boundsBehavior: Flickable.StopAtBounds
                verticalLayoutDirection: ListView.BottomToTop
                model: win.convo ? win.convo.msgs.slice().reverse() : []
                delegate: Item {
                    id: mrow
                    required property var modelData
                    width: msgs.width; height: bub.height
                    Rectangle {
                        id: bub
                        x: mrow.modelData.mine ? parent.width - width : 0
                        readonly property bool hasImg: !!mrow.modelData.img && photo.status !== Image.Error
                        width: hasImg ? photo.width + 16 : Math.min(parent.width * 0.75, mt.implicitWidth + 24)
                        height: hasImg ? photo.height + cap.implicitHeight + 22 : mt.implicitHeight + 16
                        color: mrow.modelData.call ? "#3a0d05" : (mrow.modelData.mine ? Theme.accentA : "#262626")
                        Image {   // photo preview from the app's own cache (Notifs.setMedia)
                            id: photo
                            visible: bub.hasImg
                            x: 8; y: 8
                            source: mrow.modelData.img || ""
                            asynchronous: true; fillMode: Image.PreserveAspectFit
                            sourceSize.width: 520
                            width: Math.min(260, msgs.width * 0.7)
                            height: status === Image.Ready && implicitWidth > 0 ? width * implicitHeight / implicitWidth : 160
                        }
                        Text { id: cap; visible: bub.hasImg; x: 10; y: photo.y + photo.height + 4; width: photo.width - 4
                               text: "📷 " + Notifs.mediaLabel(mrow.modelData.t); elide: Text.ElideMiddle
                               color: Theme.textDim; font.family: Theme.labelFont; font.pixelSize: 11 }
                        border.color: mrow.modelData.call ? Theme.danger : "transparent"; border.width: mrow.modelData.call ? 1 : 0
                        topLeftRadius: 14; topRightRadius: 14
                        bottomLeftRadius: mrow.modelData.mine ? 14 : 3; bottomRightRadius: mrow.modelData.mine ? 3 : 14
                        Text {
                            id: mt
                            visible: !bub.hasImg
                            x: 12; y: 8; width: Math.min(implicitWidth, msgs.width * 0.75 - 24)
                            text: mrow.modelData.call ? "📞  " + mrow.modelData.t.toUpperCase()
                                : (!mrow.modelData.mine && Notifs.isMedia(mrow.modelData.t) ? "📷  " + Notifs.mediaLabel(mrow.modelData.t) + "\nPHOTO · TAP OPEN " + (win.convo ? Notifs.serviceName(win.convo) : "APP") + " TO SEE IT" : mrow.modelData.t)
                            textFormat: Text.PlainText; wrapMode: Text.Wrap
                            color: mrow.modelData.mine ? Theme.onAccent : (mrow.modelData.call ? "#ffb0a0" : "#eeeeee")
                            font.family: Theme.fontFor(text, Theme.labelFont); font.pixelSize: 14
                        }
                    }
                }
            }

            // compose: quick replies + reply box (or OPEN IN APP)
            Column {
                id: compose
                anchors.bottom: parent.bottom
                width: parent.width; spacing: 8
                Flow {
                    width: parent.width; spacing: 6
                    visible: win.canReply
                    Repeater {
                        model: win.quick
                        Rectangle {
                            required property string modelData
                            width: qt.implicitWidth + 24; height: 28
                            color: qm.containsMouse ? Theme.accentA : "transparent"; border.color: Theme.accentA; border.width: 2
                            transform: Matrix4x4 { matrix: Qt.matrix4x4(1, Theme.skew * 0.7, 0, -Theme.skew * 10, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1) }
                            Text { id: qt; anchors.centerIn: parent; text: parent.modelData
                                   color: qm.containsMouse ? Theme.onAccent : Theme.accentA
                                   font.family: Theme.fontFor(text, Theme.labelFont); font.pixelSize: 11; font.weight: Font.ExtraBold }
                            MouseArea { id: qm; anchors.fill: parent; hoverEnabled: true
                                        onClicked: win.send(/^[A-Z ]+$/.test(parent.modelData) ? parent.modelData.charAt(0) + parent.modelData.slice(1).toLowerCase() : parent.modelData) }
                        }
                    }
                }
                Item {
                    width: parent.width; height: 40
                    Rectangle {
                        visible: win.canReply
                        width: parent.width - 54 - (Notifs.isAssisted(win.convo) ? 120 : 0); height: 38
                        color: "#101010"; border.color: input.activeFocus ? Theme.accentA : Theme.ring; border.width: 2
                        transform: Matrix4x4 { matrix: Qt.matrix4x4(1, Theme.skew * 0.4, 0, -Theme.skew * 8, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1) }
                        TextInput {
                            id: input
                            x: 14; width: parent.width - 28; anchors.verticalCenter: parent.verticalCenter
                            color: Theme.text; font.family: Theme.fontFor(text, Theme.labelFont); font.pixelSize: 14
                            maximumLength: 2000; clip: true
                            Keys.onReturnPressed: win.send(text)
                            Keys.onEnterPressed: win.send(text)
                            Keys.onEscapePressed: win.hide()
                            Keys.onPressed: ev => {
                                if ((ev.key === Qt.Key_Down || ev.key === Qt.Key_Up) && (ev.modifiers & Qt.AltModifier)) {
                                    const i = Notifs.convos.findIndex(c => c.key === (win.convo?.key ?? ""));
                                    win.select(ev.key === Qt.Key_Down ? Math.min(Notifs.convos.length - 1, i + 1) : Math.max(0, i - 1));
                                    ev.accepted = true;
                                }
                            }
                        }
                        Text { x: 14; anchors.verticalCenter: parent.verticalCenter; visible: input.text.length === 0
                               text: Notifs.isAssisted(win.convo) ? "Message " + (win.convo?.sender ?? "") + " (sent through " + Notifs.serviceName(win.convo) + ")…"
                                                                  : "Reply to " + (win.convo?.sender ?? "") + "…"; color: Theme.raised
                               font.family: Theme.fontFor(text, Theme.labelFont); font.pixelSize: 13 }
                    }
                    Text {   // alternative: just open the app on this chat
                        visible: win.canReply && Notifs.isAssisted(win.convo)
                        anchors.right: parent.right; anchors.rightMargin: 50; anchors.verticalCenter: parent.verticalCenter
                        text: "OPEN " + (win.convo ? Notifs.serviceName(win.convo) : "") + " ▸"
                        color: oam.containsMouse ? Theme.accentA : Theme.textDim
                        font.family: Theme.labelFont; font.pixelSize: 10; font.weight: Font.ExtraBold
                        MouseArea { id: oam; anchors.fill: parent; anchors.margins: -6; hoverEnabled: true
                                    onClicked: { Sfx.play("confirm"); Notifs.convoOpenApp(win.convo); win.hide(); } }
                    }
                    Rectangle {   // send
                        visible: win.canReply
                        anchors.right: parent.right; width: 40; height: 40; radius: 20
                        color: sm.containsMouse || input.text.length ? Theme.accentA : "#262626"; border.color: Theme.bg; border.width: 2
                        Text { anchors.centerIn: parent; text: "➤"; color: input.text.length ? Theme.onAccent : Theme.textDim; font.pixelSize: 16 }
                        MouseArea { id: sm; anchors.fill: parent; hoverEnabled: true; onClicked: win.send(input.text) }
                    }
                    Row {   // apps without inline reply
                        visible: !win.canReply
                        anchors.verticalCenter: parent.verticalCenter; spacing: 14
                        Rectangle {
                            width: oa.implicitWidth + 36; height: 36
                            color: om.containsMouse ? Theme.accentA : Theme.text; border.color: Theme.bg; border.width: 2
                            transform: Matrix4x4 { matrix: Qt.matrix4x4(1, Theme.skew, 0, -Theme.skew * 18, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1) }
                            Text { id: oa; anchors.centerIn: parent; text: "OPEN IN " + (win.convo ? Notifs.serviceName(win.convo) : "APP") + "  ▸"
                                   color: Theme.onAccent; font.family: Theme.labelFont; font.pixelSize: 12; font.weight: Font.ExtraBold; font.letterSpacing: 1 }
                            MouseArea { id: om; anchors.fill: parent; hoverEnabled: true
                                        onClicked: { Sfx.play("confirm"); Notifs.convoOpenApp(win.convo); win.hide(); } }
                        }
                        Text { anchors.verticalCenter: parent.verticalCenter; text: "THIS APP DOESN'T SUPPORT REPLIES FROM SAPHIE"
                               color: Theme.raised; font.family: Theme.labelFont; font.pixelSize: 10; font.weight: Font.ExtraBold }
                    }
                }
            }
        }
    }

    // ---- animations: phone pops up from below with overshoot; reverse on close; slide on chat switch
    ParallelAnimation {
        id: openAnim
        NumberAnimation { target: dim; property: "opacity"; from: 0; to: 0.6; duration: 220 }
        NumberAnimation { target: panelT; property: "y"; from: 80; to: 0; duration: 380; easing.type: Easing.OutBack; easing.overshoot: 1.4 }
        NumberAnimation { target: panelS; property: "yScale"; from: 0.82; to: 1; duration: 380; easing.type: Easing.OutBack; easing.overshoot: 1.6 }
        NumberAnimation { target: panel; property: "opacity"; from: 0; to: 1; duration: 140 }
    }
    SequentialAnimation {
        id: closeAnim
        ScriptAction { script: win.closing = true }
        ParallelAnimation {
            NumberAnimation { target: dim; property: "opacity"; to: 0; duration: 200 }
            NumberAnimation { target: panelT; property: "y"; to: 70; duration: 220; easing.type: Easing.InBack }
            NumberAnimation { target: panelS; property: "yScale"; to: 0.85; duration: 220; easing.type: Easing.InQuad }
            NumberAnimation { target: panel; property: "opacity"; to: 0; duration: 200 }
        }
        ScriptAction { script: { win.open = false; win.closing = false; panelT.y = 0; panelS.yScale = 1; panel.opacity = 1; } }
    }
    NumberAnimation { id: switchAnim; target: convT; property: "x"; from: 30; to: 0; duration: 260; easing.type: Easing.OutBack; easing.overshoot: 1.6 }
}
