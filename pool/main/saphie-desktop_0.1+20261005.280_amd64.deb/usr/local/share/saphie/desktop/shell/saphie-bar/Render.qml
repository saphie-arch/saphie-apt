pragma Singleton
import Quickshell
import Quickshell.Io
import QtQuick

// Render34 client (render34/ in the repo): talks to the render PC (PC-B) over its JSON API with
// the shared token. Used by the bar sticker (RenderSticker) and the app window (RenderApp).
//   ~/.config/render34/config.json  "pcb_url": "http://100.x.y.z:8080"  (set on both PCs)
//   ~/.config/render34/token        shared secret (mode 0600, same on both PCs)
// configured = both exist. state = GET /api/state, polled every 2 s while online (15 s when the
// render PC can't be reached, so a sleeping PC-B costs nothing).
Singleton {
    id: root
    readonly property string dir: (Quickshell.env("XDG_CONFIG_HOME") || (Quickshell.env("HOME") + "/.config")) + "/render34"
    property string url: ""          // PC-B base URL, no trailing slash
    property string token: ""
    readonly property bool configured: url !== "" && token !== ""
    property bool online: false
    property var state: null         // /api/state
    readonly property var current: state ? state.current : null
    readonly property int queued: state ? (state.queued || 0) : 0
    property double lastOk: 0

    FileView {
        id: cfgFile
        path: root.dir + "/config.json"
        printErrors: false
        watchChanges: true
        onFileChanged: reload()
        onLoaded: {
            try {
                const u = String(JSON.parse(text()).pcb_url || "").trim().replace(/\/+$/, "");
                root.url = /^https?:\/\/[A-Za-z0-9.\-\[\]:]+$/.test(u) ? u : "";
            } catch (e) { root.url = ""; }
        }
        onLoadFailed: root.url = ""
    }
    FileView {
        id: tokenFile
        path: root.dir + "/token"
        printErrors: false
        watchChanges: true
        onFileChanged: reload()
        onLoaded: { const t = text().trim(); root.token = /^[A-Za-z0-9_\-]{16,128}$/.test(t) ? t : ""; }
        onLoadFailed: root.token = ""
    }

    // One request. cb(ok, json, status). Never throws; times out after `ms`.
    function api(method, path, cb, body, ms) {
        if (!configured) { if (cb) cb(false, null, 0); return; }
        const x = new XMLHttpRequest();
        let done = false;
        const t = Qt.createQmlObject('import QtQuick; Timer { interval: ' + (ms || 8000) + ' }', root);
        t.triggered.connect(() => { if (!done) { done = true; x.abort(); if (cb) cb(false, null, 0); } t.destroy(); });
        x.onreadystatechange = () => {
            if (x.readyState !== XMLHttpRequest.DONE || done) return;
            done = true; t.stop(); t.destroy();
            let j = null;
            try { j = x.responseText ? JSON.parse(x.responseText) : null; } catch (e) {}
            if (cb) cb(x.status >= 200 && x.status < 300, j, x.status);
        };
        x.open(method, url + path);
        x.setRequestHeader("X-Render34-Token", token);
        if (body !== undefined) x.setRequestHeader("Content-Type", "application/json");
        x.send(body !== undefined ? JSON.stringify(body) : null);
        t.start();
    }
    // URLs for Image / mpv (QML Image can't send headers: these endpoints accept t=).
    function media(path) { return configured ? url + path + (path.includes("?") ? "&" : "?") + "t=" + encodeURIComponent(token) : ""; }
    function q(v) { return encodeURIComponent(String(v)); }

    function poll() {
        api("GET", "/api/state", (ok, j) => {
            root.online = ok && !!j;
            if (ok && j) { root.state = j; root.lastOk = Date.now(); }
            else if (Date.now() - root.lastOk > 10000) root.state = null;
            poller.interval = root.online ? 2000 : 15000;
        }, undefined, 4000);
    }
    // The files may appear later (install.sh / setup): look again every 5 s until configured.
    Timer { interval: 5000; repeat: true; running: !root.configured
            onTriggered: { cfgFile.reload(); tokenFile.reload(); } }
    Timer { id: poller; interval: 2000; repeat: true; running: root.configured; triggeredOnStart: true; onTriggered: root.poll() }

    // Open a finished video in mpv, streamed from PC-B (token in a header, not in the URL).
    Process { id: player }
    function play(name) {
        if (!configured) return;
        player.exec(["mpv", "--force-window=immediate", "--title=" + name,
                     "--http-header-fields=X-Render34-Token: " + token,
                     url + "/api/stream?name=" + q(name)]);
    }
    // The web UI (for things the app doesn't do, e.g. add-on details): logs in via the token link.
    function openWeb() { if (configured) Quickshell.execDetached(["xdg-open", url + "/login?t=" + encodeURIComponent(token)]); }

    function fmtTime(s) {
        if (s === null || s === undefined || s < 0) return "–";
        s = Math.round(s);
        const h = Math.floor(s / 3600), m = Math.floor(s % 3600 / 60), ss = s % 60;
        return h ? h + "h " + m + "m" : (m ? m + "m " + String(ss).padStart(2, "0") + "s" : ss + "s");
    }
    function shortName(n) { return String(n || "").replace(/^.*\//, "").replace(/\.blend$/i, ""); }
}
