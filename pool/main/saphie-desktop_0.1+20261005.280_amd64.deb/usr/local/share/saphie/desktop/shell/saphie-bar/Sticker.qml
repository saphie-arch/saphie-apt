import QtQuick

// A "sticker" module: hard offset shadow, black edge, grey inner ring, one sharp corner.
// sharp: "tl" | "tr" | "br" | "bl" picks the corner that stays square.
Item {
    id: root
    property string sharp: "br"
    property int padding: 12
    property bool interactive: false
    property bool usesWheel: false   // only then the wheel is ours; otherwise it scrolls the bar sideways
    property int order: 0          // drop-in stagger position (left to right)
    signal clicked(int button)
    signal wheel(int delta)
    default property alias content: inner.data
    implicitWidth: inner.childrenRect.width + padding * 2
    implicitHeight: parent ? parent.height : 32

    function r(corner) { return corner === sharp ? 0 : Theme.corner; }

    // Juice: stickers drop in with an overshoot when the bar starts (staggered), pop on hover and
    // squish when pressed. All event-driven: nothing animates while idle.
    transform: Translate { id: drop; y: -64 }
    opacity: 0
    Component.onCompleted: dropIn.start()
    SequentialAnimation {
        id: dropIn
        PauseAnimation { duration: 120 + root.order * 45 }
        ParallelAnimation {
            NumberAnimation { target: drop; property: "y"; to: 0; duration: 420; easing.type: Easing.OutBack; easing.overshoot: 1.8 }
            NumberAnimation { target: root; property: "opacity"; to: 1; duration: 120 }
        }
    }
    scale: mouse.pressed ? 0.93 : (mouse.containsMouse ? 1.05 : 1.0)
    Behavior on scale { NumberAnimation { duration: 180; easing.type: Easing.OutBack; easing.overshoot: 2.2 } }

    Rectangle {   // hard shadow
        x: Theme.shadow; y: Theme.shadow; width: root.width; height: root.height
        color: Theme.bg
        topLeftRadius: root.r("tl"); topRightRadius: root.r("tr")
        bottomRightRadius: root.r("br"); bottomLeftRadius: root.r("bl")
    }
    Rectangle {   // black edge
        anchors.fill: parent
        color: Theme.bg
        topLeftRadius: root.r("tl"); topRightRadius: root.r("tr")
        bottomRightRadius: root.r("br"); bottomLeftRadius: root.r("bl")
        Rectangle {   // surface + inner ring
            anchors.fill: parent; anchors.margins: Theme.edge
            color: Theme.surface
            border.color: Theme.ring; border.width: Theme.ringWidth
            topLeftRadius: Math.max(0, root.r("tl") - Theme.edge); topRightRadius: Math.max(0, root.r("tr") - Theme.edge)
            bottomRightRadius: Math.max(0, root.r("br") - Theme.edge); bottomLeftRadius: Math.max(0, root.r("bl") - Theme.edge)
        }
    }
    Item {
        id: inner
        x: root.padding
        width: childrenRect.width
        anchors.verticalCenter: parent.verticalCenter
        height: childrenRect.height
    }
    MouseArea {
        id: mouse
        anchors.fill: parent
        hoverEnabled: root.interactive
        enabled: root.interactive
        cursorShape: root.interactive ? Qt.PointingHandCursor : Qt.ArrowCursor
        acceptedButtons: Qt.LeftButton | Qt.RightButton | Qt.MiddleButton
        onClicked: ev => root.clicked(ev.button)
        onWheel: ev => { if (root.usesWheel) root.wheel(ev.angleDelta.y); else ev.accepted = false; }
    }
}
