pragma Singleton
import Quickshell
import Quickshell.Io
import QtQuick

// niri state from its own IPC event stream (format verified against niri-ipc at the pinned
// commit). Everything read from the stream is validated before use.
Singleton {
    id: root

    property var workspaces: []      // [{id, idx, output, is_active, is_focused, is_urgent, active_window_id}]
    property var windows: ({})       // id -> {id, title, app_id, workspace_id, is_focused, is_urgent}
    property bool connected: false
    property bool windowsSeeded: false
    property var kbLayouts: []           // keyboard layout names from niri, e.g. ["English (US)", "Thai"]
    property int kbIndex: 0
    // Short tag for the bar: EN, TH, ... (first two letters of the layout name, or the code).
    readonly property string kbTag: {
        const n = kbLayouts[kbIndex] ?? "";
        const map = { "English": "EN", "Thai": "TH", "Japanese": "JA", "Korean": "KO", "Chinese": "ZH", "Russian": "RU" };
        for (const k in map) if (n.startsWith(k)) return map[k];
        return n ? n.slice(0, 2).toUpperCase() : "";
    }
    function switchLayout() { send({ SwitchLayout: { layout: "Next" } }); }   // first full window list received (no open sounds before)
    signal screenshotTaken(string path)   // from niri's ScreenshotCaptured event (validated)
    property var layoutModes: ({})   // workspace id -> mode, from saphie-layout's status file

    function isId(v) { return typeof v === "number" && Number.isInteger(v) && v >= 0; }
    function str(v, max) { return typeof v === "string" ? v.slice(0, max) : ""; }

    function cleanWorkspace(w) {
        if (!w || !isId(w.id)) return null;
        return {
            id: w.id,
            idx: isId(w.idx) ? w.idx : 0,
            output: str(w.output, 64),
            name: str(w.name, 64),             // set = a channel the user added (kept when empty)
            is_active: w.is_active === true,
            is_focused: w.is_focused === true,
            is_urgent: w.is_urgent === true,
            active_window_id: isId(w.active_window_id) ? w.active_window_id : null
        };
    }
    function cleanWindow(w) {
        if (!w || !isId(w.id)) return null;
        return {
            id: w.id,
            title: str(w.title, 512),
            app_id: str(w.app_id, 128),
            workspace_id: isId(w.workspace_id) ? w.workspace_id : null,
            is_focused: w.is_focused === true,
            is_urgent: w.is_urgent === true,
            fs: w.is_fullscreen === true,
            size: cleanSize(w.layout)
        };
    }
    function cleanSize(l) {   // window_size [w, h] from niri's layout, or null
        const s = l && Array.isArray(l.window_size) ? l.window_size : null;
        return s && s.length === 2 && s.every(v => typeof v === "number" && v >= 0 && v < 100000) ? [s[0], s[1]] : null;
    }
    // True when the active window on `output` covers the whole screen (fullscreen, Super+Shift+F).
    // niri 26.04 does not report fullscreen in IPC, so the window size is compared with the screen.
    function fullscreenOn(output, w, h) {
        const ws = workspaces.find(x => x.output === output && x.is_active);
        const win = ws && ws.active_window_id !== null ? windows[ws.active_window_id] : null;
        if (!win) return false;
        if (win.fs) return true;
        return win.size !== null && Math.abs(win.size[0] - w) <= 2 && Math.abs(win.size[1] - h) <= 2;
    }

    function workspacesFor(output) {
        const own = workspaces.filter(w => w.output === output);
        return own.length > 0 ? own : workspaces;   // unknown output name: show everything
    }
    function occupied(wsId) {
        for (const k in windows) if (windows[k].workspace_id === wsId) return true;
        return false;
    }
    function activeTitle(output) {
        const ws = workspaces.find(w => w.output === output && w.is_active);
        if (!ws || ws.active_window_id === null) return "";
        const win = windows[ws.active_window_id];
        return win ? (win.title || win.app_id) : "";
    }

    // Layout mode of the active workspace on an output ("scroll" when the daemon has none).
    function layoutFor(output) {
        const ws = workspaces.find(w => w.output === output && w.is_active);
        const m = ws ? layoutModes[String(ws.id)] : undefined;
        return ["master", "dwindle", "grid", "monocle"].includes(m) ? m : "scroll";
    }
    // Cycle the layout of the workspace shown on `output` (not necessarily the focused one).
    function cycleLayout(output) {
        const ws = workspaces.find(w => w.output === output && w.is_active);
        if (!ws || !isId(ws.id)) return;
        layoutCtl.exec(["/usr/local/opt/saphie/saphie-layout/bin/saphie-layout",
                        "cycle", "--workspace", String(ws.id)]);
    }

    function setWorkspaces(list) {
        workspaces = list.slice().sort((a, b) => a.output === b.output ? a.idx - b.idx : (a.output < b.output ? -1 : 1));
    }

    function handle(line) {
        let ev;
        try { ev = JSON.parse(line); } catch (e) { return; }
        if (!ev || typeof ev !== "object") return;

        if (ev.WorkspacesChanged && Array.isArray(ev.WorkspacesChanged.workspaces)) {
            setWorkspaces(ev.WorkspacesChanged.workspaces.map(cleanWorkspace).filter(w => w));
        } else if (ev.WorkspaceActivated && isId(ev.WorkspaceActivated.id)) {
            const id = ev.WorkspaceActivated.id, focused = ev.WorkspaceActivated.focused === true;
            const target = workspaces.find(w => w.id === id);
            if (!target) return;
            setWorkspaces(workspaces.map(w => Object.assign({}, w, {
                is_active: w.output === target.output ? w.id === id : w.is_active,
                is_focused: focused ? w.id === id : w.is_focused
            })));
        } else if (ev.WorkspaceUrgencyChanged && isId(ev.WorkspaceUrgencyChanged.id)) {
            const e = ev.WorkspaceUrgencyChanged;
            setWorkspaces(workspaces.map(w => w.id === e.id ? Object.assign({}, w, { is_urgent: e.urgent === true }) : w));
        } else if (ev.WorkspaceActiveWindowChanged && isId(ev.WorkspaceActiveWindowChanged.workspace_id)) {
            const e = ev.WorkspaceActiveWindowChanged;
            const win = isId(e.active_window_id) ? e.active_window_id : null;
            setWorkspaces(workspaces.map(w => w.id === e.workspace_id ? Object.assign({}, w, { active_window_id: win }) : w));
        } else if (ev.WindowsChanged && Array.isArray(ev.WindowsChanged.windows)) {
            const m = {};
            for (const w of ev.WindowsChanged.windows) { const c = cleanWindow(w); if (c) m[c.id] = c; }
            windows = m;
            windowsSeeded = true;
        } else if (ev.WindowOpenedOrChanged) {
            const c = cleanWindow(ev.WindowOpenedOrChanged.window);
            if (!c) return;
            // TV switch-on sound for a really new window (not a title/focus change, and not the
            // initial window list the stream sends on connect: that comes as WindowsChanged).
            if (root.windowsSeeded && !windows[c.id]) Sfx.play("window-open");
            const m = Object.assign({}, windows);
            if (c.is_focused) for (const k in m) if (m[k].is_focused) m[k] = Object.assign({}, m[k], { is_focused: false });
            m[c.id] = c;
            windows = m;
        } else if (ev.WindowLayoutsChanged && Array.isArray(ev.WindowLayoutsChanged.changes)) {
            const m = Object.assign({}, windows);
            for (const ch of ev.WindowLayoutsChanged.changes.slice(0, 500)) {
                if (!Array.isArray(ch) || ch.length !== 2 || !isId(ch[0]) || !m[ch[0]]) continue;
                m[ch[0]] = Object.assign({}, m[ch[0]], { size: cleanSize(ch[1]) });
            }
            windows = m;
        } else if (ev.WindowClosed && isId(ev.WindowClosed.id)) {
            // TV switch-off sound, in time with niri's window-close animation (only for windows we
            // knew about, so a stream reconnect cannot cause a burst of sounds).
            if (Theme.closeSound && windows[ev.WindowClosed.id])
                Sfx.play("window-close");
            const m = Object.assign({}, windows);
            delete m[ev.WindowClosed.id];
            windows = m;
        } else if (ev.KeyboardLayoutsChanged && ev.KeyboardLayoutsChanged.keyboard_layouts) {
            const kl = ev.KeyboardLayoutsChanged.keyboard_layouts;
            if (Array.isArray(kl.names)) kbLayouts = kl.names.slice(0, 16).map(n => str(n, 64));
            if (isId(kl.current_idx)) kbIndex = kl.current_idx;
        } else if (ev.KeyboardLayoutSwitched && isId(ev.KeyboardLayoutSwitched.idx)) {
            kbIndex = ev.KeyboardLayoutSwitched.idx;
        } else if (ev.ScreenshotCaptured) {
            const p = str(ev.ScreenshotCaptured.path ?? "", 1024);
            const home = Quickshell.env("HOME") ?? "";
            // Only accept PNGs inside the home folder, no "..": the path is shown and opened.
            if (p === "" || (home && p.startsWith(home + "/") && p.endsWith(".png") && p.indexOf("/../") < 0))
                root.screenshotTaken(p);
        } else if (ev.WindowFocusChanged) {
            const id = isId(ev.WindowFocusChanged.id) ? ev.WindowFocusChanged.id : null;
            const m = {};
            for (const k in windows) m[k] = Object.assign({}, windows[k], { is_focused: windows[k].id === id });
            windows = m;
        } else if (ev.WindowUrgencyChanged && isId(ev.WindowUrgencyChanged.id) && windows[ev.WindowUrgencyChanged.id]) {
            const m = Object.assign({}, windows);
            m[ev.WindowUrgencyChanged.id] = Object.assign({}, m[ev.WindowUrgencyChanged.id], { is_urgent: ev.WindowUrgencyChanged.urgent === true });
            windows = m;
        }
    }

    // ---- actions over niri's socket (one connection carries many requests)
    // True once the control socket is really connected (writes before that are lost).
    readonly property bool canSend: control.connected
    function send(action) {
        if (!control.connected) control.connected = true;
        control.write(JSON.stringify({ Action: action }) + "\n");
        control.flush();
    }
    function focusWorkspace(id) { if (isId(id)) send({ FocusWorkspace: { reference: { Id: id } } }); }
    // Close the active window of the workspace shown on `output` (bar close button).
    function activeWindowId(output) {
        const ws = workspaces.find(w => w.output === output && w.is_active);
        return ws && isId(ws.active_window_id) && windows[ws.active_window_id] ? ws.active_window_id : null;
    }
    function closeActive(output) {
        const id = activeWindowId(output);
        if (id !== null) send({ CloseWindow: { id: id } });
    }
    // Channels the user adds ("+" on the bar) are named workspaces: niri keeps them even when
    // empty. niri's own automatic ones still appear/disappear by themselves.
    function addChannel(output) {
        const own = workspaces.filter(w => w.output === output).sort((a, b) => a.idx - b.idx);
        const last = own[own.length - 1];
        if (!last || !isId(last.id) || occupied(last.id)) return;   // niri keeps one empty at the end
        send({ SetWorkspaceName: { name: "saphie-ch-" + last.id, workspace: { Id: last.id } } });
        send({ FocusWorkspace: { reference: { Id: last.id } } });
    }
    function removeChannel(ws) {   // only channels added with "+"; an empty one disappears now
        if (!ws || !isId(ws.id) || !ws.name) return;
        send({ UnsetWorkspaceName: { reference: { Id: ws.id } } });
        if (ws.is_active && !occupied(ws.id)) send({ FocusWorkspaceUp: {} });   // leave it so niri drops it
    }
    function focusWorkspaceUp() { send({ FocusWorkspaceUp: {} }); }
    function focusWorkspaceDown() { send({ FocusWorkspaceDown: {} }); }

    Socket {
        id: control
        path: Quickshell.env("NIRI_SOCKET") ?? ""
        connected: path !== ""
        parser: SplitParser { onRead: _ => {} }   // replies are only {"Ok":"Handled"}; drain them
    }

    Process {
        id: events
        command: ["niri", "msg", "--json", "event-stream"]
        running: true
        stdout: SplitParser { onRead: line => { root.connected = true; root.handle(line); } }
        onExited: { root.connected = false; restart.start(); }
    }
    Timer { id: restart; interval: 2000; onTriggered: events.running = true }

    Process { id: layoutCtl }
    FileView {
        path: (Quickshell.env("XDG_RUNTIME_DIR") ?? "/nonexistent") + "/saphie-layout.json"
        watchChanges: true
        printErrors: false
        onFileChanged: reload()
        onLoaded: {
            try {
                const d = JSON.parse(text());
                root.layoutModes = d && typeof d.modes === "object" && d.modes ? d.modes : {};
            } catch (e) { root.layoutModes = {}; }
        }
        onLoadFailed: root.layoutModes = {}
    }
}
