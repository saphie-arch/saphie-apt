pragma Singleton
import Quickshell
import Quickshell.Services.Notifications
import Quickshell.Io
import QtQuick

// Saphie notification service (org.freedesktop.Notifications): message threads for the pop-up
// stack (NotificationPopups.qml) + history (NotificationCenter.qml).
// Pop-ups are grouped into threads per app + sender, like a phone chat: new messages from the
// same person stack as bubbles in one card. Calls (detected from hints, actions or text) get a
// call card with accept/decline and a ringtone. Replies use the app's own inline reply when it
// offers one (Telegram, KDE apps...); otherwise the card offers OPEN CHAT (the app's default
// action, e.g. focus the browser tab). Everything an app sends is shown as plain text.
Singleton {
    id: root
    property var threads: []         // social only: [{key, kind: msg|call, tag, appName, sender, image, appIcon, msgs, n, critical, stamp}]
    property var appNotes: []        // everything else (downloads, updates, system...): [{id, n, tag, stamp}]
    // Social = chat apps (by name/site), or apps that mark a chat message (im.*) or a call.
    readonly property var socialTags: ["MSGR", "WA", "IG", "TG", "DC", "SIG", "LINE", "SLACK", "TEAMS"]
    function isSocial(n, tag) {
        return socialTags.includes(tag) || /^im(\.|$)/i.test(String(n.hints?.category ?? ""));
    }
    // A notification's actions, or [] once the app has closed it (the object's list is gone then).
    function acts(n) {
        try { const a = n ? n.actions : null; return a && typeof a.length === "number" ? Array.from(a) : []; } catch (e) { return []; }
    }
    function defaultAct(n) { const a = acts(n); return a.find(x => x.identifier === "default") ?? a[0] ?? null; }
    function removeApp(id) { appNotes = appNotes.filter(a => a.id !== id); }
    function dismissApp(a) { removeApp(a.id); try { a.n.dismiss(); } catch (e) {} }
    function activateApp(a) {
        removeApp(a.id);
        try { const d = acts(a.n).find(x => x.identifier === "default") ?? null; if (d) d.invoke(); else a.n.dismiss(); } catch (e) {}
    }
    property bool dnd: false         // Do Not Disturb: keep history, no pop-ups/sound (calls still show)
    property int unread: 0
    readonly property var history: server.trackedNotifications.values
    readonly property bool ringing: threads.some(t => t.kind === "call")
    // Saphie Chat (Chat.qml): every conversation seen this session, newest first. In memory only
    // (messages are never written to disk); cleared at logout.
    // [{key, tag, appName, sender, image, appIcon, msgs: [{t, mine, call, at}], n, unread, at}]
    property var convos: []
    property bool chatOpen: false             // Saphie Chat on screen: chat messages go only into it
    readonly property int convoUnread: convos.reduce((a, c) => a + c.unread, 0)
    signal openChat(string key)               // a card asks Saphie Chat to open this conversation
    function convoKey(tag, sender) { return tag + "|" + sender; }
    function addToConvo(n, tag, sender, body, isCallMsg) {
        const key = convoKey(tag, sender);
        const old = convos.find(c => c.key === key);
        const msg = { t: body, mine: false, call: isCallMsg, at: Date.now() };
        const c = { key: key, tag: tag, appName: n.appName, sender: sender, image: n.image || (old ? old.image : ""),
                    appIcon: n.appIcon, msgs: (old ? old.msgs : []).concat(body || isCallMsg ? [msg] : []).slice(-60),
                    n: n, unread: (old ? old.unread : 0) + 1, at: Date.now() };
        convos = [c].concat(convos.filter(x => x.key !== key)).slice(0, 40);
    }
    function markRead(key) { convos = convos.map(c => c.key === key ? Object.assign({}, c, { unread: 0 }) : c); }
    // Assisted reply (apps without inline reply, e.g. Discord): open the chat with the app's own
    // "View" action, then saphie-assist-reply types the text only if the focused window really
    // is that chat (bin/saphie-assist-reply). Needs wtype (sudo apt install wtype).
    readonly property var assistedTags: ({ DC: "discord" })
    property bool wtypeOk: false
    Process { id: wtypeCheck; running: true; command: ["sh", "-c", "command -v wtype >/dev/null"]; onExited: code => root.wtypeOk = code === 0 }
    function recheckWtype() { if (!wtypeCheck.running) wtypeCheck.running = true; }
    // Works even after the app closed its notification: then the helper only brings the app forward
    // and still types only if the app already shows that chat.
    function isAssisted(c) { return !!(c && assistedTags[c.tag] && wtypeOk && !(c.n && c.n.hasInlineReply)); }
    property var assistPending: null
    signal assistResult(bool ok, string sender, string appLabel)
    Process {
        id: assistProc
        onExited: code => {
            const p = root.assistPending; root.assistPending = null;
            if (!p) return;
            if (code === 0) {
                root.convos = root.convos.map(x => x.key === p.key ? Object.assign({}, x, { msgs: x.msgs.concat([{ t: p.text, mine: true, call: false, at: Date.now() }]).slice(-60), unread: 0 }) : x);
                Sfx.play("confirm");
            } else {
                Sfx.play("error");
                Quickshell.execDetached(["notify-send", "-a", "Saphie Chat", "Not sent to " + p.label,
                    code === 3 ? "Install wtype first: sudo apt install wtype" : p.label + " is open on the chat with " + p.sender + ": type your message there."]);
            }
            root.assistResult(code === 0, p.sender, p.label);
        }
    }
    function assistReply(c, text) {
        const s = String(text ?? "").trim().slice(0, 2000);
        if (!s || !isAssisted(c) || assistProc.running) return false;
        const d = defaultAct(c.n);                      // none if the app already closed it
        try { if (d) d.invoke(); } catch (e) {}         // Discord opens that DM / channel
        assistPending = { key: c.key, text: s, sender: c.sender, label: serviceName(c) };
        assistProc.exec([Quickshell.shellDir + "/../../bin/saphie-assist-reply", assistedTags[c.tag], c.sender, s]);
        return true;
    }
    function convoCanReply(c) { return !!(c && ((c.n && c.n.hasInlineReply) || isAssisted(c))); }
    function convoReply(c, text) {
        const s = String(text ?? "").trim().slice(0, 2000);
        if (!s || !convoCanReply(c)) return false;
        if (isAssisted(c)) return assistReply(c, s);
        c.n.sendInlineReply(s);
        convos = convos.map(x => x.key === c.key ? Object.assign({}, x, { msgs: x.msgs.concat([{ t: s, mine: true, call: false, at: Date.now() }]).slice(-60), unread: 0 }) : x);
        Sfx.play("confirm");
        return true;
    }
    function convoOpenApp(c) {
        if (!c || !c.n) return;
        const a = defaultAct(c.n);
        try { if (a) a.invoke(); } catch (e) {}
    }

    // ---- channel tag per messaging app (app name, desktop entry, or the site browsers put in the body)
    readonly property var channels: [
        [/messenger|facebook/i, "MSGR"], [/whatsapp/i, "WA"], [/instagram/i, "IG"], [/telegram/i, "TG"],
        [/discord/i, "DC"], [/signal/i, "SIG"], [/line(\.me)?\b|naver/i, "LINE"], [/slack/i, "SLACK"],
        [/teams/i, "TEAMS"], [/thunderbird|mail|gmail/i, "MAIL"], [/steam/i, "STEAM"]]
    readonly property var serviceNames: ({ MSGR: "MESSENGER", WA: "WHATSAPP", IG: "INSTAGRAM", TG: "TELEGRAM",
                                           DC: "DISCORD", SIG: "SIGNAL", LINE: "LINE", SLACK: "SLACK", TEAMS: "TEAMS",
                                           MAIL: "MAIL", STEAM: "STEAM" })
    function serviceName(t) { return serviceNames[t.tag] ?? String(t.appName || "SYSTEM").toUpperCase(); }
    function tagFor(n) {
        const hay = [n.appName, n.desktopEntry, n.body].join(" ");
        for (const c of channels) if (c[0].test(hay)) return c[1];
        return (n.appName || "SYSTEM").toUpperCase().slice(0, 8);
    }
    // Browsers add the site on its own line: Firefox last ("...\nwww.messenger.com"), Chromium
    // first ("www.messenger.com\n\n..."). Keep only the message.
    function cleanBody(b) {
        const site = /^(https?:\/\/)?[a-z0-9.-]+\.[a-z]{2,}\/?$/i;
        const lines = String(b ?? "").split("\n");
        if (lines.length > 1 && site.test(lines[lines.length - 1].trim())) lines.pop();
        if (lines.length > 1 && site.test(lines[0].trim())) lines.shift();
        return lines.join("\n").trim().slice(0, 600);
    }
    // "Uploaded an image", "sent a photo", "ส่งรูปภาพ"...: the picture itself is never in the
    // notification, so the chat shows a photo bubble that points to the app.
    function isMedia(t) {
        const s = String(t ?? "").trim();
        return /^uploaded\b/i.test(s)                                    // Discord: "Uploaded image.png"
            || /\.(png|jpe?g|gif|webp|heic|mp4|mov|webm)$/i.test(s)          // a bare file name
            || /sent an? (photo|image|picture|attachment|video|gif|sticker)|\bphoto\b$|ส่งรูป|ส่งภาพ|ส่งวิดีโอ|ส่งสติกเกอร์/i.test(s);
    }
    // Photo previews from the app's own local cache (bin/saphie-chat-media): one lookup at a time,
    // retried while the app may still be downloading the picture.
    readonly property var mediaApps: ({ DC: "discord" })
    property var mediaQueue: []          // [{tag, sender, file, tries}]
    function wantMedia(tag, sender, body) {
        if (!mediaApps[tag] || !isMedia(body)) return;
        const file = mediaLabel(body).trim();
        if (!/^[\w .()+,-]{1,200}\.(png|jpe?g|gif|webp)$/i.test(file)) return;
        mediaQueue = mediaQueue.concat([{ tag: tag, sender: sender, file: file, tries: 0 }]);
        if (!mediaProc.running) nextMedia();
    }
    function nextMedia() {
        if (!mediaQueue.length || mediaProc.running) return;
        const j = mediaQueue[0];
        mediaProc.job = j;
        mediaProc.exec([Quickshell.shellDir + "/../../bin/saphie-chat-media", mediaApps[j.tag], j.file]);
    }
    function setMedia(j, path) {
        const img = "file://" + path;
        const fix = msgs => { const m = msgs.slice(); for (let i = m.length - 1; i >= 0; i--) {
                                if (!m[i].mine && !m[i].img && mediaLabel(m[i].t).trim() === j.file) { m[i] = Object.assign({}, m[i], { img: img }); break; } }
                              return m; };
        const ck = convoKey(j.tag, j.sender);
        convos = convos.map(c => c.key === ck ? Object.assign({}, c, { msgs: fix(c.msgs) }) : c);
        threads = threads.map(t => t.tag === j.tag && t.sender === j.sender ? Object.assign({}, t, { msgs: fix(t.msgs) }) : t);
    }
    Process {
        id: mediaProc
        property var job: null
        stdout: StdioCollector { id: mediaOut }
        onExited: code => {
            const j = job; job = null;
            root.mediaQueue = root.mediaQueue.slice(1);
            const path = mediaOut.text.trim();
            if (j && code === 0 && /^\/run\/user\/\d+\/saphie-chat-media\/[0-9a-f]{24}\.png$/.test(path)) root.setMedia(j, path);
            else if (j && j.tries < 4) retryTimer.pending = retryTimer.pending.concat([Object.assign({}, j, { tries: j.tries + 1 })]);
            if (retryTimer.pending.length) retryTimer.restart();
            root.nextMedia();
        }
    }
    Timer {   // retry after 2.5 s (the app may still be downloading the picture)
        id: retryTimer
        property var pending: []
        interval: 2500
        onTriggered: { root.mediaQueue = root.mediaQueue.concat(pending); pending = []; root.nextMedia(); }
    }
    function mediaLabel(t) {   // "Uploaded image.png" -> "IMAGE.PNG"; other phrases stay as they are
        const m = String(t ?? "").trim().match(/^uploaded\s+(.+)$/i);
        return m ? m[1] : String(t ?? "");
    }
    function isCall(n) {
        const cat = String(n.hints?.category ?? "");
        if (/call/i.test(cat)) return true;
        if (acts(n).some(a => /^(accept|answer|pickup|pick-up|รับสาย)/i.test(a.identifier + " " + a.text))) return true;
        return /incoming (voice |video |audio )?call|is calling|calling you|สายเข้า|โทรเข้า/i.test(n.summary + " " + n.body);
    }

    function findAction(n, re) { return acts(n).find(a => re.test(a.identifier + " " + a.text)) ?? null; }
    function update(t, fields) {
        threads = threads.map(x => x === t ? Object.assign({}, x, fields) : x);
    }
    function removeThread(t) { threads = threads.filter(x => x.key !== t.key); }

    // ---- user actions from the cards
    function dismissThread(t) { removeThread(t); try { if (t.n) t.n.dismiss(); } catch (e) {} }   // app may have closed it already
    function open(t) {
        const n = t.n;
        removeThread(t);
        if (!n) return;
        const a = defaultAct(n);
        try { if (a) a.invoke(); else n.dismiss(); } catch (e) {}       // app may have closed it already
    }
    function canReply(t) { return !!(t && ((t.n && t.n.hasInlineReply) || isAssisted(t))); }
    function reply(t, text) {
        const s = String(text ?? "").trim().slice(0, 2000);
        if (!s || !canReply(t)) return false;
        if (isAssisted(t)) { const ok = assistReply(Object.assign({}, t, { key: convoKey(t.tag, t.sender) }), s); if (ok) removeThread(t); return ok; }
        t.n.sendInlineReply(s);
        const cur = threads.find(x => x.key === t.key) ?? t;
        update(cur, { msgs: cur.msgs.concat([{ t: s, mine: true }]).slice(-6), stamp: Date.now() });
        const ck = convoKey(t.tag, t.sender);
        convos = convos.map(x => x.key === ck ? Object.assign({}, x, { msgs: x.msgs.concat([{ t: s, mine: true, call: false, at: Date.now() }]).slice(-60), unread: 0 }) : x);
        Sfx.play("confirm");
        return true;
    }
    function answer(t, accept) {
        const n = t.n;
        removeThread(t);
        if (!n) return;
        const a = accept ? findAction(n, /accept|answer|pick ?up|รับ/i) : findAction(n, /decline|reject|hang ?up|deny|ปฏิเสธ|วาง/i);
        try {
            if (a) a.invoke();
            else if (accept) { const d = acts(n).find(x => x.identifier === "default"); if (d) d.invoke(); }
            else n.dismiss();
        } catch (e) {}
    }

    // ---- history panel helpers (unchanged API)
    function dismiss(n) { threads = threads.filter(t => t.n !== n); appNotes = appNotes.filter(a => a.n !== n); try { n.dismiss(); } catch (e) {} }
    function clearAll() { for (const n of history.slice()) n.dismiss(); threads = []; appNotes = []; unread = 0; }
    function activate(n) {
        const a = defaultAct(n);
        try { if (a) a.invoke(); } catch (e) {}
        dismiss(n);
    }

    // Ring every 2 s while a call card is up (stops when it's answered, declined or the app hangs up).
    Timer { interval: 2000; repeat: true; triggeredOnStart: true; running: root.ringing && !root.dnd; onTriggered: Sfx.play("ring") }

    NotificationServer {
        id: server
        keepOnReload: true
        bodySupported: true
        bodyMarkupSupported: false     // plain text only (trust nothing apps send)
        actionsSupported: true
        imageSupported: true
        inlineReplySupported: true
        persistenceSupported: true
        onNotification: n => {
            n.tracked = true;
            if (n.lastGeneration) return;
            root.unread++;
            // niri's own "screenshot captured" note: the Saphie preview sticker shows it instead.
            if (n.appName === "niri" && /screenshot/i.test(n.summary)) return;
            const call = root.isCall(n);
            if (root.dnd && !call && n.urgency !== NotificationUrgency.Critical) return;

            const tag = root.tagFor(n);
            if (!call && !root.isSocial(n, tag)) {
                // App notification: compact card, top right; not a chat (never in Saphie Chat).
                root.appNotes = [{ id: n.id, n: n, tag: tag, stamp: Date.now() }].concat(root.appNotes.filter(a => a.id !== n.id)).slice(0, 4);
                n.closed.connect(() => root.removeApp(n.id));
                Sfx.play("layout");
                return;
            }
            const sender = String(n.summary || n.appName || "SYSTEM").slice(0, 120);
            const key = (call ? "call|" : "msg|") + tag + "|" + sender;
            const body = root.cleanBody(n.body);
            const old = root.threads.find(t => t.key === key);
            const msgs = (old ? old.msgs : []).concat(body ? [{ t: body, mine: false }] : []).slice(-6);
            const t = { key: key, kind: call ? "call" : "msg", tag: tag, appName: n.appName, sender: sender,
                        image: n.image || (old ? old.image : ""), appIcon: n.appIcon, msgs: msgs, n: n,
                        critical: n.urgency === NotificationUrgency.Critical, stamp: Date.now() };
            if (!(root.chatOpen && !call))           // calls still ring while the chat is open
                root.threads = [t].concat(root.threads.filter(x => x.key !== key)).slice(0, 5);
            root.addToConvo(n, tag, sender, call ? "Incoming call" : body, call);
            if (!call) root.wantMedia(tag, sender, body);
            // A call the app takes back (caller hung up / answered elsewhere) leaves the stack.
            if (call) n.closed.connect(() => { const cur = root.threads.find(x => x.key === key); if (cur && cur.n === n) root.removeThread(cur); });
            if (!call) Sfx.play(root.chatOpen ? "tick" : "notify");
        }
    }
}
