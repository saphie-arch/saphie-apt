import Quickshell
import Quickshell.Wayland
import QtQuick

// Saphie hotkey sheet (Super+Shift+/), ZZZ menu style: sticker cards with slanted keycaps.
// Curated list of the keys that matter; keep in sync with desktop/config/niri/config.kdl binds.
// Esc, Super+Shift+/ again, or any click closes it.
PanelWindow {
    id: win
    required property var modelData
    screen: modelData
    property bool open: false
    visible: open
    color: "transparent"
    anchors { top: true; bottom: true; left: true; right: true }
    exclusionMode: ExclusionMode.Ignore
    WlrLayershell.layer: WlrLayer.Overlay
    WlrLayershell.namespace: "saphie-hotkeys"
    WlrLayershell.keyboardFocus: open ? WlrKeyboardFocus.Exclusive : WlrKeyboardFocus.None
    readonly property bool portrait: height > width

    function show() { if (closing) { closeAnim.stop(); closing = false; } Sfx.play("open"); open = true; openAnim.restart(); keys.forceActiveFocus(); }
    function hide(instant) { if (!open || closing) return; Sfx.play("close"); if (instant) finishClose(); else closeAnim.restart(); }

    // [title, channel, [[keys..., label], ...]]  ("SUPER" is drawn green)
    readonly property var groups: [
        ["ESSENTIALS", "01", [
            [["SUPER", "D"], "App launcher"],
            [["SUPER", "T"], "Terminal"],
            [["SUPER", "S"], "Settings"],
            [["SUPER", "N"], "Chat"],
            [["SUPER", "SHIFT", "S"], "Snip: screenshot / record"],
            [["SUPER", "Q"], "Close window"],
            [["SUPER", "ALT", "L"], "Lock screen"],
            [["SUPER", "SHIFT", "E"], "Power menu"],
            [["CTRL", "SHIFT", "ESC"], "Task manager"],
            [["SUPER", "SHIFT", "/"], "This sheet"]]],
        ["LAYOUTS", "02", [
            [["SUPER", "SPACE"], "Next layout"],
            [["SUPER", "SHIFT", "SPACE"], "Back to scroll"],
            [["SUPER", "W"], "Tabbed column"],
            [["SUPER", "F"], "Maximize column"],
            [["SUPER", "SHIFT", "F"], "Fullscreen"],
            [["SUPER", "V"], "Float / tile"],
            [["SUPER", "R"], "Column width"],
            [["SUPER", "O"], "Overview"]]],
        ["MOVE", "03", [
            [["SUPER", "← →"], "Focus (crosses screens)"],
            [["SUPER", "↑ ↓"], "Focus up / down"],
            [["SUPER", "CTRL", "← →"], "Move window"],
            [["SUPER", "SHIFT", "← →"], "Focus other screen"],
            [["SUPER", "1-9"], "Go to workspace"],
            [["SUPER", "CTRL", "1-9"], "Send to workspace"],
            [["SUPER", "- ="], "Narrower / wider"]]],
        ["CAPTURE + MEDIA", "04", [
            [["PRINT"], "Screenshot area"],
            [["CTRL", "PRINT"], "Whole screen"],
            [["ALT", "PRINT"], "One window"],
            [["FN", "F5 F6"], "Brightness"],
            [["FN", "VOL"], "Volume / mute"],
            [["SHIFT", "ENTER"], "Launcher: run on NVIDIA"],
            [["SUPER", "ESC"], "Let app grab keys"]]]
    ]

    Item {
        id: screenRoot
        anchors.fill: parent
        transform: Scale { id: tvScale; origin.x: screenRoot.width / 2; origin.y: screenRoot.height / 2; yScale: 1 }
        Rectangle { anchors.fill: parent; color: "#000000"; opacity: 0.97 }
        Canvas { anchors.fill: parent; opacity: 0.05
                 onPaint: { const c = getContext("2d"); c.fillStyle = "#ffffff"; for (let y = 0; y < height; y += 3) c.fillRect(0, y, width, 1); } }
        MouseArea { anchors.fill: parent; onClicked: win.hide() }
        Item {
            id: keys
            focus: true
            Keys.onPressed: ev => {
                if (ev.key === Qt.Key_Escape || ev.key === Qt.Key_Question || ev.key === Qt.Key_Slash) { win.hide(); ev.accepted = true; }
            }
        }

        // ---- header: green tab + big title
        Item {
            id: header
            x: win.portrait ? 40 : 72; y: win.portrait ? 60 : 64
            width: parent.width - 2 * x; height: 92
            Rectangle {
                width: 170; height: 30
                color: Theme.accentA; border.color: Theme.bg; border.width: 2
                transform: Matrix4x4 { matrix: Qt.matrix4x4(1, Theme.skew, 0, -Theme.skew * 15, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1) }
                Text { anchors.centerIn: parent; text: "CH 00 · HOTKEYS"; color: Theme.onAccent
                       font.family: Theme.labelFont; font.pixelSize: 12; font.weight: Font.ExtraBold; font.letterSpacing: 1.6 }
            }
            Text { y: 36; text: "CONTROLS"; color: Theme.text; font.family: Theme.titleFont; font.pixelSize: win.portrait ? 44 : 56 }
            Text { anchors.right: parent.right; anchors.bottom: parent.bottom; anchors.bottomMargin: 8
                   visible: !win.portrait
                   text: "ESC CLOSE"; color: Theme.textDim
                   font.family: Theme.labelFont; font.pixelSize: 11; font.weight: Font.ExtraBold; font.letterSpacing: 1.4 }
        }

        // ---- cards: 4 columns on landscape, 2 on portrait
        Grid {
            id: grid
            x: header.x; y: header.y + header.height + (win.portrait ? 24 : 32)
            columns: win.portrait ? 1 : 4
            spacing: win.portrait ? 18 : 24
            readonly property real cardW: win.portrait ? win.width - 2 * header.x
                                                       : (win.width - 2 * header.x - 3 * spacing) / 4
            Repeater {
                model: win.groups
                Item {
                    id: card
                    required property var modelData
                    required property int index
                    width: grid.cardW
                    height: 64 + modelData[2].length * (win.portrait ? 34 : 40)
                    opacity: 0
                    transform: Translate { id: cT; y: 30 }
                    Connections { target: openAnim; function onStarted() { cIn.restart(); } }
                    SequentialAnimation { id: cIn
                        ScriptAction { script: { cT.y = 30; card.opacity = 0; } }
                        PauseAnimation { duration: 120 + card.index * 70 }
                        ParallelAnimation {
                            NumberAnimation { target: cT; property: "y"; to: 0; duration: 300; easing.type: Easing.OutBack; easing.overshoot: 1.8 }
                            NumberAnimation { target: card; property: "opacity"; to: 1; duration: 120 } } }

                    Rectangle { x: Theme.shadow + 2; y: Theme.shadow + 2; width: parent.width; height: parent.height; color: Theme.accentB; opacity: 0.35
                                topLeftRadius: Theme.corner; topRightRadius: Theme.corner; bottomLeftRadius: Theme.corner }
                    Rectangle {
                        anchors.fill: parent
                        color: Theme.surface; border.color: Theme.bg; border.width: 2
                        topLeftRadius: Theme.corner; topRightRadius: Theme.corner; bottomLeftRadius: Theme.corner; bottomRightRadius: 0
                        Rectangle { anchors.fill: parent; anchors.margins: 2; color: "transparent"; border.color: Theme.ring; border.width: 3
                                    topLeftRadius: Theme.corner - 2; topRightRadius: Theme.corner - 2; bottomLeftRadius: Theme.corner - 2 }
                    }
                    // channel number + title
                    Text { x: 18; y: 8; text: card.modelData[1]; color: Theme.accentA
                           font.family: Theme.numeralFont; font.italic: true; font.weight: Font.ExtraBold; font.pixelSize: 34 }
                    Text { x: 62; y: 18; text: card.modelData[0]; color: Theme.text
                           font.family: Theme.titleFont; font.pixelSize: 17 }
                    Rectangle { x: 18; y: 52; width: parent.width - 36; height: 2; color: Theme.ring }

                    Column {
                        x: 18; y: 62; width: parent.width - 36
                        spacing: 0
                        Repeater {
                            model: card.modelData[2]
                            Item {
                                id: row
                                required property var modelData
                                width: parent.width; height: win.portrait ? 34 : 40
                                Row {
                                    id: caps
                                    anchors.verticalCenter: parent.verticalCenter
                                    spacing: 5
                                    Repeater {
                                        model: row.modelData[0]
                                        Item {
                                            id: cap
                                            required property string modelData
                                            readonly property bool sup: modelData === "SUPER"
                                            width: capText.implicitWidth + 18; height: 24
                                            Rectangle { x: 3; y: 3; width: parent.width; height: parent.height; color: Theme.bg
                                                        transform: Matrix4x4 { matrix: Qt.matrix4x4(1, Theme.skew, 0, -Theme.skew * 12, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1) } }
                                            Rectangle {
                                                anchors.fill: parent
                                                color: cap.sup ? Theme.accentA : "#262626"
                                                border.color: cap.sup ? Theme.bg : Theme.raised; border.width: 2
                                                transform: Matrix4x4 { matrix: Qt.matrix4x4(1, Theme.skew, 0, -Theme.skew * 12, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1) }
                                            }
                                            Text { id: capText; anchors.centerIn: parent; text: cap.modelData
                                                   color: cap.sup ? Theme.onAccent : Theme.text
                                                   font.family: Theme.labelFont; font.pixelSize: 11; font.weight: Font.ExtraBold; font.letterSpacing: 0.8 }
                                        }
                                    }
                                }
                                Text {
                                    anchors.right: parent.right; anchors.verticalCenter: parent.verticalCenter
                                    width: parent.width - caps.width - 12; horizontalAlignment: Text.AlignRight; elide: Text.ElideRight
                                    text: row.modelData[1]; color: Theme.textDim
                                    font.family: Theme.labelFont; font.pixelSize: 12; font.weight: Font.Bold
                                }
                            }
                        }
                    }
                }
            }
        }

        Rectangle { id: wiper; visible: (openAnim.running || closeAnim.running) && Theme.openStyle === "wipe"
                    width: parent.width * 1.6; height: parent.height * 2; color: Theme.accentA; rotation: 20; x: -width; y: -parent.height * 0.5 }
    }
    Rectangle { id: tvLine; y: win.height / 2 - 2; width: win.width; height: 4; color: "#ffffff"; opacity: 0 }
    SequentialAnimation {
        id: openAnim
        ScriptAction { script: {
            const tv = Theme.openStyle === "tv";
            wiper.x = -wiper.width * 0.2; tvScale.yScale = tv ? 0.004 : 1; tvLine.opacity = tv ? 1 : 0;
        } }
        PauseAnimation { duration: 70 }
        ParallelAnimation {
            NumberAnimation { target: wiper; property: "x"; to: win.width + win.height; duration: 380; easing.type: Easing.OutCubic }
            NumberAnimation { target: tvScale; property: "yScale"; to: 1; duration: 340; easing.type: Easing.OutBack; easing.overshoot: 1.3 }
            NumberAnimation { target: tvLine; property: "opacity"; to: 0; duration: 220 }
        }
    }

    // Close animation (reverse of the open): wipe style = green panel sweeps back over the
    // screen; tv style = screen collapses into a white line (TV switch-off). Then the window goes.
    property bool closing: false
    function finishClose() {
        closeAnim.stop(); closing = false; open = false;
        wiper.x = -wiper.width; tvScale.yScale = 1; tvLine.opacity = 0;
    }
    SequentialAnimation {
        id: closeAnim
        ScriptAction { script: { win.closing = true; wiper.x = win.width + win.height; } }
        ParallelAnimation {
            NumberAnimation { target: wiper; property: "x"; to: -wiper.width * 0.2; duration: 240; easing.type: Easing.InCubic }
            NumberAnimation { target: tvScale; property: "yScale"; to: Theme.openStyle === "tv" ? 0.004 : 1; duration: 200; easing.type: Easing.InBack }
            NumberAnimation { target: tvLine; property: "opacity"; to: Theme.openStyle === "tv" ? 1 : 0; duration: 160 }
        }
        PauseAnimation { duration: 40 }
        ScriptAction { script: win.finishClose() }
    }
}
