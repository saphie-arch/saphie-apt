import Quickshell
import Quickshell.Wayland
import QtQuick

// Saphie snip bar (Super+Shift+S), like the Windows Snipping Tool bar: SCREENSHOT or RECORD,
// AREA / WINDOW / SCREEN, and for recordings SYSTEM SOUND / MIC switches. Enter or GO starts,
// Esc closes. Screenshots use niri's own tools; recordings bin/saphie-record (REC on the bar stops).
PanelWindow {
    id: win
    required property var modelData
    screen: modelData
    property bool open: false
    visible: open
    color: "transparent"
    anchors { top: true; left: true; right: true }
    implicitHeight: 150
    exclusionMode: ExclusionMode.Ignore
    WlrLayershell.layer: WlrLayer.Overlay
    WlrLayershell.namespace: "saphie-snip"
    WlrLayershell.keyboardFocus: open ? WlrKeyboardFocus.Exclusive : WlrKeyboardFocus.None

    property string mode: "shot"         // shot | rec
    property string target: "area"       // area | window | screen
    property bool sys: true
    property bool mic: false
    readonly property var targets: ["area", "window", "screen"]

    function show() { Sfx.play("open"); open = true; inAnim.restart(); keys.forceActiveFocus(); }
    function hide() { if (open) { Sfx.play("close"); open = false; } }
    function go() {
        Sfx.play("confirm");
        open = false;                    // gone before the capture starts
        const m = mode, t = target, s = sys, mi = mic;
        goTimer.job = () => {
            if (m === "shot") {
                const act = { area: "screenshot", window: "screenshot-window", screen: "screenshot-screen" }[t];
                Quickshell.execDetached(["niri", "msg", "action", act]);
            } else {
                const args = [Quickshell.shellDir + "/../../bin/saphie-record", "start", t];
                if (s) args.push("--system");
                if (mi) args.push("--mic");
                Quickshell.execDetached(args);
            }
        };
        goTimer.restart();
    }
    Timer { id: goTimer; property var job: null; interval: 260; onTriggered: if (job) job() }

    component Chip: Item {
        id: c
        property string label
        property bool on: false
        property bool small: false
        signal hit()
        width: ct.implicitWidth + (small ? 22 : 30); height: small ? 26 : 32
        Rectangle { x: 3; y: 3; width: parent.width; height: parent.height; color: Theme.bg
                    transform: Matrix4x4 { matrix: Qt.matrix4x4(1, Theme.skew, 0, -Theme.skew * c.height / 2, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1) } }
        Rectangle {
            anchors.fill: parent
            color: c.on ? Theme.accentA : (cm.containsMouse ? "#2a2a2a" : "#1c1c1c")
            border.color: c.on ? Theme.bg : Theme.ring; border.width: 2
            transform: Matrix4x4 { matrix: Qt.matrix4x4(1, Theme.skew, 0, -Theme.skew * c.height / 2, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1) }
        }
        Text { id: ct; anchors.centerIn: parent; text: c.label; color: c.on ? Theme.onAccent : Theme.text
               font.family: Theme.labelFont; font.pixelSize: c.small ? 10 : 12; font.weight: Font.ExtraBold; font.letterSpacing: 1 }
        MouseArea { id: cm; anchors.fill: parent; hoverEnabled: true; onClicked: { Sfx.play("tick"); c.hit(); } }
    }

    MouseArea { anchors.fill: parent; onClicked: win.hide() }   // click outside the strip closes

    Item {
        id: keys
        focus: true
        Keys.onPressed: ev => {
            if (ev.key === Qt.Key_Escape) win.hide();
            else if (ev.key === Qt.Key_Return || ev.key === Qt.Key_Enter) win.go();
            else if (ev.key === Qt.Key_Tab) { Sfx.play("tick"); win.target = win.targets[(win.targets.indexOf(win.target) + 1) % 3]; }
            else if (ev.key === Qt.Key_Left || ev.key === Qt.Key_Right) { Sfx.play("tick"); win.mode = win.mode === "shot" ? "rec" : "shot"; }
            else return;
            ev.accepted = true;
        }
    }

    Item {
        id: strip
        width: row.implicitWidth + 48; height: 64
        x: (win.width - width) / 2; y: 46
        transform: Translate { id: dropT; y: 0 }
        MouseArea { anchors.fill: parent }
        Rectangle { x: 6; y: 6; width: parent.width; height: parent.height; color: Theme.bg }
        Rectangle {
            anchors.fill: parent; color: Theme.surface; border.color: Theme.bg; border.width: 2
            topLeftRadius: Theme.corner; topRightRadius: Theme.corner; bottomLeftRadius: Theme.corner; bottomRightRadius: 0
            Rectangle { anchors.fill: parent; anchors.margins: 2; color: "transparent"
                        border.color: win.mode === "rec" ? Theme.danger : Theme.ring; border.width: 3
                        topLeftRadius: Theme.corner - 2; topRightRadius: Theme.corner - 2; bottomLeftRadius: Theme.corner - 2 }
        }
        Rectangle {   // tab
            x: 18; y: -12; width: tabT.implicitWidth + 26; height: 24
            color: win.mode === "rec" ? Theme.danger : Theme.accentA; border.color: Theme.bg; border.width: 2
            transform: Matrix4x4 { matrix: Qt.matrix4x4(1, Theme.skew, 0, -Theme.skew * 12, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1) }
            Text { id: tabT; anchors.centerIn: parent; text: win.mode === "rec" ? "● SNIP · RECORD" : "SNIP · SCREENSHOT"
                   color: win.mode === "rec" ? "#ffffff" : Theme.onAccent
                   font.family: Theme.labelFont; font.pixelSize: 10; font.weight: Font.ExtraBold; font.letterSpacing: 1.4 }
        }
        Row {
            id: row
            x: 24; anchors.verticalCenter: parent.verticalCenter; anchors.verticalCenterOffset: 2
            spacing: 8
            Chip { label: "📷 SHOT"; on: win.mode === "shot"; onHit: win.mode = "shot" }
            Chip { label: "● RECORD"; on: win.mode === "rec"; onHit: win.mode = "rec" }
            Rectangle { width: 2; height: 30; color: Theme.ring; anchors.verticalCenter: parent.verticalCenter }
            Chip { label: "AREA"; on: win.target === "area"; onHit: win.target = "area" }
            Chip { label: "WINDOW"; on: win.target === "window"; onHit: win.target = "window" }
            Chip { label: "SCREEN"; on: win.target === "screen"; onHit: win.target = "screen" }
            Rectangle { visible: win.mode === "rec"; width: 2; height: 30; color: Theme.ring; anchors.verticalCenter: parent.verticalCenter }
            Chip { visible: win.mode === "rec"; small: true; label: (win.sys ? "♪ " : "") + "SYSTEM SOUND"; on: win.sys; onHit: win.sys = !win.sys
                   anchors.verticalCenter: parent.verticalCenter }
            Chip { visible: win.mode === "rec"; small: true; label: "MIC"; on: win.mic; onHit: win.mic = !win.mic
                   anchors.verticalCenter: parent.verticalCenter }
            Rectangle { width: 2; height: 30; color: Theme.ring; anchors.verticalCenter: parent.verticalCenter }
            Rectangle {   // GO
                width: 44; height: 44; radius: 22; anchors.verticalCenter: parent.verticalCenter
                color: win.mode === "rec" ? Theme.danger : Theme.accentA; border.color: Theme.bg; border.width: 2
                scale: gm.pressed ? 0.9 : (gm.containsMouse ? 1.06 : 1)
                Behavior on scale { NumberAnimation { duration: 120; easing.type: Easing.OutBack } }
                Text { anchors.centerIn: parent; text: win.mode === "rec" ? "●" : "▶"; color: win.mode === "rec" ? "#ffffff" : Theme.onAccent
                       font.pixelSize: 18; font.weight: Font.Black }
                MouseArea { id: gm; anchors.fill: parent; hoverEnabled: true; onClicked: win.go() }
            }
        }
        Rectangle {   // key hints on their own dark plate (readable over any window)
            anchors.top: parent.bottom; anchors.topMargin: 12; anchors.horizontalCenter: parent.horizontalCenter
            width: hint.implicitWidth + 24; height: 22; color: Theme.bg; border.color: Theme.ring; border.width: 1
            Text { id: hint; anchors.centerIn: parent
                   text: "← → SHOT / RECORD    TAB AREA · WINDOW · SCREEN    ENTER GO    ESC CLOSE"
                   color: Theme.textDim; font.family: Theme.labelFont; font.pixelSize: 10; font.weight: Font.ExtraBold; font.letterSpacing: 1 }
        }
    }
    NumberAnimation { id: inAnim; target: dropT; property: "y"; from: -90; to: 0; duration: 320; easing.type: Easing.OutBack; easing.overshoot: 1.5 }
}
