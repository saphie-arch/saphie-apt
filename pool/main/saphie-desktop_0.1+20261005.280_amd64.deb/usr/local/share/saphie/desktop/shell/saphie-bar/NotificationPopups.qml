import Quickshell
import Quickshell.Wayland
import Quickshell.Widgets
import Quickshell.Services.Notifications
import QtQuick

// Message stack, bottom-right of the focused monitor (ZZZ phone-chat style, Notifs.qml threads):
//   message card: round avatar (the picture the app sends, else an initial), sender, channel tag,
//                 the last messages as bubbles (theirs left, yours right in green), reply box
//                 when the app supports inline reply, else OPEN CHAT
//   call card:    red ring + accent, caller, timer, decline (red) / accept (green)
// The window is only as tall as the stack, so clicks elsewhere go to the apps below.
PanelWindow {
    id: win
    required property var modelData
    screen: modelData
    readonly property bool active: {
        const ws = Niri.workspaces.find(w => w.is_focused);
        return ws ? ws.output === modelData.name : modelData === Quickshell.screens[0];
    }
    visible: active && Notifs.threads.length > 0
    // The window reaches the screen edge and keeps the 14 px gap inside, with room around the
    // cards: sliding in from the edge and the new-message bump are never cut off.
    anchors { bottom: true; right: true }
    readonly property int pad: 18
    implicitWidth: 392 + 14 + pad
    implicitHeight: Math.max(1, stack.implicitHeight + 14 + 2 * pad)
    exclusionMode: ExclusionMode.Ignore
    color: "transparent"
    WlrLayershell.layer: WlrLayer.Overlay
    WlrLayershell.namespace: "saphie-notifications"
    // reply box takes keys only when clicked; none at all while an assisted reply is being typed
    WlrLayershell.keyboardFocus: Notifs.assistPending ? WlrKeyboardFocus.None : WlrKeyboardFocus.OnDemand

    component Avatar: Item {
        id: av
        property string image
        property string appIcon
        property string name
        property color ring: Theme.accentA
        width: 44; height: 44
        Rectangle { anchors.fill: parent; radius: width / 2; color: Theme.bg; border.color: av.ring; border.width: 2 }
        ClippingRectangle {
            anchors.fill: parent; anchors.margins: 3; radius: width / 2
            color: pic.status === Image.Ready ? "transparent" : Theme.accentA
            Image {
                id: pic
                anchors.fill: parent
                source: av.image || (av.appIcon ? Quickshell.iconPath(av.appIcon, true) : "")
                sourceSize.width: 96; sourceSize.height: 96
                fillMode: Image.PreserveAspectCrop          // fill the circle, don't shrink to a strip
                asynchronous: true
                visible: status === Image.Ready
            }
            Text {
                anchors.centerIn: parent; visible: pic.status !== Image.Ready
                text: (av.name || "?").trim().charAt(0).toUpperCase()
                color: Theme.onAccent; font.family: Theme.fontFor(text, Theme.numeralFont)
                font.weight: Font.ExtraBold; font.italic: true; font.pixelSize: 20
            }
        }
    }
    component Tag: Rectangle {
        property string text
        property bool hot: false
        width: tagText.implicitWidth + 14; height: 18
        color: hot ? Theme.accentA : "transparent"; border.color: hot ? Theme.bg : Theme.raised; border.width: 1
        transform: Matrix4x4 { matrix: Qt.matrix4x4(1, Theme.skew, 0, -Theme.skew * 9, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1) }
        Text { id: tagText; anchors.centerIn: parent; text: parent.text; color: parent.hot ? Theme.onAccent : Theme.textDim
               font.family: Theme.labelFont; font.pixelSize: 10; font.weight: Font.ExtraBold; font.letterSpacing: 1 }
    }
    component RoundBtn: Rectangle {
        id: rb
        property color fill
        property string glyph
        signal hit()
        width: 40; height: 40; radius: 20
        color: rbm.containsMouse ? Qt.lighter(fill, 1.25) : fill
        border.color: Theme.bg; border.width: 2
        scale: rbm.pressed ? 0.9 : 1
        Behavior on scale { NumberAnimation { duration: 120; easing.type: Easing.OutBack } }
        Text { anchors.centerIn: parent; text: rb.glyph; color: rb.fill === Theme.accentA ? Theme.onAccent : "#ffffff"
               font.pixelSize: 17; font.weight: Font.Black }
        MouseArea { id: rbm; anchors.fill: parent; hoverEnabled: true; onClicked: rb.hit() }
    }

    Column {
        id: stack
        anchors.bottom: parent.bottom; anchors.bottomMargin: 14 + 6
        x: win.pad
        width: 392 - 10
        spacing: 12
        Repeater {
            model: Notifs.threads
            Item {
                id: card
                required property var modelData
                required property int index
                readonly property var th: modelData
                readonly property bool call: th.kind === "call"
                readonly property bool replyable: Notifs.canReply(th)
                width: stack.width
                height: body.implicitHeight + 26
                transform: Translate { id: slide; x: 460 }      // starts past the screen edge
                Component.onCompleted: inAnim.start()
                // New message in an existing thread: flash + small bump.
                property real lastStamp: th.stamp
                onThChanged: if (th.stamp !== lastStamp) { lastStamp = th.stamp; bump.restart(); hideTimer.restart(); }

                Timer {   // messages leave after 9 s unless hovered or typing; calls ring up to 45 s
                    id: hideTimer
                    running: !hover.containsMouse && !replyIn.activeFocus
                    interval: card.call ? 45000 : 9000
                    onTriggered: Notifs.removeThread(card.th)
                }
                SequentialAnimation {
                    id: inAnim
                    NumberAnimation { target: slide; property: "x"; to: 0; duration: 320; easing.type: Easing.OutBack; easing.overshoot: 1.5 }
                    SequentialAnimation { loops: 2
                        NumberAnimation { target: flash; property: "opacity"; to: 0.7; duration: 40 }
                        NumberAnimation { target: flash; property: "opacity"; to: 0; duration: 40 } }
                }
                SequentialAnimation {
                    id: bump
                    NumberAnimation { target: card; property: "scale"; to: 1.03; duration: 90; easing.type: Easing.OutQuad }
                    NumberAnimation { target: card; property: "scale"; to: 1; duration: 220; easing.type: Easing.OutBack; easing.overshoot: 2 }
                }

                Rectangle { x: 6; y: 6; width: parent.width; height: parent.height; color: Theme.bg }   // hard shadow
                Rectangle {
                    anchors.fill: parent
                    color: Theme.surface; border.color: Theme.bg; border.width: 2
                    topLeftRadius: Theme.corner; topRightRadius: Theme.corner; bottomLeftRadius: Theme.corner; bottomRightRadius: 0
                    Rectangle { anchors.fill: parent; anchors.margins: 2; color: "transparent"
                                border.color: card.call ? Theme.danger : Theme.ring; border.width: 3
                                topLeftRadius: Theme.corner - 2; topRightRadius: Theme.corner - 2; bottomLeftRadius: Theme.corner - 2 }
                }
                Rectangle { anchors.top: parent.top; anchors.bottom: parent.bottom; anchors.margins: 12; x: 9; width: 4
                            color: card.call ? Theme.danger : Theme.accentA }
                MouseArea {   // hover pauses auto-hide; a click on the card opens the chat in Saphie Chat
                    id: hover; anchors.fill: parent; hoverEnabled: true
                    onClicked: if (!card.call) { Sfx.play("open"); Notifs.openChat(Notifs.convoKey(card.th.tag, card.th.sender)); Notifs.removeThread(card.th); }
                }

                Column {
                    id: body
                    x: 22; y: 13; width: parent.width - 40
                    spacing: 10

                    // ---- header: avatar, sender, app line, tag, close
                    Item {
                        width: parent.width; height: 46
                        Avatar { id: ava; anchors.verticalCenter: parent.verticalCenter
                                 image: card.th.image; appIcon: card.th.appIcon; name: card.th.sender
                                 ring: card.call ? Theme.danger : Theme.accentA }
                        Column {
                            x: ava.width + 12; anchors.verticalCenter: parent.verticalCenter
                            width: parent.width - x - (card.call ? 104 : 70)
                            spacing: 1
                            Text {
                                text: card.call ? Notifs.serviceName(card.th) + "  ·  INCOMING CALL"
                                      : Notifs.serviceName(card.th) + (card.th.msgs.filter(m => !m.mine).length > 1 ? "  ·  " + card.th.msgs.filter(m => !m.mine).length + " NEW" : "")
                                color: card.call ? Theme.danger : Theme.accentA
                                font.family: Theme.labelFont; font.pixelSize: 10; font.weight: Font.ExtraBold; font.letterSpacing: 1
                                elide: Text.ElideRight; width: parent.width
                            }
                            Text {
                                width: parent.width; elide: Text.ElideRight
                                text: card.th.sender; textFormat: Text.PlainText; color: Theme.text
                                font.family: Theme.fontFor(text, Theme.numeralFont); font.weight: Font.ExtraBold
                                font.italic: !Theme.nonLatin(text); font.pixelSize: Theme.nonLatin(text) ? 17 : 22
                            }
                            Text {
                                visible: card.call
                                property int secs: 0
                                Timer { running: card.call; interval: 1000; repeat: true; onTriggered: parent.secs++ }
                                text: "RINGING  " + Math.floor(secs / 60) + ":" + String(secs % 60).padStart(2, "0")
                                color: Theme.textDim; font.family: Theme.labelFont; font.pixelSize: 10; font.weight: Font.Bold
                            }
                        }
                        Row {   // call buttons
                            visible: card.call
                            anchors.right: parent.right; anchors.verticalCenter: parent.verticalCenter
                            spacing: 10
                            RoundBtn { fill: Theme.danger; glyph: "✕"; onHit: { Sfx.play("back"); Notifs.answer(card.th, false); } }
                            RoundBtn { fill: Theme.accentA; glyph: "✓"; onHit: { Sfx.play("confirm"); Notifs.answer(card.th, true); } }
                        }
                        Tag { visible: !card.call; anchors.right: parent.right; anchors.rightMargin: 24; y: 4; text: card.th.tag; hot: true }
                        Text {
                            visible: !card.call
                            anchors.right: parent.right; y: 2
                            text: "✕"; color: closeM.containsMouse ? Theme.accentA : Theme.textDim
                            font.pixelSize: 13; font.weight: Font.Black
                            MouseArea { id: closeM; anchors.fill: parent; anchors.margins: -6; hoverEnabled: true
                                        onClicked: Notifs.dismissThread(card.th) }
                        }
                    }

                    // ---- bubbles: theirs left (dark), yours right (green); last 4
                    Column {
                        visible: !card.call && card.th.msgs.length > 0
                        width: parent.width; spacing: 5
                        Repeater {
                            model: card.th.msgs.slice(-4)
                            Item {
                                required property var modelData
                                width: parent.width; height: bubble.height
                                Rectangle {
                                    id: bubble
                                    x: modelData.mine ? parent.width - width : 0
                                    readonly property bool hasImg: !!modelData.img && cpic.status !== Image.Error
                                    width: hasImg ? cpic.width + 12 : Math.min(parent.width * 0.82, msgText.implicitWidth + 20)
                                    height: hasImg ? cpic.height + 12 : msgText.implicitHeight + 12
                                    color: modelData.mine ? Theme.accentA : "#262626"
                                    Image {
                                        id: cpic
                                        visible: bubble.hasImg; x: 6; y: 6
                                        source: modelData.img || ""; asynchronous: true; fillMode: Image.PreserveAspectFit
                                        sourceSize.width: 400; width: 200
                                        height: status === Image.Ready && implicitWidth > 0 ? Math.min(260, width * implicitHeight / implicitWidth) : 120
                                    }
                                    topLeftRadius: 12; topRightRadius: 12
                                    bottomLeftRadius: modelData.mine ? 12 : 2; bottomRightRadius: modelData.mine ? 2 : 12
                                    Text {
                                        id: msgText
                                        visible: !bubble.hasImg
                                        x: 10; y: 6; width: Math.min(implicitWidth, parent.parent.width * 0.82 - 20)
                                        text: !modelData.mine && Notifs.isMedia(modelData.t) ? "📷  " + Notifs.mediaLabel(modelData.t) : modelData.t; textFormat: Text.PlainText
                                        wrapMode: Text.Wrap; maximumLineCount: 4; elide: Text.ElideRight
                                        color: modelData.mine ? Theme.onAccent : "#eeeeee"
                                        font.family: Theme.fontFor(text, Theme.labelFont); font.pixelSize: 13
                                    }
                                }
                            }
                        }
                    }

                    // ---- reply (inline reply apps) or OPEN CHAT (browser chats, everything else)
                    Item {
                        visible: !card.call
                        width: parent.width; height: 34
                        Rectangle {
                            visible: card.replyable
                            width: parent.width - 60; height: 32
                            color: "#101010"; border.color: replyIn.activeFocus ? Theme.accentA : Theme.ring; border.width: 2
                            transform: Matrix4x4 { matrix: Qt.matrix4x4(1, Theme.skew * 0.5, 0, -Theme.skew * 8, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1) }
                            TextInput {
                                id: replyIn
                                x: 12; width: parent.width - 24; anchors.verticalCenter: parent.verticalCenter
                                color: Theme.text; font.family: Theme.fontFor(text, Theme.labelFont); font.pixelSize: 13
                                maximumLength: 2000; clip: true
                                Keys.onReturnPressed: { if (Notifs.reply(card.th, text)) text = ""; }
                                Keys.onEnterPressed: { if (Notifs.reply(card.th, text)) text = ""; }
                                Keys.onEscapePressed: { text = ""; focus = false; }
                            }
                            Text { x: 12; anchors.verticalCenter: parent.verticalCenter; visible: replyIn.text.length === 0
                                   text: card.th.n && card.th.n.inlineReplyPlaceholder && !/^reply$/i.test(card.th.n.inlineReplyPlaceholder)
                                         ? card.th.n.inlineReplyPlaceholder : "Reply to " + card.th.sender + "…"
                                   color: Theme.raised; font.family: Theme.fontFor(text, Theme.labelFont); font.pixelSize: 12
                                   elide: Text.ElideRight; width: parent.width - 24 }
                            MouseArea { anchors.fill: parent; cursorShape: Qt.IBeamCursor; onClicked: replyIn.forceActiveFocus() }
                        }
                        Text { visible: card.replyable; anchors.right: parent.right; anchors.verticalCenter: parent.verticalCenter
                               text: "ENTER ↵"; color: replyIn.activeFocus ? Theme.accentA : Theme.raised
                               font.family: Theme.labelFont; font.pixelSize: 10; font.weight: Font.ExtraBold }
                        Rectangle {   // OPEN CHAT
                            visible: !card.replyable
                            width: openText.implicitWidth + 34; height: 30
                            color: om.containsMouse ? Theme.accentA : Theme.text; border.color: Theme.bg; border.width: 2
                            transform: Matrix4x4 { matrix: Qt.matrix4x4(1, Theme.skew, 0, -Theme.skew * 15, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1) }
                            Text { id: openText; anchors.centerIn: parent; text: "OPEN CHAT  ▸"; color: Theme.onAccent
                                   font.family: Theme.labelFont; font.pixelSize: 11; font.weight: Font.ExtraBold; font.letterSpacing: 1 }
                            MouseArea { id: om; anchors.fill: parent; hoverEnabled: true; onClicked: { Sfx.play("confirm"); Notifs.open(card.th); } }
                        }
                        Text { visible: !card.replyable; anchors.right: parent.right; anchors.verticalCenter: parent.verticalCenter
                               text: "REPLY IN APP"
                               color: Theme.raised; font.family: Theme.labelFont; font.pixelSize: 10; font.weight: Font.ExtraBold }
                    }
                }
                Rectangle { id: flash; anchors.fill: parent; color: "#ffffff"; opacity: 0 }
            }
        }
    }
}
