import Quickshell
import Quickshell.Io
import Quickshell.Services.Pipewire
import Quickshell.Wayland
import QtQuick
import QtQuick.Layouts

// One bar per monitor, every sticker on every screen. Portrait screens get the compact sizes. When
// the stickers don't fit (narrow / portrait screen) the bar slides sideways: drag it, or use the
// mouse wheel over it (except where a sticker uses the wheel, e.g. volume); "‹ ›" show there's more.
PanelWindow {
    id: bar
    required property var modelData
    screen: modelData
    readonly property bool slim: modelData.height > modelData.width
    readonly property int stickerHeight: slim ? 30 : 36
    // The bar never takes the keyboard, except while a Wi-Fi password is being typed: its popups
    // can only get keys if the bar itself may (layer-shell). Escape / connecting gives it back.
    WlrLayershell.keyboardFocus: wifiPanel.visible && wifiPanel.pwFor ? WlrKeyboardFocus.Exclusive : WlrKeyboardFocus.None
    // Default mic, for the MIC OFF sticker (the mic-mute key is easy to hit without noticing).
    readonly property var micSource: Pipewire.defaultAudioSource
    readonly property bool micMuted: !!micSource?.audio?.muted
    PwObjectTracker { objects: bar.micSource ? [bar.micSource] : [] }

    anchors { top: true; left: true; right: true }
    implicitHeight: stickerHeight + 8 + Theme.shadow + 2
    exclusiveZone: implicitHeight - 4
    color: "transparent"   // stickers float on the desktop; their shadows need a visible background

    // Fullscreen window on this screen (Super+Shift+F): the stickers slide up out of view and
    // drop back in with a small overshoot when fullscreen ends.
    readonly property bool fsHidden: Niri.fullscreenOn(modelData.name, modelData.width, modelData.height)

    Flickable {
        id: scroller
        transform: Translate {
            y: bar.fsHidden ? -(bar.implicitHeight + 16) : 0
            Behavior on y { NumberAnimation { duration: bar.fsHidden ? 200 : 340
                                              easing.type: bar.fsHidden ? Easing.InBack : Easing.OutBack; easing.overshoot: 1.6 } }
        }
        anchors { left: parent.left; right: parent.right; top: parent.top }
        height: bar.implicitHeight
        readonly property real need: row.implicitWidth + 16 + Theme.shadow
        readonly property bool overflow: need > width + 1
        contentWidth: Math.max(width, need)
        contentHeight: height
        flickableDirection: Flickable.HorizontalFlick
        boundsBehavior: Flickable.StopAtBounds
        interactive: overflow
        clip: overflow
        Behavior on contentX { enabled: !scroller.moving; NumberAnimation { duration: 180; easing.type: Easing.OutCubic } }
        function slide(px) { contentX = Math.max(0, Math.min(contentWidth - width, contentX + px)); }
        WheelHandler {   // wheel over the bar (not over a sticker that uses it) slides it
            enabled: scroller.overflow
            onWheel: ev => scroller.slide(-(ev.angleDelta.y || ev.angleDelta.x) / 120 * 160)
        }

    RowLayout {
        id: row
        x: 8; y: 8
        width: scroller.contentWidth - 16 - Theme.shadow
        height: bar.stickerHeight
        spacing: Theme.gap

        Sticker {
            order: 0
            sharp: "tl"
            Layout.fillHeight: true
            Layout.preferredWidth: implicitWidth
            Row {
                spacing: 10
                Image {   // Saphie OS mark (desktop/brand/logo), also on the slim portrait bar
                    anchors.verticalCenter: parent.verticalCenter
                    width: 20; height: 20
                    source: "file://" + Quickshell.shellDir + "/../../brand/logo/saphie-48.png"
                    sourceSize.width: 40; sourceSize.height: 40
                    smooth: true; mipmap: true
                }
                Text {
                    visible: !bar.slim   // compact: the logo is enough
                    anchors.verticalCenter: parent.verticalCenter
                    text: "SAPHIE"
                    color: Theme.text
                    font.family: Theme.titleFont
                    font.pixelSize: 14
                }
                Label { visible: !bar.slim; anchors.verticalCenter: parent.verticalCenter; text: "//" }
                Channels { anchors.verticalCenter: parent.verticalCenter; output: bar.modelData.name }
            }
        }

        Sticker {   // layout + focused window on this monitor
            order: 1
            id: titleSticker
            Layout.fillHeight: true
            Layout.fillWidth: true
            Layout.preferredWidth: 1   // take the leftover space; never size from the title
            Layout.minimumWidth: bar.slim ? 120 : 80
            interactive: true
            onClicked: _ => Niri.cycleLayout(bar.modelData.name)
            Row {
                spacing: 10
                Label { id: layoutName; anchors.verticalCenter: parent.verticalCenter; text: Niri.layoutFor(bar.modelData.name).toUpperCase(); dim: false; font.weight: Font.ExtraBold }
                Label {
                    anchors.verticalCenter: parent.verticalCenter
                    dim: false
                    font.capitalization: Font.MixedCase
                    width: Math.max(0, titleSticker.width - titleSticker.padding * 2 - layoutName.width - 10)
                    elide: Text.ElideRight
                    text: Niri.activeTitle(bar.modelData.name)
                }
            }
        }
        Sticker {   // close the focused window on this monitor (works for every app)
            order: 2
            visible: Niri.activeWindowId(bar.modelData.name) !== null
            interactive: true
            padding: 10
            Layout.fillHeight: true
            Layout.preferredWidth: implicitWidth
            onClicked: _ => Niri.closeActive(bar.modelData.name)
            Text {
                text: "✕"
                color: Theme.accentA
                font.pixelSize: 15; font.weight: Font.Black
            }
        }
        Sticker {
            order: 3
            id: tapeSticker
            visible: tape.visible          // also on the slim (portrait) bar, in compact width
            interactive: true
            Layout.fillHeight: true
            Layout.preferredWidth: implicitWidth
            onClicked: b => { if (b === Qt.LeftButton) deck.toggle(); else tape.click(b); }
            Tape { id: tape; compact: bar.slim }
        }
        MusicPanel {
            id: deck
            player: tape.player
            anchorItem: tapeSticker
            barWindow: bar
        }
        Sticker {   // Wi-Fi + network speed: click for the Wi-Fi picker
            id: netSticker
            order: 4
            interactive: true
            Layout.fillHeight: true
            Layout.preferredWidth: implicitWidth
            onClicked: _ => wifiPanel.toggle()
            Net {}
        }
        WifiPanel {
            id: wifiPanel
            anchorItem: netSticker
            barWindow: bar
        }
        Sticker {   // Render34: progress of the render PC (hidden when idle); click for the render window
            order: 4
            visible: renderSt.show
            interactive: true
            Layout.fillHeight: true
            Layout.preferredWidth: implicitWidth
            onClicked: _ => shell.toggleRender()
            RenderSticker { id: renderSt }
        }
        Sticker {   // NVIDIA state (never wakes the GPU); click for the performance view
            order: 4
            visible: SysStats.gpuState !== ""
            interactive: true
            Layout.fillHeight: true
            Layout.preferredWidth: implicitWidth
            onClicked: _ => shell.toggleTaskManager(bar.modelData.name, 1)
            Gpu {}
        }
        Sticker {   // CPU: click for the task manager
            order: 4
            interactive: true
            Layout.fillHeight: true
            Layout.preferredWidth: implicitWidth
            onClicked: _ => shell.toggleTaskManager(bar.modelData.name, 0)
            Cpu {}
        }
        Sticker {   // system tray, collapsed: "▾ N" opens the list of background apps (WARP, Discord, Steam...)
            order: 4
            visible: tray.items.length > 0
            interactive: true
            onClicked: _ => tray.toggle()
            Layout.fillHeight: true
            Layout.preferredWidth: implicitWidth
            Tray { id: tray; barWindow: bar }
        }
        Sticker {
            order: 4
            interactive: true
            usesWheel: true
            Layout.fillHeight: true
            Layout.preferredWidth: implicitWidth
            // left: mute, right: Settings > SOUND (output + microphone pickers), wheel: volume
            onClicked: b => { if (b === Qt.RightButton) Quickshell.execDetached([Quickshell.shellDir + "/../../bin/saphie-settings-page", "2"]); else volume.click(b); }
            onWheel: d => volume.step(d)
            Volume { id: volume }
        }
        Sticker {   // power: click cycles AUTO / PERF / BAL / QUIET (perfd), right click opens Settings > Power
            order: 5
            interactive: true
            Layout.fillHeight: true
            Layout.preferredWidth: implicitWidth
            onClicked: b => {
                if (b === Qt.RightButton || !PowerMode.available) Quickshell.execDetached([Quickshell.shellDir + "/../../bin/saphie-settings-page", "5"]);
                else { Sfx.play("tick"); PowerMode.cycle(); }
            }
            Perf {}
        }
        Sticker {   // battery (hidden when the laptop has no battery)
            order: 5
            visible: battery.present
            Layout.fillHeight: true
            Layout.preferredWidth: implicitWidth
            Battery { id: battery }
        }
        Sticker {   // notifications: bell + unread count, click for history
            id: bellSticker
            order: 5
            interactive: true
            padding: 10
            Layout.fillHeight: true
            Layout.preferredWidth: implicitWidth
            onClicked: _ => notifCenter.toggle()
            Row {
                spacing: 6
                Canvas {   // drawn bell (white, green when unread, slashed in Do Not Disturb)
                    id: bellIcon
                    anchors.verticalCenter: parent.verticalCenter
                    width: 16; height: 16
                    readonly property color ink: Notifs.unread > 0 ? Theme.accentA : Theme.text
                    onInkChanged: requestPaint()
                    property bool dnd: Notifs.dnd
                    onDndChanged: requestPaint()
                    onPaint: {
                        const c = getContext("2d");
                        c.reset();
                        c.fillStyle = ink;
                        c.beginPath();
                        c.moveTo(8, 1.5);
                        c.bezierCurveTo(4, 1.5, 3.2, 5, 3.2, 8);
                        c.lineTo(3.2, 10.5); c.lineTo(1.5, 12.5); c.lineTo(14.5, 12.5); c.lineTo(12.8, 10.5); c.lineTo(12.8, 8);
                        c.bezierCurveTo(12.8, 5, 12, 1.5, 8, 1.5);
                        c.fill();
                        c.fillRect(6.2, 13.4, 3.6, 2);
                        if (dnd) { c.strokeStyle = Theme.danger; c.lineWidth = 2; c.beginPath(); c.moveTo(1, 15); c.lineTo(15, 1); c.stroke(); }
                    }
                }
                Rectangle {
                    anchors.verticalCenter: parent.verticalCenter
                    visible: Notifs.unread > 0
                    width: Math.max(18, cnt.implicitWidth + 8); height: 16
                    color: Theme.accentA
                    Text { id: cnt; anchors.centerIn: parent; text: Notifs.unread > 99 ? "99+" : Notifs.unread
                           color: Theme.onAccent; font.family: Theme.labelFont; font.pixelSize: 10; font.weight: Font.ExtraBold }
                }
            }
        }
        NotificationCenter {
            id: notifCenter
            anchorItem: bellSticker
            barWindow: bar
        }
        Sticker {   // screen recording: red REC + time, click to stop (Super+Shift+S starts)
            order: 6
            visible: RecState.recording
            interactive: true
            Layout.fillHeight: true
            Layout.preferredWidth: implicitWidth
            onClicked: _ => { Sfx.play("confirm"); RecState.stop(); }
            Row {
                spacing: 7
                Rectangle { width: 12; height: 12; radius: 6; color: Theme.danger; anchors.verticalCenter: parent.verticalCenter
                            SequentialAnimation on opacity { running: RecState.recording; loops: Animation.Infinite
                                NumberAnimation { to: 0.25; duration: 600 } NumberAnimation { to: 1; duration: 600 } } }
                Text { anchors.verticalCenter: parent.verticalCenter; color: Theme.text
                       text: "REC " + Math.floor(RecState.secs / 60) + ":" + String(RecState.secs % 60).padStart(2, "0")
                       font.family: Theme.labelFont; font.pixelSize: 12; font.weight: Font.ExtraBold; font.letterSpacing: 1 }
            }
        }
        Sticker {   // mic muted (Fn+F4 / mic-mute key): red MIC OFF, click to turn the mic back on
            order: 6
            visible: bar.micMuted
            interactive: true
            Layout.fillHeight: true
            Layout.preferredWidth: implicitWidth
            onClicked: _ => { Sfx.play("confirm"); if (bar.micSource?.audio) bar.micSource.audio.muted = false; }
            Row {
                spacing: 7
                Text { anchors.verticalCenter: parent.verticalCenter; text: "🎙"; color: Theme.danger; font.pixelSize: 13 }
                Text { anchors.verticalCenter: parent.verticalCenter; color: Theme.danger; text: "MIC OFF"
                       font.family: Theme.labelFont; font.pixelSize: 12; font.weight: Font.ExtraBold; font.letterSpacing: 1 }
            }
        }
        Sticker {   // keyboard language (EN / TH), green when not English; click or Alt+Shift switches
            order: 6
            visible: Niri.kbLayouts.length > 1
            interactive: true
            Layout.fillHeight: true
            Layout.preferredWidth: implicitWidth
            onClicked: _ => { Sfx.play("tick"); Niri.switchLayout(); }
            Rectangle {   // (the sticker centres its content; no anchors here: binding loop)
                readonly property bool alt: Niri.kbIndex !== 0
                width: kbText.implicitWidth + 14; height: 18
                color: alt ? Theme.accentA : "transparent"
                border.color: alt ? Theme.bg : Theme.raised; border.width: 1
                transform: Matrix4x4 { matrix: Qt.matrix4x4(1, Theme.skew, 0, -Theme.skew * 9, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1) }
                Text { id: kbText; anchors.centerIn: parent; text: Niri.kbTag
                       color: parent.alt ? Theme.onAccent : Theme.text
                       font.family: Theme.labelFont; font.pixelSize: 11; font.weight: Font.ExtraBold; font.letterSpacing: 1 }
            }
        }
        Sticker {   // clock: click for the calendar
            id: clockSticker
            order: 6
            sharp: "tr"
            interactive: true
            Layout.fillHeight: true
            Layout.preferredWidth: implicitWidth
            onClicked: _ => calendar.toggle()
            Clock { compact: bar.slim }
        }
        CalendarPanel {
            id: calendar
            anchorItem: clockSticker
            barWindow: bar
        }
        IpcHandler {   // quickshell ipc call bar-<OUTPUT> toggleWifi|toggleMusic|toggleCalendar|toggleNotifications (tests, keys)
            target: "bar-" + bar.modelData.name
            function toggleWifi(): void { wifiPanel.toggle(); }
            function toggleMusic(): void { deck.toggle(); }
            function toggleCalendar(): void { calendar.toggle(); }
            function toggleNotifications(): void { notifCenter.toggle(); }
        }
    }
    }

    // "‹ ›": there's more of the bar that way (click to slide)
    Repeater {
        model: scroller.overflow ? [-1, 1] : []
        Rectangle {
            required property int modelData
            readonly property bool more: modelData < 0 ? scroller.contentX > 2
                                                       : scroller.contentX < scroller.contentWidth - scroller.width - 2
            visible: more
            x: modelData < 0 ? 0 : bar.width - width
            y: 8; width: 18; height: bar.stickerHeight
            color: Theme.bg; opacity: 0.92
            Text { anchors.centerIn: parent; text: parent.modelData < 0 ? "‹" : "›"; color: Theme.accentA
                   font.pixelSize: 20; font.weight: Font.Black }
            MouseArea { anchors.fill: parent; onClicked: scroller.slide(parent.modelData * scroller.width * 0.6) }
        }
    }
}
