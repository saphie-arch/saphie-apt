import Quickshell.Io
import QtQuick

// Power: the mode chip (AUTO / PERF / BAL / QUIET, click the sticker to cycle, PowerMode.qml)
// and the firmware profile perfd actually set (world-readable sysfs).
Row {
    id: root
    property string profile: ""
    spacing: 6

    FileView {
        id: file
        path: "/sys/firmware/acpi/platform_profile"
        printErrors: false
        onLoaded: {
            const t = file.text().trim();
            root.profile = /^[a-z-]{1,32}$/.test(t) ? t : "";   // trust nothing we read
        }
        onLoadFailed: root.profile = ""
    }
    Timer { interval: 2000; running: true; repeat: true; onTriggered: file.reload() }

    Label { anchors.verticalCenter: parent.verticalCenter; text: "PWR" }
    Rectangle {   // mode chip: green when the user forced a mode
        visible: PowerMode.available
        anchors.verticalCenter: parent.verticalCenter
        width: modeText.implicitWidth + 12; height: 16
        color: PowerMode.mode === "auto" ? "transparent" : Theme.accentA
        border.color: PowerMode.mode === "auto" ? Theme.raised : Theme.bg; border.width: 1
        transform: Matrix4x4 { matrix: Qt.matrix4x4(1, Theme.skew, 0, -Theme.skew * 8, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1) }
        Text { id: modeText; anchors.centerIn: parent; text: PowerMode.label(PowerMode.mode)
               color: PowerMode.mode === "auto" ? Theme.textDim : Theme.onAccent
               font.family: Theme.labelFont; font.pixelSize: 9; font.weight: Font.ExtraBold; font.letterSpacing: 0.8 }
    }
    Label {
        anchors.verticalCenter: parent.verticalCenter
        dim: false
        font.weight: Font.ExtraBold
        text: ({ "performance": "PERF", "balanced": "BAL", "balanced-performance": "BAL+",
                 "low-power": "LOW", "quiet": "QUIET", "cool": "COOL" })[root.profile]
              ?? (root.profile ? root.profile.toUpperCase().slice(0, 6) : "--")
    }
}
