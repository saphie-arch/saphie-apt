import Quickshell.Services.Pipewire
import QtQuick

// Segmented VU-style volume meter for the default output. Click: mute. Wheel: +-5 %.
Row {
    id: root
    readonly property var sink: Pipewire.defaultAudioSink
    readonly property real volume: sink?.audio?.volume ?? 0
    readonly property bool muted: sink?.audio?.muted ?? true
    readonly property int blocks: 10
    spacing: 8

    PwObjectTracker { objects: root.sink ? [root.sink] : [] }

    // Meter bounces when the level changes.
    onVolumeChanged: bump.restart()
    onMutedChanged: bump.restart()
    SequentialAnimation {
        id: bump
        NumberAnimation { target: meter; property: "scale"; to: 1.18; duration: 60; easing.type: Easing.OutQuad }
        NumberAnimation { target: meter; property: "scale"; to: 1.0; duration: 260; easing.type: Easing.OutBack; easing.overshoot: 2.5 }
    }

    Row {
        id: meter
        anchors.verticalCenter: parent.verticalCenter
        spacing: 2
        height: 18
        transformOrigin: Item.Bottom
        Repeater {
            model: root.blocks
            Rectangle {
                required property int index
                readonly property bool lit: !root.muted && root.volume * root.blocks > index + 0.5 - 1e-6
                anchors.bottom: parent.bottom
                width: 4
                height: 6 + index * 12 / (root.blocks - 1)
                color: !lit ? Theme.raised : (index >= root.blocks * 0.8 ? Theme.accentA : Theme.text)
            }
        }
    }
    Label {
        anchors.verticalCenter: parent.verticalCenter
        width: 26
        text: root.muted ? "MUTE" : String(Math.round(root.volume * 100))
    }

    function click(button) {
        if (root.sink?.audio && button === Qt.LeftButton) root.sink.audio.muted = !root.sink.audio.muted;
    }
    function step(delta) {
        if (!root.sink?.audio) return;
        const v = root.sink.audio.volume + (delta > 0 ? 0.05 : -0.05);
        root.sink.audio.volume = Math.max(0, Math.min(1, v));   // never boost past 100 % from the bar
    }
}
