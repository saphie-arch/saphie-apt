import Quickshell
import Quickshell.Wayland
import QtQuick

// Saphie power menu (Super+Shift+E): log out / lock / sleep / restart / shut down.
// Same language as the launcher: scanlines, indexed rows, sliding green plate, TV switch-off.
// The menu is the confirmation: nothing happens until an option is chosen (Esc cancels).
PanelWindow {
    id: win
    required property var modelData
    screen: modelData
    property bool open: false
    property bool busy: false
    visible: open
    color: "transparent"
    anchors { top: true; bottom: true; left: true; right: true }
    exclusionMode: ExclusionMode.Ignore
    WlrLayershell.layer: WlrLayer.Overlay
    WlrLayershell.namespace: "saphie-power"
    WlrLayershell.keyboardFocus: open ? WlrKeyboardFocus.Exclusive : WlrKeyboardFocus.None

    readonly property var options: [
        { label: "LOG OUT",   hint: "END THE SAPHIE SESSION",  cmd: ["niri", "msg", "action", "quit", "--skip-confirmation"], off: true },
        { label: "LOCK",      hint: "LOCK THE SCREEN",          cmd: [],                                                         off: false },
        { label: "SLEEP",     hint: "SUSPEND TO RAM",           cmd: ["systemctl", "suspend"],                                   off: false },
        { label: "RESTART",   hint: "REBOOT THE PC",            cmd: ["systemctl", "reboot"],                                    off: true },
        { label: "SHUT DOWN", hint: "POWER OFF",                cmd: ["systemctl", "poweroff"],                                  off: true }
    ]
    property int current: 0
    property var pending: null

    function show() { if (closing) { closeAnim.stop(); closing = false; } Sfx.play("open"); busy = false; current = 0; open = true; openAnim.restart(); keys.forceActiveFocus(); }
    function hide(instant) { if (!open || closing) return; if (!busy) Sfx.play("close"); if (instant) finishClose(); else closeAnim.restart(); }
    function choose(i) {
        if (busy) return;
        Sfx.play("confirm");
        busy = true;
        current = i;
        pending = options[i];
        if (pending.off) {
            Sfx.play("window-close");
            offAnim.restart();
        } else {
            hide();
            runTimer.restart();   // let the menu disappear before locking/suspending
        }
    }
    Timer {
        id: runTimer; interval: 330          // after the close animation (280 ms)
        onTriggered: {
            if (win.pending.label === "LOCK") Locker.lock();
            else Quickshell.execDetached(win.pending.cmd);   // SLEEP: saphie-sleep-lock locks first
        }
    }

    Item {
        id: screenRoot
        anchors.fill: parent
        transform: Scale { id: tvScale; origin.x: screenRoot.width / 2; origin.y: screenRoot.height / 2; yScale: 1 }

        Rectangle { anchors.fill: parent; color: "#f0000000" }
        Canvas {
            anchors.fill: parent; opacity: 0.05
            onPaint: { const c = getContext("2d"); c.fillStyle = "#ffffff"; for (let y = 0; y < height; y += 3) c.fillRect(0, y, width, 1); }
        }
        MouseArea { anchors.fill: parent; onClicked: win.hide() }

        Item {
            id: keys
            focus: true
            Keys.onPressed: ev => {
                if (ev.key === Qt.Key_Escape) win.hide();
                else if (ev.key === Qt.Key_Down || ev.key === Qt.Key_Tab) { Sfx.play("tick"); win.current = (win.current + 1) % win.options.length; }
                else if (ev.key === Qt.Key_Up || ev.key === Qt.Key_Backtab) { Sfx.play("tick"); win.current = (win.current + win.options.length - 1) % win.options.length; }
                else if (ev.key === Qt.Key_Return || ev.key === Qt.Key_Enter || ev.key === Qt.Key_Space) win.choose(win.current);
                else return;
                ev.accepted = true;
            }
        }

        Column {
            id: menu
            anchors.centerIn: parent
            width: Math.min(parent.width - 80, 620)
            spacing: 6
            transform: Translate { id: menuT; x: 0 }

            Text {
                text: "CH ▸ POWER"
                color: Theme.text
                font.family: Theme.titleFont; font.pixelSize: 22
                bottomPadding: 18
            }
            Item {
                width: menu.width; height: win.options.length * 70 - 6
                Item {   // sliding plate
                    id: plate
                    width: parent.width; height: 64
                    y: win.current * 70
                    Behavior on y { NumberAnimation { duration: 170; easing.type: Easing.OutBack; easing.overshoot: 1.8 } }
                    Rectangle {
                        anchors.fill: parent
                        color: win.options[win.current].off ? Theme.accentA : Theme.accentA
                        transform: Matrix4x4 { matrix: Qt.matrix4x4(1, Theme.skew, 0, -Theme.skew * 32, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1) }
                    }
                }
                Repeater {
                    model: win.options
                    Item {
                        id: optRow
                        required property var modelData
                        required property int index
                        readonly property bool sel: index === win.current
                        y: index * 70; width: menu.width; height: 64
                        opacity: 0
                        transform: Translate { id: rT; x: -28 }
                        Connections { target: openAnim; function onStarted() { rIn.restart(); } }
                        SequentialAnimation {
                            id: rIn
                            ScriptAction { script: { rT.x = -28; optRow.opacity = 0; } }
                            PauseAnimation { duration: 150 + index * 40 }
                            ParallelAnimation {
                                NumberAnimation { target: rT; property: "x"; to: 0; duration: 240; easing.type: Easing.OutBack; easing.overshoot: 1.6 }
                                NumberAnimation { target: optRow; property: "opacity"; to: 1; duration: 90 }
                            }
                        }
                        Text {
                            x: 18; anchors.verticalCenter: parent.verticalCenter
                            text: String(index + 1).padStart(2, "0")
                            color: parent.sel ? Theme.onAccent : Theme.raised
                            font.family: Theme.labelFont; font.pixelSize: 16; font.weight: Font.ExtraBold
                        }
                        Text {
                            x: 70; anchors.verticalCenter: parent.verticalCenter; anchors.verticalCenterOffset: -6
                            text: modelData.label
                            color: parent.sel ? Theme.onAccent : Theme.text
                            font.family: Theme.numeralFont; font.weight: Font.ExtraBold; font.italic: true; font.pixelSize: 38
                        }
                        Text {
                            x: 72; anchors.bottom: parent.bottom; anchors.bottomMargin: 4
                            text: modelData.hint
                            color: parent.sel ? Theme.onAccent : Theme.raised
                            font.family: Theme.labelFont; font.pixelSize: 10; font.letterSpacing: 1.4
                        }
                        MouseArea {
                            anchors.fill: parent; hoverEnabled: true
                            onEntered: win.current = index
                            onClicked: win.choose(index)
                        }
                    }
                }
            }
            Text {
                topPadding: 22
                text: "↑↓ SELECT    ⏎ CONFIRM    ESC CANCEL"
                color: Theme.textDim
                font.family: Theme.labelFont; font.pixelSize: 11; font.letterSpacing: 1.2
            }
        }

        Rectangle {
            id: wiper
            visible: (openAnim.running || closeAnim.running) && Theme.openStyle === "wipe"
            width: parent.width * 1.6; height: parent.height * 2
            color: Theme.accentA; rotation: 20
            x: -width; y: -parent.height * 0.5
        }
    }

    Rectangle {   // TV switch-on line
        id: tvLine
        anchors.centerIn: parent
        width: parent.width; height: 4
        color: "#ffffff"
        opacity: 0
    }

    SequentialAnimation {
        id: openAnim
        ScriptAction { script: {
            const tv = Theme.openStyle === "tv";
            screenRoot.scale = 1; screenRoot.opacity = 1; wiper.x = -wiper.width * 0.2;
            tvScale.yScale = tv ? 0.004 : 1; tvLine.opacity = tv ? 1 : 0;
        } }
        PauseAnimation { duration: 70 }
        ParallelAnimation {
            NumberAnimation { target: wiper; property: "x"; to: win.width + win.height; duration: 380; easing.type: Easing.OutCubic }
            SequentialAnimation {   // TV switch-on (Theme.openStyle "tv")
                PauseAnimation { duration: 70 }
                ParallelAnimation {
                    NumberAnimation { target: tvScale; property: "yScale"; to: 1; duration: 340; easing.type: Easing.OutBack; easing.overshoot: 1.3 }
                    NumberAnimation { target: tvLine; property: "opacity"; to: 0; duration: 220; easing.type: Easing.InQuad }
                }
            }
        }
    }
    SequentialAnimation {   // TV switch-off, then run the command
        id: offAnim
        NumberAnimation { target: screenRoot; property: "scale"; to: 1.02; duration: 60 }
        ParallelAnimation {
            NumberAnimation { target: screenRoot; property: "scale"; to: 0.3; duration: 220; easing.type: Easing.InQuad }
            NumberAnimation { target: screenRoot; property: "opacity"; to: 0; duration: 220; easing.type: Easing.InQuad }
        }
        ScriptAction { script: { Quickshell.execDetached(win.pending.cmd); win.hide(true); } }
    }

    // Close animation (reverse of the open): wipe style = green panel sweeps back over the
    // screen; tv style = screen collapses into a white line (TV switch-off). Then the window goes.
    property bool closing: false
    function finishClose() {
        closeAnim.stop(); closing = false; open = false;
        wiper.x = -wiper.width; tvScale.yScale = 1; tvLine.opacity = 0; screenRoot.scale = 1; screenRoot.opacity = 1;
    }
    SequentialAnimation {
        id: closeAnim
        ScriptAction { script: { win.closing = true; wiper.x = win.width + win.height; } }
        ParallelAnimation {
            NumberAnimation { target: wiper; property: "x"; to: -wiper.width * 0.2; duration: 240; easing.type: Easing.InCubic }
            NumberAnimation { target: tvScale; property: "yScale"; to: Theme.openStyle === "tv" ? 0.004 : 1; duration: 200; easing.type: Easing.InBack }
            NumberAnimation { target: tvLine; property: "opacity"; to: Theme.openStyle === "tv" ? 1 : 0; duration: 160 }
        }
        PauseAnimation { duration: 40 }
        ScriptAction { script: win.finishClose() }
    }
}
