pragma Singleton
import Quickshell
import QtQuick

// Saphie UI sound kit (desktop/sounds/make-sounds.py). One place that plays every UI sound:
//   Sfx.play("tick" | "confirm" | "back" | "open" | "close" | "window-open" | "window-close" | "layout" |
//            "notify" | "shutter" | "lock" | "unlock" | "error")
// pw-play per sound (QtMultimedia is not in our Qt build). Repeats of the same sound within
// 45 ms are dropped, so holding an arrow key cannot pile up players.
Singleton {
    id: root
    readonly property var known: ["tick", "confirm", "back", "open", "close", "window-open", "window-close", "layout",
                                  "notify", "shutter", "lock", "unlock", "error", "ring"]
    property var last: ({})

    function play(name) {
        if (!Theme.uiSounds || !known.includes(name)) return;
        const now = Date.now();
        if (now - (last[name] ?? 0) < 45) return;
        last[name] = now;
        Quickshell.execDetached(["pw-play", "--media-role", "Event", "--volume", String(Theme.soundVolume),
                                 Quickshell.shellDir + "/../../sounds/" + name + ".wav"]);
    }
}
