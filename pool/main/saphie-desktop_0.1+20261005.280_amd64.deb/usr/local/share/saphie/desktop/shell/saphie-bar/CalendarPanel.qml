import Quickshell
import QtQuick

// Month calendar under the clock: today on a green skewed plate, weekend dimmed,
// ‹ › change month, click the title to jump back to this month.
PopupWindow {
    id: cal
    required property Item anchorItem
    required property var barWindow
    anchor.window: barWindow
    anchor.item: anchorItem
    anchor.edges: Edges.Bottom
    anchor.gravity: Edges.Bottom
    anchor.margins.top: 10
    implicitWidth: 340
    implicitHeight: 330
    color: "transparent"
    grabFocus: true

    property date today: new Date()
    property int year: today.getFullYear()
    property int month: today.getMonth()       // 0..11
    function toggle() {
        if (closing) return;
        if (visible) { Sfx.play("close"); closing = true; closeAnim.restart(); }
        else { Sfx.play("open"); drop.y = 0; body.opacity = 1; visible = true; }
    }
    onVisibleChanged: if (visible) { today = new Date(); year = today.getFullYear(); month = today.getMonth(); openAnim.restart(); }
    function shift(d) {
        let m = month + d, y = year;
        if (m < 0) { m = 11; y--; } else if (m > 11) { m = 0; y++; }
        month = m; year = y; flip.restart();
    }
    readonly property var days: {
        // Monday-first grid of 42 cells: {day, inMonth, isToday, weekend}
        const first = new Date(year, month, 1);
        const offset = (first.getDay() + 6) % 7;
        const out = [];
        for (let i = 0; i < 42; i++) {
            const d = new Date(year, month, 1 - offset + i);
            out.push({ day: d.getDate(), inMonth: d.getMonth() === month,
                       isToday: d.toDateString() === today.toDateString(),
                       weekend: d.getDay() === 0 || d.getDay() === 6 });
        }
        return out;
    }

    Item {
        id: body
        anchors.fill: parent
        anchors.topMargin: 16; anchors.rightMargin: 8; anchors.bottomMargin: 8
        transform: Translate { id: drop; y: 0 }

        Rectangle { x: 6; y: 6; width: parent.width; height: parent.height; color: Theme.bg }
        Rectangle {
            anchors.fill: parent
            color: Theme.surface; border.color: Theme.bg; border.width: 2
            topLeftRadius: Theme.corner; topRightRadius: 0; bottomLeftRadius: Theme.corner; bottomRightRadius: Theme.corner
            Rectangle { anchors.fill: parent; anchors.margins: 2; color: "transparent"; border.color: Theme.ring; border.width: 3
                        topLeftRadius: Theme.corner - 2; bottomLeftRadius: Theme.corner - 2; bottomRightRadius: Theme.corner - 2 }
        }
        Rectangle {   // green tab
            x: 18; y: -12; width: 120; height: 26
            color: Theme.accentA; border.color: Theme.bg; border.width: 2
            transform: Matrix4x4 { matrix: Qt.matrix4x4(1, Theme.skew, 0, -Theme.skew * 13, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1) }
            Text { anchors.centerIn: parent; text: "CALENDAR"; color: Theme.onAccent
                   font.family: Theme.labelFont; font.pixelSize: 11; font.weight: Font.ExtraBold; font.letterSpacing: 1.6 }
        }

        // Header: ‹  OCTOBER 2026  ›
        Item {
            x: 18; y: 26; width: parent.width - 36; height: 40
            Text {
                id: title
                anchors.centerIn: parent
                text: Qt.formatDate(new Date(cal.year, cal.month, 1), "MMMM yyyy").toUpperCase()
                color: Theme.text
                font.family: Theme.numeralFont; font.weight: Font.ExtraBold; font.italic: true; font.pixelSize: 30
                transform: Translate { id: titleT; y: 0 }
                MouseArea { anchors.fill: parent; onClicked: { cal.today = new Date(); cal.year = cal.today.getFullYear(); cal.month = cal.today.getMonth(); flip.restart(); } }
            }
            component Arrow: Rectangle {
                id: arrowBtn
                property string glyph
                signal hit()
                width: 32; height: 30
                color: am.containsMouse ? Theme.accentA : Theme.bg
                border.color: Theme.ring; border.width: 2
                scale: am.pressed ? 0.9 : 1
                Behavior on scale { NumberAnimation { duration: 140; easing.type: Easing.OutBack; easing.overshoot: 2.4 } }
                Text { anchors.centerIn: parent; text: arrowBtn.glyph; color: am.containsMouse ? Theme.onAccent : Theme.text; font.pixelSize: 16; font.weight: Font.Black }
                MouseArea { id: am; anchors.fill: parent; hoverEnabled: true; onClicked: arrowBtn.hit() }
            }
            Arrow { anchors.left: parent.left; anchors.verticalCenter: parent.verticalCenter; glyph: "‹"; onHit: cal.shift(-1) }
            Arrow { anchors.right: parent.right; anchors.verticalCenter: parent.verticalCenter; glyph: "›"; onHit: cal.shift(1) }
        }

        // Weekday header + grid
        Grid {
            id: grid
            x: 18; y: 76
            columns: 7; spacing: 4
            Repeater {
                model: ["MO", "TU", "WE", "TH", "FR", "SA", "SU"]
                Text {
                    required property string modelData
                    required property int index
                    width: 40; height: 22
                    horizontalAlignment: Text.AlignHCenter
                    text: modelData
                    color: index >= 5 ? Theme.raised : Theme.textDim
                    font.family: Theme.labelFont; font.pixelSize: 11; font.weight: Font.ExtraBold
                }
            }
            Repeater {
                model: cal.days
                Item {
                    required property var modelData
                    width: 40; height: 30
                    Rectangle {   // today plate
                        anchors.fill: parent; anchors.margins: 1
                        visible: modelData.isToday
                        color: Theme.accentA
                        transform: Matrix4x4 { matrix: Qt.matrix4x4(1, Theme.skew, 0, -Theme.skew * 14, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1) }
                    }
                    Text {
                        anchors.centerIn: parent
                        text: modelData.day
                        color: modelData.isToday ? Theme.onAccent
                             : !modelData.inMonth ? "#3a3a3a"
                             : modelData.weekend ? Theme.textDim : Theme.text
                        font.family: Theme.numeralFont; font.weight: Font.ExtraBold; font.italic: true
                        font.pixelSize: modelData.isToday ? 22 : 19
                    }
                }
            }
        }
    }

    SequentialAnimation {
        id: openAnim
        ParallelAnimation {
            NumberAnimation { target: drop; property: "y"; from: -18; to: 0; duration: 260; easing.type: Easing.OutBack; easing.overshoot: 1.6 }
            NumberAnimation { target: body; property: "opacity"; from: 0; to: 1; duration: 120 }
        }
    }
    ParallelAnimation {   // month change: title flips, grid slides
        id: flip
        NumberAnimation { target: titleT; property: "y"; from: 12; to: 0; duration: 240; easing.type: Easing.OutBack; easing.overshoot: 2.0 }
        NumberAnimation { target: grid; property: "opacity"; from: 0.2; to: 1; duration: 200 }
    }

    // Close animation: lift + fade (reverse of the drop-in), then hide.
    property bool closing: false
    SequentialAnimation {
        id: closeAnim
        ParallelAnimation {
            NumberAnimation { target: drop; property: "y"; to: -18; duration: 150; easing.type: Easing.InBack; easing.overshoot: 1.4 }
            NumberAnimation { target: body; property: "opacity"; to: 0; duration: 150; easing.type: Easing.InQuad }
        }
        ScriptAction { script: { cal.closing = false; cal.visible = false; drop.y = 0; body.opacity = 1; } }
    }
}
