pragma Singleton
import Quickshell
import Quickshell.Services.Pam
import QtQuick

// Lock state + PAM authentication (system "login" stack, like swaylock on Ubuntu).
// The password lives only in the input field until it is handed to PAM, then it is cleared.
Singleton {
    id: root
    property bool locked: false
    property bool unlocking: false     // plays the switch-off before the lock is released
    property string message: ""        // shown under the field (PAM prompt / error)
    property bool error: false
    property bool busy: false
    property int failures: 0
    signal failed()                    // UI shakes
    property string pending: ""

    function lock() { if (!locked) { Sfx.play("lock"); message = ""; error = false; busy = false; unlocking = false; locked = true; } }
    Timer { id: releaseTimer; interval: 300; onTriggered: { root.locked = false; root.unlocking = false; } }
    function submit(password) {
        if (busy || password.length === 0) return;
        pending = password;
        busy = true; error = false; message = "CHECKING…";
        if (!pam.active && !pam.start()) { busy = false; error = true; message = "AUTH UNAVAILABLE"; pending = ""; }
    }

    PamContext {
        id: pam
        // config defaults to "login" in /etc/pam.d
        onResponseRequiredChanged: {
            if (!responseRequired) return;
            if (root.pending.length > 0) { respond(root.pending); root.pending = ""; }
            else { root.busy = false; root.message = (message || "PASSWORD").toUpperCase(); }   // extra prompt (e.g. 2FA)
        }
        onPamMessage: if (messageIsError) root.message = message.toUpperCase()
        onCompleted: result => {
            root.busy = false; root.pending = "";
            if (result === PamResult.Success) {
                root.failures = 0; root.message = ""; root.error = false;
                Sfx.play("unlock"); root.unlocking = true; releaseTimer.restart();   // TV switch-off, then unlock
            } else {
                root.failures++; root.error = true; root.message = "WRONG PASSWORD"; root.failed();
            }
        }
        onError: err => { root.busy = false; root.pending = ""; root.error = true; root.message = "AUTH ERROR"; root.failed(); }
    }
}
