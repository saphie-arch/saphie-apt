import Quickshell
import QtQuick

// Render34 app window (Saphie style): the render PC's queue with a live frame preview, blends to
// render, finished videos (play in mpv, save to PC-A), history and PC-A's files. Opened from the
// bar's render sticker, the launcher ("Render") or `quickshell ipc call render toggle`.
// A normal window (niri tiles it), so it can stay open on any channel while you work.
FloatingWindow {
    id: win
    title: "Render34"
    implicitWidth: 980
    implicitHeight: 680
    color: Theme.bg
    visible: false
    property int tab: 0
    readonly property var tabs: ["QUEUE", "BLENDS", "VIDEOS", "HISTORY", "PC-A"]
    property var queue: null          // /api/queue
    property var blends: []
    property var videos: []
    property var history: []
    property var source: []           // PC-A files
    property string msg: ""
    property string startF: ""
    property string endF: ""

    function toggle() { visible = !visible; if (visible) refresh(); }
    function showTab(n) { tab = Math.max(0, Math.min(tabs.length - 1, n)); visible = true; refresh(); }
    function say(t) { msg = t; msgOff.restart(); }
    Timer { id: msgOff; interval: 5000; onTriggered: win.msg = "" }

    function refresh() {
        if (!Render.configured) return;
        if (tab === 0) Render.api("GET", "/api/queue", (ok, j) => { if (ok) win.queue = j; });
        if (tab === 1) Render.api("GET", "/api/blends", (ok, j) => { if (ok) win.blends = j.items || []; });
        if (tab === 2) Render.api("GET", "/api/videos", (ok, j) => { if (ok) win.videos = j.items || []; });
        if (tab === 3) Render.api("GET", "/api/history?what=renders&limit=100", (ok, j) => { if (ok) win.history = j.items || []; });
        if (tab === 4) Render.api("GET", "/api/source-list", (ok, j) => {
            if (ok) win.source = (j.items || []).filter(i => /\.blend$/i.test(i.name || i.path));
            else win.say("PC-A ISN'T REACHABLE FROM THE RENDER PC");
        });
    }
    onTabChanged: refresh()
    Timer { interval: 3000; repeat: true; running: win.visible && Render.online; onTriggered: win.refresh() }

    function render(file, mode) {
        let p = "/api/render?file=" + Render.q(file) + "&mode=" + mode;
        if (/^\d+$/.test(startF)) p += "&start=" + startF;
        if (/^\d+$/.test(endF)) p += "&end=" + endF;
        Render.api("POST", p, (ok, j) => {
            if (ok) { Sfx.play("confirm"); say("QUEUED " + Render.shortName(file).toUpperCase() + " · #" + (j.position ?? 0)); tab = 0; }
            else say(((j && j.error) || "COULD NOT QUEUE").toUpperCase());
        });
    }
    function cancel(id) {
        Render.api("POST", "/api/cancel?job=" + Render.q(id), ok => { Sfx.play(ok ? "close" : "error"); win.refresh(); });
    }
    function fmtSize(b) { b = Number(b || 0); return b > 1e9 ? (b / 1e9).toFixed(1) + " GB" : (b / 1e6).toFixed(b > 1e7 ? 0 : 1) + " MB"; }
    function fmtDate(t) { return t ? new Date(Number(t) * 1000).toLocaleString(Qt.locale(), "dd MMM HH:mm") : "–"; }

    // ---- small styled pieces
    component Btn: Rectangle {
        id: b
        property string label
        property bool hot: false
        property bool danger: false
        signal hit()
        width: bt.implicitWidth + 26; height: 28
        color: bm.containsMouse ? (danger ? Theme.danger : Theme.accentA) : (hot ? Theme.accentA : Theme.bg)
        border.color: hot || bm.containsMouse ? Theme.bg : Theme.ring; border.width: 2
        transform: Matrix4x4 { matrix: Qt.matrix4x4(1, Theme.skew, 0, -Theme.skew * 14, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1) }
        Text { id: bt; anchors.centerIn: parent; text: b.label
               color: bm.containsMouse || b.hot ? Theme.onAccent : Theme.text
               font.family: Theme.labelFont; font.pixelSize: 11; font.weight: Font.ExtraBold; font.letterSpacing: 1 }
        MouseArea { id: bm; anchors.fill: parent; hoverEnabled: true; onClicked: { Sfx.play("tick"); b.hit(); } }
    }
    component Lbl: Text {
        color: Theme.text
        font.family: Theme.labelFont; font.pixelSize: 12; font.weight: Font.Bold
        elide: Text.ElideRight
    }
    component Bar: Rectangle {
        property real v: 0
        height: 6; color: Theme.raised
        Rectangle { width: parent.width * Math.max(0, Math.min(1, parent.v)); height: parent.height; color: Theme.accentA
                    Behavior on width { NumberAnimation { duration: 400; easing.type: Easing.OutCubic } } }
    }

    Rectangle {   // frame
        anchors.fill: parent
        color: Theme.surface
        border.color: Theme.ring; border.width: 3

        // header
        Row {
            x: 22; y: 18; spacing: 14
            Text { text: "RENDER34"; color: Theme.text; font.family: Theme.titleFont; font.pixelSize: 24 }
            Rectangle {
                anchors.verticalCenter: parent.verticalCenter
                width: st.implicitWidth + 20; height: 22
                color: Render.online ? Theme.accentA : Theme.bg
                border.color: Render.online ? Theme.bg : Theme.ring; border.width: 2
                transform: Matrix4x4 { matrix: Qt.matrix4x4(1, Theme.skew, 0, -Theme.skew * 11, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1) }
                Text { id: st; anchors.centerIn: parent
                       text: !Render.configured ? "NOT SET UP" : (Render.online ? "PC-B ● ONLINE" : "PC-B ○ OFFLINE")
                       color: Render.online ? Theme.onAccent : Theme.textDim
                       font.family: Theme.labelFont; font.pixelSize: 10; font.weight: Font.ExtraBold; font.letterSpacing: 1 }
            }
        }
        Row {
            anchors.right: parent.right; anchors.rightMargin: 22; y: 20; spacing: 10
            Btn { label: "↻ REFRESH"; onHit: win.refresh() }
            Btn { label: "WEB PAGE"; visible: Render.configured; onHit: Render.openWeb() }
        }

        // tabs
        Row {
            x: 22; y: 64; spacing: 6
            Repeater {
                model: win.tabs
                Btn { required property int index; required property string modelData
                      label: modelData; hot: win.tab === index; onHit: win.tab = index }
            }
        }
        Text {
            visible: win.msg !== ""
            x: 22; y: 98; width: parent.width - 44; elide: Text.ElideRight
            text: win.msg; color: Theme.accentA
            font.family: Theme.labelFont; font.pixelSize: 11; font.weight: Font.ExtraBold; font.letterSpacing: 1
        }

        Item {   // page
            id: page
            x: 22; y: 118
            width: parent.width - 44; height: parent.height - y - 20

            // not set up
            Column {
                visible: !Render.configured
                spacing: 10
                Lbl { text: "RENDER34 ISN'T SET UP ON THIS PC YET"; color: Theme.accentA; font.pixelSize: 14 }
                Lbl { width: page.width; wrapMode: Text.WordWrap; elide: Text.ElideNone
                      text: "Install it with render34/install.sh (see render34/README.md), then put the render PC's address in ~/.config/render34/config.json (\"pcb_url\": \"http://100.x.y.z:8080\") and the shared token in ~/.config/render34/token." }
            }

            // ---- QUEUE
            Item {
                anchors.fill: parent
                visible: Render.configured && win.tab === 0
                readonly property var cur: Render.current
                readonly property bool narrow: width < 860
                Rectangle {   // live preview
                    id: prev
                    width: parent.narrow ? parent.width : 480; height: width * 9 / 16
                    color: Theme.bg; border.color: Theme.ring; border.width: 2
                    Image {
                        id: shot
                        anchors.fill: parent; anchors.margins: 2
                        fillMode: Image.PreserveAspectFit
                        cache: false; asynchronous: true
                        property string next: parent.parent.cur && parent.parent.cur.kind !== "bake"
                                              ? Render.media("/api/preview?job=" + Render.q(parent.parent.cur.id) + "&n=" + parent.parent.cur.frame) : ""
                        // keep showing the last good frame while the next one loads
                        onNextChanged: if (next !== "") loader.source = next
                        Image { id: loader; visible: false; cache: false; asynchronous: true
                                onStatusChanged: if (status === Image.Ready) shot.source = source }
                    }
                    Lbl { anchors.centerIn: parent; visible: shot.status !== Image.Ready
                          text: parent.parent.cur ? "WAITING FOR THE FIRST FRAME…" : "NOTHING RENDERING"; color: Theme.textDim }
                }
                Column {
                    id: info
                    x: parent.narrow ? 0 : prev.width + 24
                    y: parent.narrow ? prev.height + 14 : 0
                    width: parent.width - x
                    spacing: 10
                    visible: !!parent.cur
                    Lbl { width: parent.width; font.pixelSize: 18; font.weight: Font.ExtraBold
                          text: parent.parent.cur ? Render.shortName(parent.parent.cur.blend) : "" }
                    Lbl { color: Theme.textDim
                          text: parent.parent.cur ? (parent.parent.cur.kind === "bake" ? "BAKING FLUID" : (parent.parent.cur.status || "").toUpperCase())
                                + "  ·  FRAME " + (parent.parent.cur.frame || 0) + " / " + ((parent.parent.cur.frame_end - parent.parent.cur.frame_start + 1) || "?") : "" }
                    Bar { width: parent.width; v: parent.parent.cur ? (parent.parent.cur.percent || 0) / 100 : 0 }
                    Lbl { text: parent.parent.cur ? Math.round(parent.parent.cur.percent || 0) + " %   ·   ETA " + Render.fmtTime(parent.parent.cur.eta_s)
                                + (parent.parent.cur.s_per_frame ? "   ·   " + (parent.parent.cur.s_per_frame < 1 ? Math.round(parent.parent.cur.s_per_frame * 1000) + " ms" : Number(parent.parent.cur.s_per_frame).toFixed(1) + " s") + "/frame" : "") : "" }
                    Lbl { color: Theme.accentA
                          text: parent.parent.cur ? (parent.parent.cur.engine || "").replace("BLENDER_", "")
                                + (parent.parent.cur.engine === "CYCLES" && parent.parent.cur.device ? "  ·  " + parent.parent.cur.device : "") : "" }
                    Btn { label: "CANCEL"; danger: true; onHit: win.cancel(parent.parent.cur.id) }
                }
                Column {
                    y: parent.narrow ? info.y + (info.visible ? info.height : 0) + 20 : prev.height + 20
                    width: parent.width
                    spacing: 6
                    Lbl { text: "QUEUE  ·  " + ((win.queue && win.queue.queued) ? win.queue.queued.length : 0); color: Theme.textDim }
                    Repeater {
                        model: win.queue ? (win.queue.queued || []) : []
                        Row {
                            required property var modelData
                            spacing: 14
                            Lbl { width: 30; text: "#" + (modelData.position ?? ""); color: Theme.accentA }
                            Lbl { width: page.width - 30 - 14 * 2 - 90; text: Render.shortName(modelData.file || modelData.blend) + (modelData.kind === "bake" ? "  (bake)" : "") }
                            Btn { label: "REMOVE"; danger: true; onHit: win.cancel(modelData.id) }
                        }
                    }
                }
            }

            // ---- BLENDS
            Item {
                anchors.fill: parent
                visible: Render.configured && win.tab === 1
                Row {
                    id: rangeRow
                    spacing: 10
                    Lbl { anchors.verticalCenter: parent.verticalCenter; text: "FRAMES"; color: Theme.textDim }
                    Repeater {
                        model: ["START", "END"]
                        Rectangle {
                            required property string modelData
                            width: 90; height: 28; color: "#101010"; border.color: inp.activeFocus ? Theme.accentA : Theme.ring; border.width: 2
                            TextInput {
                                id: inp
                                anchors.fill: parent; anchors.margins: 6
                                color: Theme.text; font.family: Theme.labelFont; font.pixelSize: 13
                                validator: RegularExpressionValidator { regularExpression: /\d{0,6}/ }
                                onTextChanged: { if (parent.modelData === "START") win.startF = text; else win.endF = text; }
                                Text { visible: !parent.text; text: parent.parent.modelData + " (FILE)"; color: Theme.raised
                                       font.family: Theme.labelFont; font.pixelSize: 11 }
                            }
                        }
                    }
                }
                ListView {
                    y: 44; width: parent.width; height: parent.height - y
                    clip: true; spacing: 4
                    model: win.blends
                    delegate: Row {
                        required property var modelData
                        spacing: 14; height: 32
                        Lbl { anchors.verticalCenter: parent.verticalCenter; width: Math.max(100, page.width - (page.width > 700 ? 404 : 300)); text: Render.shortName(modelData.name) }
                        Lbl { anchors.verticalCenter: parent.verticalCenter; width: 70; text: win.fmtSize(modelData.size); color: Theme.textDim }
                        Lbl { anchors.verticalCenter: parent.verticalCenter; width: 90; visible: page.width > 700; color: Theme.textDim
                              text: modelData.cache_frames ? modelData.cache_frames + " CACHE FR" : "" }
                        Btn { anchors.verticalCenter: parent.verticalCenter; label: "RENDER"; hot: true; onHit: win.render(modelData.name, "full") }
                        Btn { anchors.verticalCenter: parent.verticalCenter; label: "PREVIEW"; onHit: win.render(modelData.name, "viewport") }
                    }
                    Lbl { visible: win.blends.length === 0; text: "NO .BLEND FILES ON THE RENDER PC YET (PULL ONE IN THE PC-A TAB)"; color: Theme.textDim }
                }
            }

            // ---- VIDEOS
            GridView {
                anchors.fill: parent
                visible: Render.configured && win.tab === 2
                clip: true
                cellWidth: Math.max(232, width / Math.max(1, Math.floor(width / 232))); cellHeight: 190
                model: win.videos
                delegate: Item {
                    required property var modelData
                    width: 220; height: 180
                    Rectangle {
                        width: 220; height: 124
                        color: Theme.bg; border.color: vm.containsMouse ? Theme.accentA : Theme.ring; border.width: 2
                        Image { anchors.fill: parent; anchors.margins: 2; fillMode: Image.PreserveAspectCrop
                                asynchronous: true; source: modelData.thumb ? Render.media(modelData.thumb) : "" }
                        Text { anchors.centerIn: parent; visible: vm.containsMouse; text: "▶"; color: Theme.accentA; font.pixelSize: 34 }
                        MouseArea { id: vm; anchors.fill: parent; hoverEnabled: true; onClicked: { Sfx.play("open"); Render.play(modelData.name); } }
                    }
                    Lbl { y: 130; width: 220; text: Render.shortName(modelData.name).replace(/\.mp4$/i, "") }
                    Lbl { y: 150; color: Theme.textDim; font.pixelSize: 10
                          text: Render.fmtTime(modelData.duration) + "  ·  " + win.fmtSize(modelData.size) }
                    Text { y: 148; anchors.right: parent.right; text: "SAVE TO PC-A"
                           color: sm.containsMouse ? Theme.accentA : Theme.textDim
                           font.family: Theme.labelFont; font.pixelSize: 10; font.weight: Font.ExtraBold
                           MouseArea { id: sm; anchors.fill: parent; anchors.margins: -4; hoverEnabled: true
                                       onClicked: Render.api("POST", "/api/save-to-pca?name=" + Render.q(modelData.name),
                                                             ok => win.say(ok ? "SAVING TO PC-A…" : "PC-A DIDN'T ANSWER")) } }
                }
                Lbl { visible: win.videos.length === 0; text: "NO FINISHED VIDEOS YET"; color: Theme.textDim }
            }

            // ---- HISTORY
            ListView {
                anchors.fill: parent
                visible: Render.configured && win.tab === 3
                clip: true; spacing: 2
                model: win.history
                delegate: Row {
                    required property var modelData
                    spacing: 14; height: 26
                    Lbl { width: 100; text: win.fmtDate(modelData.started); color: Theme.textDim }
                    Lbl { width: Math.max(120, page.width - 100 - 80 - 120 - (page.width > 860 ? 140 : 0) - 60); text: Render.shortName(modelData.blend) }
                    Lbl { width: 80; text: (modelData.status || "").toUpperCase()
                          color: modelData.status === "done" ? Theme.accentA : (modelData.status === "error" ? Theme.danger : Theme.textDim) }
                    Lbl { width: 120; text: (modelData.frames || 0) + " FR  ·  " + Render.fmtTime(modelData.seconds) }
                    Lbl { width: 140; visible: page.width > 860; text: modelData.device || ""; color: Theme.textDim }
                }
                Lbl { visible: win.history.length === 0; text: "NO RENDERS YET"; color: Theme.textDim }
            }

            // ---- PC-A files
            ListView {
                anchors.fill: parent
                visible: Render.configured && win.tab === 4
                clip: true; spacing: 4
                model: win.source
                delegate: Row {
                    required property var modelData
                    spacing: 14; height: 32
                    Lbl { anchors.verticalCenter: parent.verticalCenter; width: Math.max(120, page.width - 330); text: modelData.path || modelData.name }
                    Lbl { anchors.verticalCenter: parent.verticalCenter; width: 90; text: win.fmtSize(modelData.size); color: Theme.textDim }
                    Btn { anchors.verticalCenter: parent.verticalCenter; label: "SEND TO RENDER PC"; hot: true
                          onHit: Render.api("POST", "/api/pull?path=" + Render.q(modelData.path),
                                            (ok, j) => win.say(ok ? "SENDING " + Render.shortName(modelData.name).toUpperCase() + " — THEN RENDER IT IN BLENDS"
                                                                  : ((j && j.error) || "COULD NOT PULL").toUpperCase())) }
                }
                Lbl { visible: win.source.length === 0; text: "NO .BLEND FILES SHARED FROM PC-A (OR PC-A IS OFF)"; color: Theme.textDim }
            }
        }
    }
}
