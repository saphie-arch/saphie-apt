import Quickshell
import Quickshell.Io
import Quickshell.Wayland
import QtQuick

// One greeter screen per monitor. The built-in panel (or the first screen) gets the login card.
PanelWindow {
    id: win
    required property var modelData
    screen: modelData
    anchors { top: true; bottom: true; left: true; right: true }
    exclusionMode: ExclusionMode.Ignore
    color: "#000000"
    WlrLayershell.layer: WlrLayer.Overlay
    WlrLayershell.namespace: "saphie-greeter"
    readonly property bool main: {
        const panel = Quickshell.screens.find(s => /^(eDP|LVDS|DSI)/.test(s.name));
        return modelData === (panel ?? Quickshell.screens[0]);
    }
    WlrLayershell.keyboardFocus: main ? WlrKeyboardFocus.Exclusive : WlrKeyboardFocus.None

    Item {
        id: root
        anchors.fill: parent
        transform: Scale { id: tv; origin.x: root.width / 2; origin.y: root.height / 2; yScale: 1; xScale: 1 }
        Component.onCompleted: enter.start()
        Canvas { anchors.fill: parent; opacity: 0.05
                 onPaint: { const c = getContext("2d"); c.fillStyle = "#ffffff"; for (let y = 0; y < height; y += 3) c.fillRect(0, y, width, 1); } }
        SystemClock { id: clock; precision: SystemClock.Seconds }

        Image {   // Saphie OS mark (desktop/brand/logo)
            x: 48; y: 36; width: 34; height: 34
            source: "file://" + Quickshell.shellDir + "/saphie-logo.png"
            sourceSize.width: 68; sourceSize.height: 68; smooth: true; mipmap: true
        }
        Text {
            x: 92; y: 40
            text: "SAPHIE"
            color: Theme.text
            font.family: Theme.titleFont; font.pixelSize: 24
            Text { anchors.left: parent.right; anchors.leftMargin: 10; anchors.verticalCenter: parent.verticalCenter
                   text: "//  CH ▸ LOGIN"; color: Theme.textDim; font.family: Theme.labelFont; font.pixelSize: 13; font.weight: Font.ExtraBold }
        }

        Column {
            id: clockCol
            anchors.centerIn: parent
            anchors.verticalCenterOffset: win.main ? -150 : 0
            Text {
                id: bigClock
                anchors.horizontalCenter: parent.horizontalCenter
                text: Qt.formatDateTime(clock.date, "HH:mm")
                color: Theme.text
                font.family: Theme.numeralFont; font.weight: Font.ExtraBold; font.italic: true
                font.pixelSize: Math.min(200, root.width / 5)
                transform: Translate { id: clockT; y: 0 }
            }
            Rectangle {
                id: datePlate
                anchors.horizontalCenter: parent.horizontalCenter
                width: dateText.implicitWidth + 40; height: 34
                color: Theme.accentA
                transform: Matrix4x4 { matrix: Qt.matrix4x4(1, Theme.skew, 0, -Theme.skew * 17, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1) }
                Text { id: dateText; anchors.centerIn: parent
                       text: Qt.formatDateTime(clock.date, "dddd  dd MMMM yyyy").toUpperCase()
                       color: Theme.onAccent; font.family: Theme.labelFont; font.pixelSize: 14; font.weight: Font.ExtraBold; font.letterSpacing: 2 }
            }
            Item { width: 1; height: 14 }
            Row {
                id: ticks
                anchors.horizontalCenter: parent.horizontalCenter
                spacing: 3
                readonly property int sec: clock.date.getSeconds()
                Repeater {
                    model: 60
                    Rectangle {
                        required property int index
                        width: 4; height: index % 5 === 0 ? 12 : 7
                        anchors.bottom: parent.bottom
                        color: index <= ticks.sec ? (index === ticks.sec ? "#ffffff" : Theme.accentA) : "#262626"
                    }
                }
            }
        }

        // ---- login card (main screen)
        Item {
            id: card
            visible: win.main
            anchors.horizontalCenter: parent.horizontalCenter
            anchors.top: parent.verticalCenter; anchors.topMargin: 40
            width: Math.min(560, root.width - 80); height: 236
            transform: [ Translate { id: shakeT; x: 0 }, Translate { id: riseT; y: 0 } ]
            Rectangle { x: 8; y: 8; width: parent.width; height: parent.height; color: "#000000"; border.color: "#1a1a1a" }
            Rectangle {
                anchors.fill: parent
                color: Theme.surface; border.color: Theme.bg; border.width: 2
                topLeftRadius: 20; topRightRadius: 20; bottomLeftRadius: 20; bottomRightRadius: 0
                Rectangle { anchors.fill: parent; anchors.margins: 2; color: "transparent"
                            border.color: shell.error ? Theme.danger : Theme.ring; border.width: 3
                            topLeftRadius: 18; topRightRadius: 18; bottomLeftRadius: 18 }
            }
            component Pick: Row {
                id: pick
                property string label
                property string value
                property bool canPrev: true
                property bool canNext: true
                signal prev()
                signal next()
                spacing: 10
                Text { anchors.verticalCenter: parent.verticalCenter; text: pick.label; width: 76
                       color: Theme.textDim; font.family: Theme.labelFont; font.pixelSize: 11; font.weight: Font.ExtraBold; font.letterSpacing: 1.4 }
                Text { anchors.verticalCenter: parent.verticalCenter; text: "‹"; visible: pick.canPrev
                       color: pm.containsMouse ? Theme.accentA : Theme.textDim; font.pixelSize: 26; font.weight: Font.Black
                       MouseArea { id: pm; anchors.fill: parent; anchors.margins: -8; hoverEnabled: true; onClicked: { shell.sfx("tick"); pick.prev(); } } }
                Text { anchors.verticalCenter: parent.verticalCenter; text: pick.value.toUpperCase()
                       color: Theme.text; font.family: Theme.numeralFont; font.weight: Font.ExtraBold; font.italic: true; font.pixelSize: 30 }
                Text { anchors.verticalCenter: parent.verticalCenter; text: "›"; visible: pick.canNext
                       color: nm.containsMouse ? Theme.accentA : Theme.textDim; font.pixelSize: 26; font.weight: Font.Black
                       MouseArea { id: nm; anchors.fill: parent; anchors.margins: -8; hoverEnabled: true; onClicked: { shell.sfx("tick"); pick.next(); } } }
            }
            Pick {
                x: 28; y: 18
                label: "USER"
                value: shell.user ? (shell.user.gecos || shell.user.name) : "…"
                canPrev: shell.users.length > 1; canNext: shell.users.length > 1
                onPrev: shell.userIdx = (shell.userIdx + shell.users.length - 1) % shell.users.length
                onNext: shell.userIdx = (shell.userIdx + 1) % shell.users.length
            }
            Pick {
                x: 28; y: 62
                label: "SESSION"
                value: shell.session ? shell.session.name : "…"
                canPrev: shell.sessions.length > 1; canNext: shell.sessions.length > 1
                onPrev: shell.sessionIdx = (shell.sessionIdx + shell.sessions.length - 1) % shell.sessions.length
                onNext: shell.sessionIdx = (shell.sessionIdx + 1) % shell.sessions.length
            }
            Item {   // password field
                x: 28; y: 116; width: parent.width - 56; height: 50
                Rectangle {
                    anchors.fill: parent
                    color: "#0c0c0c"; border.color: pw.activeFocus ? Theme.accentA : Theme.ring; border.width: 3
                    transform: Matrix4x4 { matrix: Qt.matrix4x4(1, Theme.skew, 0, -Theme.skew * 25, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1) }
                }
                Rectangle {
                    id: errFill; anchors.fill: parent; color: Theme.danger; opacity: 0
                    transform: Matrix4x4 { matrix: Qt.matrix4x4(1, Theme.skew, 0, -Theme.skew * 25, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1) }
                }
                Row {
                    x: 22; anchors.verticalCenter: parent.verticalCenter
                    spacing: 7
                    Repeater {
                        model: Math.min(pw.text.length, 26)
                        Rectangle {
                            width: 10; height: 10; rotation: 45; color: Theme.accentA; scale: 0
                            Component.onCompleted: popA.start()
                            NumberAnimation on scale { id: popA; running: false; from: 0; to: 1; duration: 180; easing.type: Easing.OutBack; easing.overshoot: 3 }
                        }
                    }
                }
                Text { x: 22; anchors.verticalCenter: parent.verticalCenter; visible: pw.text.length === 0
                       text: "PASSWORD"; color: Theme.raised; font.family: Theme.labelFont; font.pixelSize: 16; font.letterSpacing: 2 }
                TextInput {
                    id: pw
                    anchors.fill: parent; opacity: 0
                    echoMode: TextInput.Password
                    maximumLength: 256
                    enabled: !shell.busy
                    focus: win.main
                    Keys.onReturnPressed: { shell.login(text); text = ""; }
                    Keys.onEnterPressed: { shell.login(text); text = ""; }
                    Keys.onEscapePressed: text = ""
                    Keys.onTabPressed: { shell.sfx("tick"); shell.sessionIdx = (shell.sessionIdx + 1) % Math.max(1, shell.sessions.length); }
                    Component.onCompleted: if (win.main) forceActiveFocus()
                }
            }
            Text {
                x: 28; y: 186
                text: shell.message || "ENTER TO LOG IN    TAB SESSION"
                color: shell.error ? Theme.danger : Theme.textDim
                font.family: Theme.labelFont; font.pixelSize: 11; font.weight: Font.ExtraBold; font.letterSpacing: 1.4
            }
            Connections {
                target: shell
                function onFailed() { shake.restart(); redFlash.restart(); pw.forceActiveFocus(); }
                function onLaunching() { leave.restart(); }
            }
            SequentialAnimation { id: shake
                NumberAnimation { target: shakeT; property: "x"; to: -16; duration: 45 }
                NumberAnimation { target: shakeT; property: "x"; to: 14; duration: 60 }
                NumberAnimation { target: shakeT; property: "x"; to: -9; duration: 55 }
                NumberAnimation { target: shakeT; property: "x"; to: 0; duration: 140; easing.type: Easing.OutBack } }
            SequentialAnimation { id: redFlash
                NumberAnimation { target: errFill; property: "opacity"; to: 0.6; duration: 60 }
                NumberAnimation { target: errFill; property: "opacity"; to: 0; duration: 400 } }
        }

        // ---- ambient sound switch (main screen)
        Rectangle {
            visible: win.main
            anchors.left: parent.left; anchors.bottom: parent.bottom; anchors.margins: 40
            width: amb.implicitWidth + 30; height: 36
            color: shell.ambient ? Theme.accentA : (am2.containsMouse ? "#1f1f1f" : Theme.bg)
            border.color: shell.ambient ? Theme.bg : Theme.ring; border.width: 2
            transform: Matrix4x4 { matrix: Qt.matrix4x4(1, Theme.skew, 0, -Theme.skew * 18, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1) }
            Text { id: amb; anchors.centerIn: parent; text: "♪ AMBIENT " + (shell.ambient ? "ON" : "OFF")
                   color: shell.ambient ? Theme.onAccent : Theme.textDim
                   font.family: Theme.labelFont; font.pixelSize: 11; font.weight: Font.ExtraBold; font.letterSpacing: 1.4 }
            MouseArea { id: am2; anchors.fill: parent; hoverEnabled: true; onClicked: { shell.toggleAmbient(); pw.forceActiveFocus(); } }
        }

        // ---- power (main screen)
        Row {
            visible: win.main
            anchors.right: parent.right; anchors.bottom: parent.bottom; anchors.margins: 40
            spacing: 12
            component PBtn: Rectangle {
                id: b
                property string label
                property var cmd
                Process {   // polkit may refuse (e.g. other users logged in): say so
                    id: proc
                    command: b.cmd
                    onExited: code => { if (code !== 0) { shell.error = true; shell.message = b.label + " NOT ALLOWED RIGHT NOW"; } }
                }
                width: bt.implicitWidth + 32; height: 36
                color: bm.containsMouse ? Theme.accentA : Theme.bg
                border.color: Theme.ring; border.width: 2
                transform: Matrix4x4 { matrix: Qt.matrix4x4(1, Theme.skew, 0, -Theme.skew * 18, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1) }
                Text { id: bt; anchors.centerIn: parent; text: b.label; color: bm.containsMouse ? Theme.onAccent : Theme.text
                       font.family: Theme.labelFont; font.pixelSize: 11; font.weight: Font.ExtraBold; font.letterSpacing: 1.4 }
                MouseArea { id: bm; anchors.fill: parent; hoverEnabled: true; onClicked: proc.running = true }
            }
            PBtn { label: "RESTART"; cmd: ["systemctl", "reboot"] }
            PBtn { label: "SHUT DOWN"; cmd: ["systemctl", "poweroff"] }
        }
        MouseArea { anchors.fill: parent; z: -1; onClicked: pw.forceActiveFocus() }
    }
    Rectangle { id: tvLine; y: win.height / 2 - 2; width: win.width; height: 4; color: "#ffffff"; opacity: 0 }

    SequentialAnimation {
        id: enter
        ScriptAction { script: { tv.yScale = 0.004; tvLine.opacity = 1; clockT.y = -60; bigClock.opacity = 0;
                                 datePlate.opacity = 0; ticks.opacity = 0; riseT.y = 80; card.opacity = 0; } }
        PauseAnimation { duration: 120 }
        ParallelAnimation {
            NumberAnimation { target: tv; property: "yScale"; to: 1; duration: 360; easing.type: Easing.OutBack; easing.overshoot: 1.3 }
            NumberAnimation { target: tvLine; property: "opacity"; to: 0; duration: 240 }
        }
        ParallelAnimation {
            NumberAnimation { target: clockT; property: "y"; to: 0; duration: 380; easing.type: Easing.OutBack; easing.overshoot: 1.8 }
            NumberAnimation { target: bigClock; property: "opacity"; to: 1; duration: 120 }
            SequentialAnimation { PauseAnimation { duration: 90 } NumberAnimation { target: datePlate; property: "opacity"; to: 1; duration: 100 } }
            SequentialAnimation { PauseAnimation { duration: 150 } NumberAnimation { target: ticks; property: "opacity"; to: 1; duration: 200 } }
            SequentialAnimation { PauseAnimation { duration: 180 }
                ParallelAnimation {
                    NumberAnimation { target: riseT; property: "y"; to: 0; duration: 400; easing.type: Easing.OutBack; easing.overshoot: 1.6 }
                    NumberAnimation { target: card; property: "opacity"; to: 1; duration: 120 } } }
        }
    }
    SequentialAnimation {
        id: leave
        NumberAnimation { target: tv; property: "xScale"; to: 1.03; duration: 50 }
        ParallelAnimation {
            NumberAnimation { target: tv; property: "yScale"; to: 0.004; duration: 170; easing.type: Easing.InQuad }
            NumberAnimation { target: tvLine; property: "opacity"; to: 1; duration: 170 }
        }
        ParallelAnimation {
            NumberAnimation { target: tv; property: "xScale"; to: 0; duration: 90; easing.type: Easing.InQuad }
            NumberAnimation { target: root; property: "opacity"; to: 0; duration: 90 }
        }
    }
}
