// Saphie greeter (greetd + Quickshell). Runs inside a minimal niri as the "greeter" user.
// Same visual language as the lock screen: TV switch-on/off, big clock, green date plate,
// user card with password diamonds, session chip (Saphie / Ubuntu), restart / shut down.
// Test without root: desktop/greeter/test/run-nested.sh (fake greetd, password "saphie-test").
import Quickshell
import Quickshell.Io
import Quickshell.Wayland
import Quickshell.Services.Greetd
import QtQuick

ShellRoot {
    id: shell
    property var users: []            // [{name, gecos}]
    property var sessions: []         // [{name, exec, desktopNames, file}]
    property int userIdx: 0
    property int sessionIdx: 0
    property string message: ""
    property bool error: false
    property bool busy: false
    property string pending: ""
    property bool awaiting: false
    property bool ambient: true        // login ambient sound (saved with the last user/session)
    property bool launchingNow: false      // greetd asked another question (e.g. expired password, 2FA)
    signal failed()
    signal launching()

    readonly property var user: users[userIdx] ?? null
    readonly property var session: sessions[sessionIdx] ?? null
    readonly property string stateFile: (Quickshell.env("HOME") ?? "/tmp") + "/.saphie-greeter.json"

    // --- users with a real login shell (uid 1000..59999)
    Process {
        running: true
        command: ["getent", "passwd"]
        stdout: SplitParser {
            onRead: line => {
                const f = line.split(":");
                const uid = parseInt(f[2]);
                if (f.length < 7 || !(uid >= 1000 && uid < 60000) || /(nologin|false)$/.test(f[6])) return;
                if (!/^[a-z_][a-z0-9_-]*$/.test(f[0])) return;
                shell.users = shell.users.concat([{ name: f[0], gecos: (f[4] || "").split(",")[0] }]);
                shell.restore();
            }
        }
    }
    // --- Wayland sessions from /usr/share/wayland-sessions (root-owned, trusted), de-duplicated
    Process {
        running: true
        command: ["sh", "-c", "for f in /usr/share/wayland-sessions/*.desktop; do printf '%s\\t' \"$f\"; " +
                 "grep -m1 '^Name=' \"$f\" | cut -d= -f2- | tr -d '\\t' | tr '\\n' '\\t'; " +
                 "grep -m1 '^Exec=' \"$f\" | cut -d= -f2- | tr -d '\\t' | tr '\\n' '\\t'; " +
                 "grep -m1 '^DesktopNames=' \"$f\" | cut -d= -f2- | tr -d '\\t' | tr '\\n' '\\t'; " +
                 "grep -m1 -E '^(NoDisplay|Hidden)=true' \"$f\" >/dev/null && echo hidden || echo shown; done"]
        stdout: SplitParser {
            onRead: line => {
                const f = line.split("\t");
                if (f.length < 5 || f[4] === "hidden" || !f[2]) return;
                if (shell.sessions.some(s => s.exec === f[2])) return;      // Ubuntu == Ubuntu on Wayland
                const s = { file: f[0], name: f[1] || "Session", exec: f[2], desktopNames: f[3] };
                // Saphie first
                shell.sessions = /saphie/i.test(s.name) ? [s].concat(shell.sessions) : shell.sessions.concat([s]);
                shell.restore();
            }
        }
    }
    // --- remember last user/session (greeter's own home)
    FileView {
        id: stateView
        path: shell.stateFile
        printErrors: false
        onLoaded: shell.restore()
    }
    function restore() {
        try {
            const d = JSON.parse(stateView.text() || "{}");
            const ui = users.findIndex(u => u.name === d.user); if (ui >= 0) userIdx = ui;
            const si = sessions.findIndex(s => s.name === d.session); if (si >= 0) sessionIdx = si;
            if (typeof d.ambient === "boolean") ambient = d.ambient;
        } catch (e) {}
    }
    function save() {
        stateView.setText(JSON.stringify({ user: user?.name ?? "", session: session?.name ?? "", ambient: ambient }) + "\n");
    }

    // --- greetd flow
    function login(password) {
        if (busy || !user || !session || password.length === 0) return;
        if (!Greetd.available) { error = true; message = "GREETD NOT AVAILABLE"; failed(); return; }
        if (awaiting) {   // answer the open prompt instead of starting a new session
            awaiting = false; busy = true; error = false; message = "CHECKING…";
            Greetd.respond(password);
            return;
        }
        busy = true; error = false; message = "CHECKING…"; pending = password;
        Greetd.createSession(user.name);
    }
    Connections {
        target: Greetd
        function onAuthMessage(msg, isError, responseRequired, echo) {
            if (responseRequired) {
                if (shell.pending.length > 0) { Greetd.respond(shell.pending); shell.pending = ""; }
                else { shell.busy = false; shell.awaiting = true; shell.message = msg.toUpperCase(); }
            } else if (msg) { shell.message = msg.toUpperCase(); shell.error = isError; }
        }
        function onAuthFailure(msg) {
            // Quickshell already cancels the greetd session on an auth error.
            shell.busy = false; shell.pending = ""; shell.awaiting = false; shell.error = true; shell.message = "WRONG PASSWORD";
            shell.sfx("error");
            shell.failed();
        }
        function onError(err) {
            shell.busy = false; shell.pending = ""; shell.awaiting = false; shell.error = true; shell.message = "LOGIN ERROR";
            Greetd.cancelSession();      // a hard greetd error leaves the session open
            shell.failed();
        }
        function onReadyToLaunch() {
            shell.save();
            shell.launchingNow = true;                       // stops the ambient (frees the sound card)
            shell.sfx("unlock");
            shell.message = "STARTING " + shell.session.name.toUpperCase();
            shell.launching();
            launchTimer.restart();     // let the switch-off play
        }
    }
    // Ambient loop: runs while the greeter is up and the switch is on; SIGTERM stops it.
    Process {
        id: ambientProc
        running: shell.ambient && !shell.launchingNow
        command: [Quickshell.shellDir + "/ambient-play", "loop"]
    }
    function toggleAmbient() { ambient = !ambient; save(); sfx("tick"); }
    // Short UI sounds (desktop/sounds kit), mixed over the ambient through ALSA dmix.
    function sfx(name) {
        if (["tick", "error", "unlock"].includes(name))
            Quickshell.execDetached([Quickshell.shellDir + "/ambient-play", "once", Quickshell.shellDir + "/sounds/" + name + ".wav"]);
    }

    Timer {
        id: launchTimer; interval: 320
        onTriggered: {
            const names = (shell.session.desktopNames || "").replace(/;+$/, "").replace(/;/g, ":");
            const base = shell.session.file.replace(/^.*\//, "").replace(/\.desktop$/, "");
            Greetd.launch(["/bin/sh", "-c", shell.session.exec],
                          ["XDG_SESSION_TYPE=wayland", "XDG_CURRENT_DESKTOP=" + names, "XDG_SESSION_DESKTOP=" + base],
                          true);
        }
    }

    // TEST-HOOK-BEGIN (removed from the installed copy by install.sh)
    // Test hook (only with SAPHIE_GREETER_TEST=1): drive the login from a script.
    IpcHandler {
        target: "greetertest"
        enabled: Quickshell.env("SAPHIE_GREETER_TEST") === "1"
        function login(pw: string): void { shell.login(pw); }
        function state(): string { return JSON.stringify({ busy: shell.busy, message: shell.message, user: shell.user?.name, session: shell.session?.name, sessions: shell.sessions.map(s => s.name) }); }
    }
    // TEST-HOOK-END

    Variants {
        model: Quickshell.screens
        delegate: Component { GreeterScreen {} }
    }
}
