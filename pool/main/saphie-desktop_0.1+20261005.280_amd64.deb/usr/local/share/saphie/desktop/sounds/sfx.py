"""Tiny pure-Python synth toolkit for the Saphie sound kit (no numpy, deterministic).

All signals are plain lists of floats at RATE. Building blocks: oscillators, seeded noise,
one-pole / biquad filters, envelopes, FM bell, mixing, echo, gentle saturation, WAV writing.
"""
import math, struct, wave

RATE = 48000
TAU = 2 * math.pi


class Noise:
    """Deterministic white noise (LCG), so regenerating gives byte-identical files."""
    def __init__(self, seed=1):
        self.s = seed & 0xFFFFFFFF
    def __call__(self):
        self.s = (1664525 * self.s + 1013904223) & 0xFFFFFFFF
        return self.s / 2147483648.0 - 1.0
    def block(self, n):
        return [self() for _ in range(n)]


def n_of(sec): return max(1, int(sec * RATE))
def silence(sec): return [0.0] * n_of(sec)


def sweep(f0, f1, sec, shape="exp", wave_="sine", amp=1.0, phase=0.0):
    """Oscillator gliding f0 -> f1. wave_: sine | tri | soft (sine + odd harmonics, squarish)."""
    n = n_of(sec); out = []; ph = phase
    for i in range(n):
        u = i / n
        f = f0 * (f1 / f0) ** u if shape == "exp" else f0 + (f1 - f0) * u
        ph += TAU * f / RATE
        if wave_ == "sine":
            v = math.sin(ph)
        elif wave_ == "tri":
            v = 2 / math.pi * math.asin(math.sin(ph))
        else:
            v = math.sin(ph) + math.sin(3 * ph) / 4 + math.sin(5 * ph) / 12
        out.append(amp * v)
    return out


def tone(f, sec, wave_="sine", amp=1.0):
    return sweep(f, f, sec, "lin", wave_, amp)


def fm_bell(f, sec, ratio=2.0, index=2.2, decay=0.25, amp=1.0, idecay=0.08):
    """Bright FM pluck/bell (DX-style e-piano/bell) - the 'signal ping' colour."""
    n = n_of(sec); out = []
    for i in range(n):
        t = i / RATE
        mod = index * math.exp(-t / idecay) * math.sin(TAU * f * ratio * t)
        out.append(amp * math.sin(TAU * f * t + mod) * math.exp(-t / decay) * min(1.0, t / 0.002))
    return out


def ep(f, sec, amp=1.0, decay=1.2):
    """Soft FM electric piano voice (for the ambient)."""
    n = n_of(sec); out = []
    for i in range(n):
        t = i / RATE
        mod = 1.3 * math.exp(-t / 0.35) * math.sin(TAU * f * t)
        tine = 0.25 * math.exp(-t / 0.05) * math.sin(TAU * f * 14 * t)
        out.append(amp * (math.sin(TAU * f * t + mod) + tine) * math.exp(-t / decay) * min(1.0, t / 0.004))
    return out


def env(sig, attack=0.002, decay=None, hold=0.0, release=0.0):
    """Linear attack, optional hold, exponential decay (time constant) and linear release tail."""
    n = len(sig); a = max(1, n_of(attack)); h = n_of(hold) if hold else 0
    r = n_of(release) if release else 0
    out = []
    for i, v in enumerate(sig):
        g = min(1.0, i / a)
        if decay and i > a + h:
            g *= math.exp(-(i - a - h) / RATE / decay)
        if r and i > n - r:
            g *= (n - i) / r
        out.append(v * g)
    return out


def lowpass(sig, fc):
    """One-pole low-pass; fc may be a number or a function of progress u (0..1)."""
    out = []; y = 0.0; n = len(sig)
    for i, x in enumerate(sig):
        f = fc(i / n) if callable(fc) else fc
        a = 1 - math.exp(-TAU * f / RATE)
        y += a * (x - y); out.append(y)
    return out


def highpass(sig, fc):
    lp = lowpass(sig, fc)
    return [x - y for x, y in zip(sig, lp)]


def bandpass(sig, fc, q=4.0):
    """RBJ biquad band-pass (constant peak gain)."""
    w = TAU * fc / RATE; al = math.sin(w) / (2 * q); c = math.cos(w)
    b0, b2, a0, a1, a2 = al, -al, 1 + al, -2 * c, 1 - al
    b0, b2, a1, a2 = b0 / a0, b2 / a0, a1 / a0, a2 / a0
    x1 = x2 = y1 = y2 = 0.0; out = []
    for x in sig:
        y = b0 * x + b2 * x2 - a1 * y1 - a2 * y2
        x2, x1, y2, y1 = x1, x, y1, y
        out.append(y)
    return out


def mix(*parts, length=None):
    """parts: (offset_seconds, signal, gain) tuples or plain signals."""
    norm = [(0.0, p, 1.0) if isinstance(p, list) else (p if len(p) == 3 else (p[0], p[1], 1.0)) for p in parts]
    n = length or max(n_of(o) + len(s) for o, s, _ in norm)
    out = [0.0] * n
    for o, s, g in norm:
        k = n_of(o) if o else 0
        for i, v in enumerate(s):
            if k + i < n:
                out[k + i] += v * g
    return out


def echo(sig, delay, fb=0.3, taps=3):
    parts = [(0.0, sig, 1.0)] + [(delay * k, sig, fb ** k) for k in range(1, taps + 1)]
    return mix(*parts)


def saturate(sig, drive=1.5):
    k = math.tanh(drive)
    return [math.tanh(v * drive) / k for v in sig]


def fade_out(sig, sec):
    n = len(sig); r = n_of(sec)
    return [v * min(1.0, (n - i) / r) for i, v in enumerate(sig)]


def normalize(sig, peak_db):
    pk = max(abs(v) for v in sig) or 1.0
    g = 10 ** (peak_db / 20) / pk
    return [v * g for v in sig]


def write(path, sig, rate=RATE):
    with wave.open(str(path), "wb") as w:
        w.setnchannels(1); w.setsampwidth(2); w.setframerate(rate)
        w.writeframes(b"".join(struct.pack("<h", int(max(-1.0, min(1.0, v)) * 32000)) for v in sig))
